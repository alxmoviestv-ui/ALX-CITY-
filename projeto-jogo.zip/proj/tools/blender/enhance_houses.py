"""
enhance_houses.py - roda DENTRO do Blender (sem interface) para melhorar as casas dos condomínios:
junta vértices duplicados, arredonda as quinas com um chanfro pequeno (as bordas passam a pegar luz)
e exporta de novo. Etapa obrigatória do build: se alguma casa falhar, o build para.

Uso: blender -b -P tools/blender/enhance_houses.py -- game/condos
"""
import glob
import math
import os
import sys

import bpy


def enhance(path):
    mtl_path = path[:-4] + ".mtl"
    original_mtl = open(mtl_path).read()

    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.wm.obj_import(filepath=path)
    meshes = [o for o in bpy.context.scene.objects if o.type == "MESH"]
    if not meshes:
        raise RuntimeError("sem malhas")
    bpy.ops.object.select_all(action="DESELECT")
    for o in meshes:
        o.select_set(True)
    bpy.context.view_layer.objects.active = meshes[0]
    if len(meshes) > 1:
        bpy.ops.object.join()
    obj = bpy.context.view_layer.objects.active

    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.mesh.remove_doubles(threshold=0.002)
    bpy.ops.object.mode_set(mode="OBJECT")

    bev = obj.modifiers.new("Chanfro", "BEVEL")
    bev.width = 0.025
    bev.segments = 2
    bev.limit_method = "ANGLE"
    bev.angle_limit = math.radians(40)
    bpy.ops.object.modifier_apply(modifier=bev.name)

    try:  # Blender 4.1 ou mais novo
        bpy.ops.object.shade_auto_smooth(angle=math.radians(35))
    except Exception:  # Blender 4.0 ou mais antigo
        obj.data.use_auto_smooth = True
        obj.data.auto_smooth_angle = math.radians(35)
        bpy.ops.object.shade_smooth()

    bpy.ops.wm.obj_export(
        filepath=path,
        export_materials=True,
        export_normals=True,
        export_uv=True,
        export_triangulated_mesh=True,
        apply_modifiers=True,
        forward_axis="NEGATIVE_Z",
        up_axis="Y",
    )
    # o Blender reescreve o .mtl com outros caminhos de textura: devolve o original
    open(mtl_path, "w").write(original_mtl)


def main():
    folder = sys.argv[sys.argv.index("--") + 1]
    files = sorted(glob.glob(os.path.join(folder, "condo*_house*_raw.obj")))
    print("casas encontradas:", len(files))
    ok = 0
    for path in files:
        try:
            enhance(path)
            ok += 1
            print("ok:", os.path.basename(path))
        except Exception as e:  # noqa: BLE001
            print("falhou:", os.path.basename(path), "->", e)
    print("casas melhoradas:", ok, "de", len(files))
    if ok != len(files):
        raise SystemExit(1)  # etapa obrigatória: o build para se alguma casa falhar


main()
