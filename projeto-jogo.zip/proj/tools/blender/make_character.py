"""
make_character.py - roda DENTRO do Blender (sem interface): cria um personagem humanoide com esqueleto
e as animações idle, walk e run, e exporta em .glb (o Godot importa direto).

Uso: blender -b -P tools/blender/make_character.py -- game/assets/character.glb

O personagem olha para +Y no Blender, que vira -Z no Godot (a "frente" do Godot).
"""
import math
import os
import sys

import bmesh
import bpy
from mathutils import Matrix, Vector

OUT = sys.argv[sys.argv.index("--") + 1]


def material(name, color, rough=0.8):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (color[0], color[1], color[2], 1.0)
    b.inputs["Roughness"].default_value = rough
    return m


MATS = {}


def limb(bm, p0, p1, r0, r1, seg=10):
    p0, p1 = Vector(p0), Vector(p1)
    d = p1 - p0
    mid = (p0 + p1) / 2
    rot = Vector((0, 0, 1)).rotation_difference(d.normalized()).to_matrix().to_4x4()
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=seg, radius1=r0, radius2=r1,
                          depth=d.length, matrix=Matrix.Translation(mid) @ rot)


def ball(bm, p, r, scale=(1, 1, 1)):
    m = Matrix.Translation(Vector(p)) @ Matrix.Diagonal(Vector((scale[0], scale[1], scale[2], 1.0)))
    bmesh.ops.create_uvsphere(bm, u_segments=12, v_segments=8, radius=r, matrix=m)


def box(bm, center, size):
    m = Matrix.Translation(Vector(center)) @ Matrix.Diagonal(Vector((size[0], size[1], size[2], 1.0)))
    bmesh.ops.create_cube(bm, size=1.0, matrix=m)


parts = []  # (nome, malha bmesh, material, osso)


def part(name, mat, bone, build):
    bm = bmesh.new()
    build(bm)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    ob.data.materials.append(MATS[mat])
    for p in me.polygons:
        p.use_smooth = True
    vg = ob.vertex_groups.new(name=bone)
    vg.add(list(range(len(me.vertices))), 1.0, "REPLACE")
    parts.append(ob)


def build_body():
    # torso e quadril
    part("quadril", "pants", "hips", lambda bm: (box(bm, (0, 0, 0.98), (0.34, 0.20, 0.20)), ball(bm, (0, 0, 0.98), 0.17, (1.0, 0.65, 0.7))))
    part("torso", "shirt", "spine", lambda bm: (box(bm, (0, 0, 1.24), (0.38, 0.21, 0.40)), ball(bm, (0, 0, 1.40), 0.20, (1.0, 0.6, 0.5))))
    part("pescoco", "skin", "neck", lambda bm: limb(bm, (0, 0, 1.50), (0, 0, 1.60), 0.05, 0.045))
    part("cabeca", "skin", "head", lambda bm: ball(bm, (0, 0, 1.68), 0.105, (0.9, 1.0, 1.1)))
    part("cabelo", "hair", "head", lambda bm: ball(bm, (0, -0.015, 1.715), 0.108, (0.92, 1.0, 0.95)))
    part("olhos", "eye", "head", lambda bm: (ball(bm, (-0.035, 0.088, 1.69), 0.012), ball(bm, (0.035, 0.088, 1.69), 0.012)))
    for side, sx in (("L", 1), ("R", -1)):
        # braços
        part("braco_" + side, "shirt", "upper_arm." + side, lambda bm, sx=sx: (
            limb(bm, (0.20 * sx, 0, 1.45), (0.22 * sx, 0, 1.18), 0.055, 0.048), ball(bm, (0.20 * sx, 0, 1.45), 0.06)))
        part("antebraco_" + side, "skin", "forearm." + side, lambda bm, sx=sx: (
            limb(bm, (0.22 * sx, 0, 1.18), (0.23 * sx, 0, 0.92), 0.045, 0.038), ball(bm, (0.22 * sx, 0, 1.18), 0.046)))
        part("mao_" + side, "skin", "hand." + side, lambda bm, sx=sx: ball(bm, (0.23 * sx, 0.01, 0.86), 0.045, (0.8, 1.0, 1.4)))
        # pernas
        part("coxa_" + side, "pants", "thigh." + side, lambda bm, sx=sx: (
            limb(bm, (0.10 * sx, 0, 0.93), (0.10 * sx, 0, 0.50), 0.085, 0.065), ball(bm, (0.10 * sx, 0, 0.93), 0.088)))
        part("canela_" + side, "pants", "shin." + side, lambda bm, sx=sx: (
            limb(bm, (0.10 * sx, 0, 0.50), (0.10 * sx, 0, 0.09), 0.065, 0.048), ball(bm, (0.10 * sx, 0, 0.50), 0.066)))
        part("pe_" + side, "shoes", "foot." + side, lambda bm, sx=sx: box(bm, (0.10 * sx, 0.05, 0.05), (0.11, 0.26, 0.09)))


BONES = [  # nome, cabeça, cauda, pai
    ("hips", (0, 0, 0.95), (0, 0, 1.05), None),
    ("spine", (0, 0, 1.05), (0, 0, 1.45), "hips"),
    ("neck", (0, 0, 1.50), (0, 0, 1.60), "spine"),
    ("head", (0, 0, 1.60), (0, 0, 1.78), "neck"),
]
for side, sx in (("L", 1), ("R", -1)):
    BONES += [
        ("upper_arm." + side, (0.20 * sx, 0, 1.45), (0.22 * sx, 0, 1.18), "spine"),
        ("forearm." + side, (0.22 * sx, 0, 1.18), (0.23 * sx, 0, 0.92), "upper_arm." + side),
        ("hand." + side, (0.23 * sx, 0, 0.92), (0.23 * sx, 0.02, 0.80), "forearm." + side),
        ("thigh." + side, (0.10 * sx, 0, 0.93), (0.10 * sx, 0, 0.50), "hips"),
        ("shin." + side, (0.10 * sx, 0, 0.50), (0.10 * sx, 0, 0.09), "thigh." + side),
        ("foot." + side, (0.10 * sx, 0, 0.09), (0.10 * sx, 0.15, 0.04), "shin." + side),
    ]


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    # materiais precisam ser recriados depois do reset
    global MATS
    MATS = {
        "skin": material("skin", (0.78, 0.58, 0.45), 0.6),
        "shirt": material("shirt", (0.16, 0.30, 0.55), 0.85),
        "pants": material("pants", (0.10, 0.11, 0.16), 0.9),
        "shoes": material("shoes", (0.05, 0.05, 0.05), 0.7),
        "hair": material("hair", (0.12, 0.08, 0.05), 0.9),
        "eye": material("eye", (0.02, 0.02, 0.02), 0.3),
    }
    build_body()

    # esqueleto
    arm = bpy.data.armatures.new("Esqueleto")
    arm_ob = bpy.data.objects.new("Esqueleto", arm)
    bpy.context.collection.objects.link(arm_ob)
    bpy.context.view_layer.objects.active = arm_ob
    bpy.ops.object.mode_set(mode="EDIT")
    made = {}
    for name, head, tail, parent in BONES:
        eb = arm.edit_bones.new(name)
        eb.head, eb.tail = head, tail
        if parent:
            eb.parent = made[parent]
        made[name] = eb
    bpy.ops.object.mode_set(mode="OBJECT")

    # junta as peças numa malha só, presa ao esqueleto
    bpy.ops.object.select_all(action="DESELECT")
    for ob in parts:
        ob.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()
    body = bpy.context.view_layer.objects.active
    body.name = "Personagem"
    body.parent = arm_ob
    mod = body.modifiers.new("Esqueleto", "ARMATURE")
    mod.object = arm_ob

    # descobre, para cada osso, qual sinal de rotação em X leva a ponta para a frente (+Y)
    bpy.context.view_layer.objects.active = arm_ob
    bpy.ops.object.mode_set(mode="POSE")
    sign = {}
    for pb in arm_ob.pose.bones:
        pb.rotation_mode = "XYZ"
        rest = (arm_ob.matrix_world @ pb.tail).y
        pb.rotation_euler.x = 0.4
        bpy.context.view_layer.update()
        moved = (arm_ob.matrix_world @ pb.tail).y
        sign[pb.name] = 1.0 if moved > rest + 1e-5 else -1.0
        pb.rotation_euler.x = 0.0
    bpy.context.view_layer.update()

    def key(pb, frame, ax_angle):
        pb.rotation_euler = (sign[pb.name] * ax_angle, 0.0, 0.0)
        pb.keyframe_insert("rotation_euler", frame=frame)

    pose = arm_ob.pose.bones
    arm_ob.animation_data_create()

    def make_action(name, frames, builder):
        act = bpy.data.actions.new(name)
        arm_ob.animation_data.action = act
        for pb in pose:
            pb.rotation_euler = (0.0, 0.0, 0.0)
        for f in range(frames + 1):
            builder(1 + f, 2.0 * math.pi * f / frames)
        track = arm_ob.animation_data.nla_tracks.new()
        track.name = name
        track.strips.new(name, 1, act)
        arm_ob.animation_data.action = None

    def locomotion(amp, knee, arm_amp):
        def build(frame, ph):
            for s, sg in (("L", 1.0), ("R", -1.0)):
                key(pose["thigh." + s], frame, amp * sg * math.sin(ph))
                key(pose["shin." + s], frame, -knee * max(0.0, sg * math.cos(ph)) - 0.05)
                key(pose["foot." + s], frame, 0.15 * sg * -math.sin(ph))
                key(pose["upper_arm." + s], frame, -arm_amp * sg * math.sin(ph))
                key(pose["forearm." + s], frame, 0.25 + 0.2 * max(0.0, -sg * math.sin(ph)))
            key(pose["spine"], frame, 0.04 * math.sin(2 * ph))
            key(pose["head"], frame, -0.03 * math.sin(2 * ph))
        return build

    def idle(frame, ph):
        for s in ("L", "R"):
            key(pose["upper_arm." + s], frame, 0.03 * math.sin(ph))
            key(pose["forearm." + s], frame, 0.15)
        key(pose["spine"], frame, 0.015 * math.sin(ph))
        key(pose["head"], frame, 0.01 * math.sin(ph + 1.0))

    make_action("idle", 48, idle)
    make_action("walk", 24, locomotion(0.55, 0.9, 0.5))
    make_action("run", 16, locomotion(0.95, 1.5, 0.9))
    bpy.ops.object.mode_set(mode="OBJECT")

    os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
    bpy.ops.export_scene.gltf(filepath=OUT, export_format="GLB", export_animations=True,
                              export_nla_strips=True, export_yup=True)
    print("personagem exportado:", OUT, os.path.getsize(OUT), "bytes")


main()
