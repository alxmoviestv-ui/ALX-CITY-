"""
make_car.py - roda DENTRO do Blender (sem interface): modela um sedã (carroceria arredondada, vidros,
faróis e lanternas acesos, grade, para-choques, retrovisores, caixas de roda) e uma roda (pneu, aro e
calota), e exporta car_body.glb e car_wheel.glb.

Uso: blender -b -P tools/blender/make_car.py -- game/assets

Frente do carro: +Y no Blender (vira -Z no Godot). A origem do carro fica no chão; as rodas ficam a
0,35 m de altura (raio da roda = 0,35 m). O material "paint" é recolorido pelo jogo.
"""
import math
import os
import sys

import bmesh
import bpy
from mathutils import Matrix, Vector

OUT = sys.argv[sys.argv.index("--") + 1]


def material(name, color, rough=0.5, metal=0.0, emission=None, strength=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (color[0], color[1], color[2], 1.0)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if emission is not None:
        name_color = "Emission Color" if "Emission Color" in b.inputs else "Emission"
        b.inputs[name_color].default_value = (emission[0], emission[1], emission[2], 1.0)
        b.inputs["Emission Strength"].default_value = strength
    return m


def new_obj(name, bm, mat):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = True
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    ob.data.materials.append(mat)
    return ob


def box(bm, c, s):
    m = Matrix.Translation(Vector(c)) @ Matrix.Diagonal(Vector((s[0], s[1], s[2], 1.0)))
    bmesh.ops.create_cube(bm, size=1.0, matrix=m)


def cyl_x(bm, c, r, w, seg=24, r2=None):
    """Cilindro com o eixo ao longo de X."""
    rot = Matrix.Rotation(math.radians(90), 4, "Y")
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=seg, radius1=r, radius2=r if r2 is None else r2,
                          depth=w, matrix=Matrix.Translation(Vector(c)) @ rot)


def body_shell(paint):
    # perfil lateral (y, z), de trás para a frente; extrudado na largura
    prof = [(-2.20, 0.32), (-2.30, 0.58), (-2.22, 0.92), (-1.65, 0.98), (-0.98, 1.40), (0.50, 1.42),
            (1.12, 1.00), (2.02, 0.90), (2.28, 0.64), (2.18, 0.32)]
    w = 1.84
    bm = bmesh.new()
    vs = [bm.verts.new((-w / 2, y, z)) for y, z in prof]
    face = bm.faces.new(vs)
    ret = bmesh.ops.extrude_face_region(bm, geom=[face])
    top = [g for g in ret["geom"] if isinstance(g, bmesh.types.BMVert)]
    bmesh.ops.translate(bm, vec=(w, 0, 0), verts=top)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    for v in bm.verts:               # cabine mais estreita e pontas levemente afuniladas
        if v.co.z > 1.0:
            v.co.x *= 0.86
        if abs(v.co.y) > 2.1:
            v.co.x *= 0.94
    bmesh.ops.bevel(bm, geom=bm.edges[:], offset=0.07, segments=3, profile=0.6, affect="EDGES", clamp_overlap=True)
    return new_obj("carroceria", bm, paint)


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    paint = material("paint", (0.9, 0.9, 0.9), 0.28, 0.5)
    glass = material("glass", (0.05, 0.08, 0.11), 0.05, 0.4)
    chrome = material("chrome", (0.75, 0.76, 0.8), 0.15, 1.0)
    rubber = material("rubber", (0.02, 0.02, 0.02), 0.9)
    dark = material("dark", (0.03, 0.03, 0.035), 0.7)
    head = material("light_front", (1.0, 0.97, 0.88), 0.2, 0.0, (1.0, 0.95, 0.8), 3.0)
    tail = material("light_rear", (0.7, 0.02, 0.02), 0.3, 0.0, (1.0, 0.05, 0.05), 2.5)
    plate = material("plate", (0.9, 0.9, 0.85), 0.5)

    objs = [body_shell(paint)]

    # vidros: para-brisa, vidro traseiro e janelas laterais (levemente à frente da carroceria)
    bm = bmesh.new()
    def quad(pts):
        bm.faces.new([bm.verts.new(p) for p in pts])
    quad([(-0.66, 0.52, 1.40), (0.66, 0.52, 1.40), (0.76, 1.10, 1.02), (-0.76, 1.10, 1.02)])      # para-brisa
    quad([(0.66, -1.00, 1.38), (-0.66, -1.00, 1.38), (-0.76, -1.62, 1.00), (0.76, -1.62, 1.00)])  # traseiro
    for sx in (-1, 1):
        x = 0.84 * sx
        pts = [(x, -1.30, 1.03), (x, -0.90, 1.36), (x, 0.42, 1.38), (x, 0.98, 1.04)]
        bm.faces.new([bm.verts.new(p) for p in (pts if sx > 0 else pts[::-1])])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bmesh.ops.translate(bm, vec=(0, 0, 0.004), verts=bm.verts[:])
    objs.append(new_obj("vidros", bm, glass))

    # faróis, lanternas, grade, placas, para-choques
    bm = bmesh.new()
    for sx in (-1, 1):
        box(bm, (0.62 * sx, 2.22, 0.72), (0.40, 0.10, 0.14))
    objs.append(new_obj("farois", bm, head))
    bm = bmesh.new()
    for sx in (-1, 1):
        box(bm, (0.66 * sx, -2.27, 0.78), (0.38, 0.08, 0.14))
    objs.append(new_obj("lanternas", bm, tail))
    bm = bmesh.new()
    box(bm, (0, 2.27, 0.60), (0.80, 0.06, 0.20))      # grade
    box(bm, (0, 0.0, 0.26), (1.60, 4.2, 0.12))        # assoalho escuro
    for sy in (-1, 1):
        for sx in (-1, 1):                            # caixas de roda (discos pretos atrás das rodas)
            cyl_x(bm, (0.89 * sx, 1.40 * sy, 0.38), 0.42, 0.06)
    objs.append(new_obj("escuro", bm, dark))
    bm = bmesh.new()
    box(bm, (0, 2.30, 0.40), (1.50, 0.08, 0.07))
    box(bm, (0, -2.33, 0.40), (1.50, 0.08, 0.07))
    box(bm, (0, 2.285, 0.78), (0.06, 0.04, 0.05))
    objs.append(new_obj("cromados", bm, chrome))
    bm = bmesh.new()
    box(bm, (0, 2.31, 0.52), (0.46, 0.02, 0.12))
    box(bm, (0, -2.32, 0.62), (0.46, 0.02, 0.12))
    objs.append(new_obj("placas", bm, plate))
    bm = bmesh.new()
    for sx in (-1, 1):                                # retrovisores
        box(bm, (1.00 * sx, 0.62, 1.10), (0.16, 0.10, 0.10))
    objs.append(new_obj("retrovisores", bm, paint))

    bpy.ops.object.select_all(action="DESELECT")
    for ob in objs:
        ob.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.join()
    car = bpy.context.view_layer.objects.active
    car.name = "Carro"
    os.makedirs(OUT, exist_ok=True)
    car_path = os.path.join(OUT, "car_body.glb")
    bpy.ops.export_scene.gltf(filepath=car_path, export_format="GLB", export_yup=True)
    print("carro exportado:", car_path, os.path.getsize(car_path), "bytes")

    # roda: pneu, aro e calota (simétrica, para servir dos dois lados)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete()
    parts = []
    bm = bmesh.new()
    cyl_x(bm, (0, 0, 0), 0.35, 0.24, 32)
    cyl_x(bm, (0, 0, 0), 0.30, 0.255, 32)             # ressalto do pneu
    parts.append(new_obj("pneu", bm, rubber))
    bm = bmesh.new()
    cyl_x(bm, (0, 0, 0), 0.21, 0.26, 24)
    parts.append(new_obj("aro", bm, chrome))
    bm = bmesh.new()
    for i in range(5):                                # raios do aro
        a = 2 * math.pi * i / 5
        box(bm, (0, 0.11 * math.cos(a), 0.11 * math.sin(a)), (0.275, 0.05, 0.05))
    cyl_x(bm, (0, 0, 0), 0.05, 0.28, 12)
    parts.append(new_obj("cubo", bm, dark))
    bpy.ops.object.select_all(action="DESELECT")
    for ob in parts:
        ob.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()
    bpy.context.view_layer.objects.active.name = "Roda"
    wheel_path = os.path.join(OUT, "car_wheel.glb")
    bpy.ops.export_scene.gltf(filepath=wheel_path, export_format="GLB", export_yup=True)
    print("roda exportada:", wheel_path, os.path.getsize(wheel_path), "bytes")


main()
