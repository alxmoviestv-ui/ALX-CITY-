"""
bake_city_gi.py - roda DENTRO do Blender (sem interface). Refaz com o Cycles a iluminação gravada dos
pedaços da cidade (city_solid_*_lit.obj): luz do céu com quique nas paredes (iluminação global), sem sol,
então vale para qualquer hora do dia. Reescreve só as cores de vértice; se algo falhar, os arquivos
gravados pelo Python (tools/bake_city.py) continuam valendo.

Uso: blender -b -P tools/blender/bake_city_gi.py -- game/city
"""
import glob
import math
import os
import re
import sys
import time

import bpy

SAMPLES = 24
ALBEDO = 0.6


def key_of(path):
    m = re.search(r"city_(?:solid|deco)_(\d+)_(\d+)", os.path.basename(path))
    return (int(m.group(1)), int(m.group(2))) if m else None


def import_obj(path):
    before = set(bpy.data.objects)
    bpy.ops.wm.obj_import(filepath=path, forward_axis="NEGATIVE_Z", up_axis="Y")
    return [o for o in bpy.data.objects if o not in before and o.type == "MESH"]


def main():
    folder = sys.argv[sys.argv.index("--") + 1]
    lit_files = sorted(glob.glob(os.path.join(folder, "city_solid_*_lit.obj")))
    if not lit_files:
        print("nenhum *_lit.obj, nada a fazer")
        return
    lit_keys = {key_of(p) for p in lit_files}

    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene

    # material branco difuso (só a iluminação importa)
    white = bpy.data.materials.new("branco")
    white.use_nodes = True
    bsdf = white.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (ALBEDO, ALBEDO, ALBEDO, 1.0)
    bsdf.inputs["Roughness"].default_value = 1.0

    # céu uniforme branco
    world = bpy.data.worlds.new("ceu")
    world.use_nodes = True
    bg = world.node_tree.nodes["Background"]
    bg.inputs["Color"].default_value = (1.0, 1.0, 1.0, 1.0)
    bg.inputs["Strength"].default_value = 1.0
    scene.world = world

    # pedaços a gravar
    baked = {}
    for p in lit_files:
        objs = import_obj(p)
        names = {}
        for o in objs:
            names[o.name] = o.material_slots[0].material.name if o.material_slots else "branco"
        baked[p] = (objs, names)
    # oclusores: decoração e pedaços sólidos vizinhos (±1)
    near = set()
    for (i, j) in lit_keys:
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                near.add((i + di, j + dj))
    occluders = []
    for p in sorted(glob.glob(os.path.join(folder, "city_deco_*[0-9].obj")) +
                    glob.glob(os.path.join(folder, "city_solid_*[0-9].obj"))):
        k = key_of(p)
        if k in near and not (os.path.basename(p).startswith("city_solid") and k in lit_keys):
            occluders += import_obj(p)
    for o in occluders:
        o.data.materials.clear()
        o.data.materials.append(white)
    targets = []
    for objs, _names in baked.values():
        for o in objs:
            o.data.materials.clear()
            o.data.materials.append(white)
            attr = o.data.color_attributes.new(name="luz", type="FLOAT_COLOR", domain="POINT")
            o.data.color_attributes.active_color = attr
            targets.append(o)
    print("pedaços:", len(lit_files), " objetos a gravar:", len(targets), " oclusores:", len(occluders))

    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = SAMPLES
    scene.cycles.use_denoising = False
    scene.cycles.max_bounces = 3
    scene.cycles.diffuse_bounces = 3
    scene.render.bake.target = "VERTEX_COLORS"
    scene.render.bake.use_pass_direct = True
    scene.render.bake.use_pass_indirect = True
    scene.render.bake.use_pass_color = False

    bpy.ops.object.select_all(action="DESELECT")
    for o in targets:
        o.select_set(True)
    bpy.context.view_layer.objects.active = targets[0]
    t0 = time.time()
    bpy.ops.object.bake(type="DIFFUSE", pass_filter={"DIRECT", "INDIRECT"}, target="VERTEX_COLORS")
    print("bake concluído em %.0f s" % (time.time() - t0))

    # reescreve cada *_lit.obj (eixos: Blender Z-up -> OBJ Y-up)
    for p, (objs, names) in baked.items():
        v_lines, vt_lines, vn_lines, groups = [], [], [], []
        vcount = 0
        for o in objs:
            me = o.data
            attr = me.color_attributes.get("luz")
            uvl = me.uv_layers.active
            lines = []
            for poly in me.polygons:
                ids = []
                n = poly.normal
                vn_lines.append("vn %.2f %.2f %.2f\n" % (n.x, n.z, -n.y))
                ni = len(vn_lines)
                for li in poly.loop_indices:
                    vi = me.loops[li].vertex_index
                    co = me.vertices[vi].co
                    c = attr.data[vi].color
                    lum = (c[0] + c[1] + c[2]) / 3.0 / ALBEDO
                    shade = 0.45 + 0.55 * max(0.0, min(1.0, lum)) ** 0.8
                    v_lines.append("v %.2f %.2f %.2f %.2f %.2f %.2f\n" % (co.x, co.z, -co.y, shade, shade, shade))
                    uv = uvl.data[li].uv if uvl else (0.0, 0.0)
                    vt_lines.append("vt %.3f %.3f\n" % (uv[0], uv[1]))
                    vcount += 1
                    ids.append(vcount)
                for k in range(1, len(ids) - 1):
                    lines.append("f %d/%d/%d %d/%d/%d %d/%d/%d\n" % (ids[0], ids[0], ni, ids[k], ids[k], ni,
                                                                        ids[k + 1], ids[k + 1], ni))
            mat = re.sub(r"\.\d+$", "", names.get(o.name, "branco"))
            groups.append((mat, lines))
        base = os.path.basename(p)[:-8]  # sem "_lit.obj"
        tmp = p + ".tmp"
        with open(tmp, "w") as f:
            f.write("mtllib %s.mtl\n" % base)
            f.writelines(v_lines)
            f.writelines(vt_lines)
            f.writelines(vn_lines)
            for mat, lines in groups:
                f.write("o %s\nusemtl %s\n" % (mat, mat))
                f.writelines(lines)
        os.replace(tmp, p)
        print("regravado:", os.path.basename(p))


main()
