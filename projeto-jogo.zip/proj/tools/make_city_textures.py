#!/usr/bin/env python3
"""Gera as texturas da cidade em tools/textures_city/. Requer numpy + pillow.
Prédios: cada textura cobre 6,4 m x 6,4 m (2 andares de 3,2 m, 2 janelas por andar)."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_textures as mt  # noqa: E402
from make_textures import N, rgb, fnoise, shade, yy, xx, rng  # noqa: E402
from PIL import Image  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "textures_city")
os.makedirs(OUT, exist_ok=True)


def save(name, img):
    img = np.clip(img, 0, 1)
    Image.fromarray((img * 255).astype(np.uint8)).save(os.path.join(OUT, name + ".png"), optimize=True)
    print("ok", name)


def rect(img, x0, y0, x1, y1, color):
    img[y0:y1, x0:x1] = color


def _wear(img, seed):
    """Remendos, rachaduras e bueiros no asfalto (img: array HxWx3 em 0..1)."""
    from PIL import ImageDraw
    r = np.random.default_rng(seed)
    pil = Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8))
    d = ImageDraw.Draw(pil, "RGBA")
    for _ in range(5):                      # remendos
        x, y = int(r.integers(0, N - 90)), int(r.integers(0, N - 90))
        w, h = int(r.integers(40, 90)), int(r.integers(30, 80))
        d.rectangle([x, y, x + w, y + h], fill=(14, 14, 15, 70))
    for _ in range(7):                      # rachaduras
        x, y = float(r.integers(0, N)), float(r.integers(0, N))
        pts = [(x, y)]
        for _k in range(int(r.integers(4, 9))):
            x += float(r.normal(0, 18))
            y += float(r.normal(0, 18))
            pts.append((x, y))
        d.line(pts, fill=(8, 8, 9, 200), width=1)
    for _ in range(2):                      # bueiros
        x, y = int(r.integers(60, N - 60)), int(r.integers(60, N - 60))
        d.ellipse([x - 16, y - 16, x + 16, y + 16], fill=(38, 38, 40, 255), outline=(20, 20, 22, 255))
        d.ellipse([x - 11, y - 11, x + 11, y + 11], outline=(60, 60, 62, 255))
    return np.asarray(pil).astype(np.float32) / 255.0


def road():
    # rua local: 14 m de largura = 512 px (36,6 px/m); u atravessa a rua
    img = mt.asphalt() * 1.0
    ppm = N / 14.0

    def line(xc_m, w_m, color):
        a = int((xc_m - w_m / 2) * ppm)
        b = int((xc_m + w_m / 2) * ppm) + 1
        img[:, a:b] = color * (0.9 + 0.1 * fnoise(0.5)[:, a:b, None])

    white, yellow = rgb((0.85, 0.85, 0.82)), rgb((0.85, 0.68, 0.12))
    for xc in (3.8, 5.7, 8.3, 10.2):        # desgaste de pneus
        a, b = int((xc - 0.35) * ppm), int((xc + 0.35) * ppm)
        img[:, a:b] *= 0.93
    img = _wear(img, 11)
    line(2.5, 0.15, white)
    line(11.5, 0.15, white)
    line(6.85, 0.12, yellow)
    line(7.15, 0.12, yellow)
    dash = ((yy // 64) % 2 == 0)
    for xc in (4.75, 9.25):
        a, b = int((xc - 0.07) * ppm), int((xc + 0.07) * ppm) + 1
        sel = dash[:, a:b, None]
        img[:, a:b] = np.where(sel, white * 0.9, img[:, a:b])
    return img


def avenue():
    # avenida: 24 m = 512 px (21,3 px/m): estacionamento 2,5 | 2 faixas de 4 | canteiro 2 | 2 faixas | 2,5
    img = mt.asphalt() * 1.0
    ppm = N / 24.0

    def line(xc_m, w_m, color):
        a = int((xc_m - w_m / 2) * ppm)
        b = int((xc_m + w_m / 2) * ppm) + 1
        img[:, a:b] = color * (0.9 + 0.1 * fnoise(0.5)[:, a:b, None])

    white, yellow = rgb((0.85, 0.85, 0.82)), rgb((0.85, 0.68, 0.12))
    for xc in (4.5, 8.5, 15.5, 19.5):
        a, b = int((xc - 0.4) * ppm), int((xc + 0.4) * ppm)
        img[:, a:b] *= 0.93
    img = _wear(img, 23)
    line(2.5, 0.15, white)
    line(21.5, 0.15, white)
    line(10.8, 0.15, yellow)                # ao lado do canteiro (que cobre 11 a 13 m)
    line(13.2, 0.15, yellow)
    dash = ((yy // 64) % 2 == 0)
    for xc in (6.5, 17.5):
        a, b = int((xc - 0.08) * ppm), int((xc + 0.08) * ppm) + 1
        sel = dash[:, a:b, None]
        img[:, a:b] = np.where(sel, white * 0.9, img[:, a:b])
    return img


def crosswalk():
    img = mt.asphalt() * 1.0
    bars = 12
    w = N / (bars * 2)
    idx = (xx // w).astype(int)
    on = (idx % 2 == 0)
    white = rgb((0.88, 0.88, 0.85)) * (0.85 + 0.15 * fnoise(0.8)[..., None])
    return np.where(on[..., None], white, img)


def sidewalk():
    img = mt.concrete() * rgb((1.05, 1.05, 1.03))
    slab = N / 2
    joint = ((xx % slab) < 2.5) | ((yy % slab) < 2.5)
    return np.where(joint[..., None], img * 0.55, img)


def leaves():
    base = mt.shade(rgb((0.20, 0.42, 0.14)), 0.5, 1.2, 0.3)
    spots = (rng.random((N, N)) > 0.97)[..., None] * 0.12
    return base * (0.85 + 0.3 * fnoise(1.0)[..., None]) + spots * rgb((0.3, 0.4, 0.1))


def bark():
    s = mt.streaks(False, 0.02)[..., None]
    return rgb((0.28, 0.19, 0.12)) * (0.6 + 0.8 * s)


def roof():
    img = mt.shade(rgb((0.30, 0.30, 0.31)), 0.18, 0.9, 0.25)
    patches = fnoise(3.0)[..., None]
    return img * (0.9 + 0.2 * patches)


# ------------------------------------------------------------- fachadas
# H = relevo (0..1) e E = emissão (janelas acesas) de cada textura de prédio.
H = np.zeros((N, N), np.float32)
E = np.zeros((N, N, 3), np.float32)
WARM = [(1.0, 0.80, 0.48), (1.0, 0.90, 0.70), (0.85, 0.92, 1.0), (1.0, 0.70, 0.40)]


def reset(h0=0.5):
    H[:] = h0
    E[:] = 0


def window(img, cx, cy, w=150, h=140, frame=9, glass=((0.40, 0.55, 0.66), (0.10, 0.17, 0.25)),
           frame_color=(0.88, 0.87, 0.83), sill=True, lit_prob=0.35):
    x0, x1, y0, y1 = cx - w // 2, cx + w // 2, cy - h // 2, cy + h // 2
    rect(img, x0, y0, x1, y1, rgb(frame_color))
    H[y0:y1, x0:x1] = 0.62
    gx0, gx1, gy0, gy1 = x0 + frame, x1 - frame, y0 + frame, y1 - frame
    hh = gy1 - gy0
    grad = np.linspace(0, 1, hh, dtype=np.float32)[:, None, None]
    img[gy0:gy1, gx0:gx1] = rgb(glass[0]) * (1 - grad) + rgb(glass[1]) * grad
    H[gy0:gy1, gx0:gx1] = 0.10
    gw = gx1 - gx0
    streak = np.exp(-((np.arange(gw)[None, :] + np.arange(hh)[:, None] - gw * 0.55) ** 2) / (2 * 18 ** 2))
    img[gy0:gy1, gx0:gx1] += streak[..., None].astype(np.float32) * 0.12
    mx = (gx0 + gx1) // 2
    rect(img, mx - 2, gy0, mx + 2, gy1, rgb(frame_color))
    H[gy0:gy1, mx - 2:mx + 2] = 0.62
    if sill:
        rect(img, x0 - 8, y1, x1 + 8, y1 + 7, rgb(frame_color) * 0.9)
        rect(img, x0 - 8, y1 + 7, x1 + 8, y1 + 11, rgb(frame_color) * 0.45)
        H[y1:y1 + 7, x0 - 8:x1 + 8] = 0.90
    if rng.random() < lit_prob:
        c = rgb(WARM[int(rng.integers(0, len(WARM)))]) * float(rng.uniform(0.55, 1.0))
        E[gy0:gy1, gx0:gx1] = c * (0.6 + 0.4 * (1 - grad))
    return img


def two_floor_windows(img, **kw):
    for fy in (128, 384):
        for fx in (128, 384):
            window(img, fx, fy, **kw)
    return img


def b_brick():
    reset()
    img = mt.brick() * 1.0
    mortar = (img[..., 0] - img[..., 2]) < 0.15
    H[:] = np.where(mortar, 0.22, 0.55 + 0.12 * fnoise(1.5))
    return two_floor_windows(img.copy())


def b_concrete():
    reset()
    img = mt.concrete() * rgb((1.0, 1.0, 1.02))
    img = img.copy()
    H[:] = 0.45 + 0.25 * fnoise(2.0)
    for y in (0, 255):
        rect(img, 0, y, N, y + 3, img[y:y + 3] * 0.6)
        H[y:y + 3, :] = 0.15
    return two_floor_windows(img, frame_color=(0.28, 0.30, 0.33), glass=((0.35, 0.5, 0.6), (0.08, 0.12, 0.18)))


def b_office():
    reset()
    img = mt.plaster() * rgb((1.0, 0.97, 0.9))
    img = img.copy()
    H[:] = 0.5 + 0.1 * fnoise(2.2)
    for fy in (128, 384):
        rect(img, 0, fy - 60, N, fy + 60, rgb((0.2, 0.24, 0.28)))
        H[fy - 60:fy + 60, :] = 0.35
        grad = np.linspace(0, 1, 112, dtype=np.float32)[:, None, None]
        g = rgb((0.42, 0.58, 0.70)) * (1 - grad) + rgb((0.10, 0.16, 0.24)) * grad
        for px in range(0, N, 128):
            img[fy - 56:fy + 56, px + 6:px + 122] = g
            H[fy - 56:fy + 56, px + 6:px + 122] = 0.08
            if rng.random() < 0.35:
                E[fy - 56:fy + 56, px + 6:px + 122] = rgb(WARM[int(rng.integers(0, 4))]) * float(rng.uniform(0.5, 1.0))
        rect(img, 0, fy + 60, N, fy + 70, rgb((0.82, 0.80, 0.74)))
        H[fy + 60:fy + 70, :] = 0.85
    return img


def b_glass():
    reset()
    img = np.zeros((N, N, 3), np.float32)
    panel = 128
    colors = [((0.38, 0.55, 0.66), (0.14, 0.26, 0.36)), ((0.30, 0.48, 0.60), (0.10, 0.20, 0.30)),
              ((0.45, 0.62, 0.72), (0.18, 0.30, 0.40))]
    for gy in range(0, N, panel):
        for gx in range(0, N, panel):
            c = colors[rng.integers(0, 3)]
            grad = np.linspace(0, 1, panel, dtype=np.float32)[:, None, None]
            img[gy:gy + panel, gx:gx + panel] = rgb(c[0]) * (1 - grad) + rgb(c[1]) * grad
            H[gy:gy + panel, gx:gx + panel] = 0.30
            if rng.random() < 0.3 and (gy % 256) < 128:
                E[gy:gy + panel, gx:gx + panel] = rgb(WARM[int(rng.integers(0, 4))]) * float(rng.uniform(0.5, 0.95))
    streak = np.exp(-(((xx + yy) % 256 - 110) ** 2) / (2 * 22 ** 2))[..., None] * 0.10
    img = img + streak
    dark = rgb((0.12, 0.13, 0.15))
    for p in range(0, N, panel):
        rect(img, p, 0, p + 4, N, dark)
        rect(img, 0, p, N, p + 4, dark)
        H[:, p:p + 4] = 0.85
        H[p:p + 4, :] = 0.85
    for fy in (0, 256):
        rect(img, 0, fy + 224, N, fy + 256, rgb((0.35, 0.37, 0.40)))
        H[fy + 224:fy + 256, :] = 0.6
        E[fy + 224:fy + 256, :] = 0
    return img


def b_shop():
    reset()
    img = mt.plaster() * rgb((0.9, 0.86, 0.8))
    img = img.copy()
    H[:] = 0.5 + 0.1 * fnoise(2.2)
    base = 256
    rect(img, 0, base, N, N, rgb((0.18, 0.16, 0.15)))
    H[base:, :] = 0.6
    rect(img, 0, base, N, base + 40, rgb((0.32, 0.26, 0.22)))
    H[base:base + 40, :] = 0.8
    rect(img, 0, N - 26, N, N, rgb((0.24, 0.24, 0.25)))
    for cx in (128, 384):
        x0, x1, y0, y1 = cx - 110, cx + 110, base + 50, N - 30
        rect(img, x0, y0, x1, y1, rgb((0.1, 0.09, 0.08)))
        gh = y1 - y0 - 12
        grad = np.linspace(0, 1, gh, dtype=np.float32)[:, None, None]
        img[y0 + 6:y1 - 6, x0 + 6:x1 - 6] = (rgb((0.42, 0.56, 0.66)) * (1 - grad) + rgb((0.12, 0.18, 0.26)) * grad)
        H[y0:y1, x0:x1] = 0.7
        H[y0 + 6:y1 - 6, x0 + 6:x1 - 6] = 0.10
        E[y0 + 6:y1 - 6, x0 + 6:x1 - 6] = rgb((1.0, 0.86, 0.6)) * 0.9 * (0.6 + 0.4 * (1 - grad))
    rect(img, 252, base + 50, 260, N - 30, rgb((0.14, 0.12, 0.1)))
    H[base + 50:N - 30, 252:260] = 0.8
    E[base + 50:N - 30, 252:260] = 0
    return img


def b_roof_tex():
    reset()
    img = roof()
    H[:] = 0.4 + 0.4 * fnoise(0.8)
    return img


def roof_tile():
    reset()
    rows, tw = 24, 32
    rh = N / rows
    row = np.floor(yy / rh).astype(int)
    off = (row % 2) * (tw / 2)
    xs = (xx + off) % N
    col = (xs // tw).astype(int)
    v = rng.random((rows, N // tw + 1)).astype(np.float32)[row, col]
    base = rgb((0.55, 0.22, 0.15)) * (0.75 + 0.5 * v[..., None]) * (0.9 + 0.2 * fnoise(1.5)[..., None])
    edge = ((yy % rh) < 3) | ((xs % tw) < 2)
    H[:] = np.where(edge, 0.2, 0.6 + 0.2 * ((yy % rh) / rh))
    return np.where(edge[..., None], base * 0.45, base)


def pine():
    reset()
    return mt.shade(rgb((0.07, 0.22, 0.09)), 0.5, 1.0, 0.4)


def leafcard():
    """RGBA: cacho de folhas com fundo transparente (usado em cartões cruzados nas copas)."""
    from PIL import ImageDraw
    pil = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    d = ImageDraw.Draw(pil)
    r = np.random.default_rng(5)
    for layer, (n_leaves, light) in enumerate(((260, 0.55), (300, 0.8), (240, 1.0))):
        for _ in range(n_leaves):
            ang = r.uniform(0, 2 * np.pi)
            rad = 232 * np.sqrt(r.uniform(0, 1)) * (0.95 - 0.1 * layer)
            cx, cy = 256 + rad * np.cos(ang), 256 + rad * np.sin(ang)
            ln, wd = r.uniform(22, 40), r.uniform(10, 17)
            rot = r.uniform(0, np.pi)
            pts = []
            for t in np.linspace(0, 2 * np.pi, 10, endpoint=False):
                px, py = ln * np.cos(t), wd * np.sin(t)
                pts.append((cx + px * np.cos(rot) - py * np.sin(rot), cy + px * np.sin(rot) + py * np.cos(rot)))
            g = r.uniform(0.75, 1.15) * light
            col = (int(min(255, 40 * g + r.uniform(0, 25))), int(min(255, 105 * g + r.uniform(0, 40))), int(min(255, 32 * g)), 255)
            d.polygon(pts, fill=col)
    return pil


def b_stucco():
    """Reboco pintado com janelas e venezianas (a cor vem do tom aplicado ao material)."""
    reset()
    img = mt.plaster() * rgb((1.0, 0.98, 0.94))
    img = img.copy()
    H[:] = 0.5 + 0.12 * fnoise(2.4)
    for fy in (128, 384):
        for fx in (128, 384):
            for side in (-1, 1):  # venezianas
                x0 = fx + side * 75 - 14
                rect(img, x0, fy - 66, x0 + 28, fy + 66, rgb((0.55, 0.62, 0.55)))
                H[fy - 66:fy + 66, x0:x0 + 28] = 0.7
                for yy2 in range(fy - 62, fy + 62, 9):
                    img[yy2:yy2 + 2, x0:x0 + 28] *= 0.7
                    H[yy2:yy2 + 2, x0:x0 + 28] = 0.45
            window(img, fx, fy, w=120, h=132, frame=8, lit_prob=0.4)
    return img


def b_shop2():
    """Térreo com porta central e duas vitrines."""
    reset()
    img = mt.brick() * rgb((0.8, 0.75, 0.7))
    img = img.copy()
    H[:] = 0.5
    base = 256
    rect(img, 0, base, N, N, rgb((0.16, 0.15, 0.14)))
    H[base:, :] = 0.6
    rect(img, 0, base, N, base + 44, rgb((0.10, 0.12, 0.16)))      # faixa do letreiro
    H[base:base + 44, :] = 0.8
    rect(img, 150, base + 8, 362, base + 36, rgb((0.85, 0.8, 0.65)))  # "letreiro"
    E[base + 8:base + 36, 150:362] = rgb((1.0, 0.85, 0.5)) * 0.8
    for x0, x1 in ((20, 176), (336, 492)):                           # vitrines
        rect(img, x0, base + 56, x1, N - 24, rgb((0.1, 0.09, 0.08)))
        gh = (N - 24 - 6) - (base + 62)
        grad = np.linspace(0, 1, gh, dtype=np.float32)[:, None, None]
        img[base + 62:N - 30, x0 + 6:x1 - 6] = rgb((0.45, 0.58, 0.68)) * (1 - grad) + rgb((0.14, 0.2, 0.28)) * grad
        H[base + 56:N - 24, x0:x1] = 0.7
        H[base + 62:N - 30, x0 + 6:x1 - 6] = 0.1
        E[base + 62:N - 30, x0 + 6:x1 - 6] = rgb((1.0, 0.88, 0.62)) * 0.75
    rect(img, 206, base + 56, 306, N - 4, rgb((0.32, 0.2, 0.12)))    # porta de madeira
    rect(img, 218, base + 70, 294, base + 150, rgb((0.35, 0.5, 0.6)))
    H[base + 56:N - 4, 206:306] = 0.75
    H[base + 70:base + 150, 218:294] = 0.15
    return img


def leaf_cluster(seed, ln_rng, wd_rng, greens, n_layers=(260, 300, 240)):
    from PIL import ImageDraw
    pil = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    d = ImageDraw.Draw(pil)
    r = np.random.default_rng(seed)
    for layer, n_leaves in enumerate(n_layers):
        light = (0.55, 0.8, 1.0)[layer]
        for _ in range(n_leaves):
            ang = r.uniform(0, 2 * np.pi)
            rad = 232 * np.sqrt(r.uniform(0, 1)) * (0.95 - 0.1 * layer)
            cx, cy = 256 + rad * np.cos(ang), 256 + rad * np.sin(ang)
            ln, wd = r.uniform(*ln_rng), r.uniform(*wd_rng)
            rot = r.uniform(0, np.pi)
            pts = []
            for t in np.linspace(0, 2 * np.pi, 10, endpoint=False):
                px, py = ln * np.cos(t), wd * np.sin(t)
                pts.append((cx + px * np.cos(rot) - py * np.sin(rot), cy + px * np.sin(rot) + py * np.cos(rot)))
            g = greens[int(r.integers(0, len(greens)))]
            k = r.uniform(0.8, 1.15) * light
            col = (int(min(255, g[0] * k)), int(min(255, g[1] * k)), int(min(255, g[2] * k)), 255)
            d.polygon(pts, fill=col)
    return pil


def leafcard2():   # folhas pequenas e densas (tons claros)
    return leaf_cluster(11, (12, 20), (8, 13), [(70, 140, 40), (95, 160, 50), (55, 120, 35)], (420, 480, 380))


def leafcard3():   # folhas largas
    return leaf_cluster(23, (34, 56), (18, 30), [(45, 105, 30), (60, 125, 35), (35, 90, 28)], (150, 190, 150))


def siding():
    """Tábuas de madeira pintada (revestimento horizontal), 2,4 m por textura."""
    reset()
    rows = 16
    rh = N / rows
    row = np.floor(yy / rh).astype(int)
    v = rng.random(rows).astype(np.float32)[row]
    base = rgb((0.88, 0.87, 0.83)) * (0.94 + 0.08 * v[..., None]) * (0.96 + 0.06 * fnoise(0.8)[..., None])
    grain = mt.streaks(True, 0.01)[..., None]
    base = base * (0.95 + 0.07 * grain)
    edge = (yy % rh) < 3
    H[:] = np.where(edge, 0.15, 0.55 + 0.25 * ((yy % rh) / rh))
    return np.where(edge[..., None], base * 0.62, base)


def save_maps(name):
    h = H.copy()
    h = (h + np.roll(h, 1, 0) + np.roll(h, -1, 0) + np.roll(h, 1, 1) + np.roll(h, -1, 1)) / 5.0
    gx = (np.roll(h, -1, 1) - np.roll(h, 1, 1)) * 0.5
    gy = (np.roll(h, -1, 0) - np.roll(h, 1, 0)) * 0.5
    nx, ny, nz = -gx * 14.0, gy * 14.0, np.ones_like(h)
    L = np.sqrt(nx * nx + ny * ny + nz * nz)
    n = np.stack([nx / L, ny / L, nz / L], axis=-1) * 0.5 + 0.5
    Image.fromarray((n * 255).astype(np.uint8)).save(os.path.join(OUT, name + "_n.png"), optimize=True)
    if E.max() > 0:
        Image.fromarray((np.clip(E, 0, 1) * 255).astype(np.uint8)).save(os.path.join(OUT, name + "_e.png"), optimize=True)


TEX = dict(road=road, avenue=avenue, crosswalk=crosswalk, sidewalk=sidewalk, leaves=leaves, bark=bark,
           b_roof=b_roof_tex, b_brick=b_brick, b_concrete=b_concrete, b_office=b_office, b_glass=b_glass,
           b_shop=b_shop, roof_tile=roof_tile, pine=pine, b_stucco=b_stucco, b_shop2=b_shop2, siding=siding)
WITH_MAPS = {"siding", "b_stucco", "b_shop2", "b_roof", "b_brick", "b_concrete", "b_office", "b_glass", "b_shop", "roof_tile"}

if __name__ == "__main__":
    for k, fn in TEX.items():
        save(k, fn())
        if k in WITH_MAPS:
            save_maps(k)
    leafcard().save(os.path.join(OUT, "leafcard.png"), optimize=True)
    leafcard2().save(os.path.join(OUT, "leafcard2.png"), optimize=True)
    leafcard3().save(os.path.join(OUT, "leafcard3.png"), optimize=True)
    print("ok leafcard")
