"""Prédios detalhados e árvores para gen_city.py (as funções básicas vêm de gen_city via bind)."""
import math

NEEDED = ["box_flat", "wall", "ground_quad", "cylinder", "blob", "UP", "LY", "FLOOR", "GY"]


def bind(ns):
    globals().update({k: ns[k] for k in NEEDED})


def _norm(v):
    L = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
    return (v[0] / L, v[1] / L, v[2] / L)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


# ------------------------------------------------------------------ prédios
def ring_boxes(m, mat, x0, x1, z0, z1, y0, y1, t, out=0.0):
    x0, x1, z0, z1 = x0 - out, x1 + out, z0 - out, z1 + out
    box_flat(m, mat, x0, x1, y0, y1, z0, z0 + t)
    box_flat(m, mat, x0, x1, y0, y1, z1 - t, z1)
    box_flat(m, mat, x0, x0 + t, y0, y1, z0 + t, z1 - t)
    box_flat(m, mat, x1 - t, x1, y0, y1, z0 + t, z1 - t)


def obox(m, mat, p, u, n, w, d, y0, y1, bottom=False):
    """Caixa orientada: centro p na parede, u ao longo da parede, n para fora (ambos em XZ)."""
    def P(s, t, y):
        return (p[0] + u[0] * s + n[0] * t, y, p[1] + u[1] * s + n[1] * t)
    hw = w / 2
    z = [(0, 0)] * 4
    m.poly(mat, [P(-hw, 0, y1), P(hw, 0, y1), P(hw, d, y1), P(-hw, d, y1)], z, UP)
    m.poly(mat, [P(-hw, d, y0), P(hw, d, y0), P(hw, d, y1), P(-hw, d, y1)], z, (n[0], 0, n[1]))
    m.poly(mat, [P(-hw, 0, y0), P(-hw, d, y0), P(-hw, d, y1), P(-hw, 0, y1)], z, (-u[0], 0, -u[1]))
    m.poly(mat, [P(hw, 0, y0), P(hw, d, y0), P(hw, d, y1), P(hw, 0, y1)], z, (u[0], 0, u[1]))
    if bottom:
        m.poly(mat, [P(-hw, 0, y0), P(hw, 0, y0), P(hw, d, y0), P(-hw, d, y0)], z, (0, -1, 0))


def awnings(deco, rnd, a, b, n, y_top):
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    ux, uz = (b[0] - a[0]) / L, (b[1] - a[1]) / L
    mat = rnd.choice(["awning_red", "awning_blue", "awning_green", "awning_yellow"])
    c = 1.6
    while c < L - 1.5:
        if rnd.random() < 0.85:
            xa, za = a[0] + ux * (c - 1.5), a[1] + uz * (c - 1.5)
            xb, zb = a[0] + ux * (c + 1.5), a[1] + uz * (c + 1.5)
            pts = [(xa + n[0] * 0.05, y_top, za + n[2] * 0.05), (xb + n[0] * 0.05, y_top, zb + n[2] * 0.05),
                   (xb + n[0] * 1.5, y_top - 0.45, zb + n[2] * 1.5), (xa + n[0] * 1.5, y_top - 0.45, za + n[2] * 1.5)]
            deco.poly(mat, pts, [(0, 0)] * 4, (n[0] * 0.3, 0.95, n[2] * 0.3))
        c += 3.2


def balconies(deco, rnd, a, b, n, f0, f1):
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
    nn = (n[0], n[2])
    for k in range(max(f0, 1), f1):
        y = LY + k * FLOOR
        c = 1.6 + 3.2 * (k % 2)
        while c < L - 1.6:
            p = (a[0] + u[0] * c, a[1] + u[1] * c)
            obox(deco, "ledge", p, u, nn, 2.4, 0.9, y, y + 0.12, bottom=True)
            obox(deco, "metal_gray", (p[0] + nn[0] * 0.87, p[1] + nn[1] * 0.87), u, nn, 2.4, 0.04, y + 0.12, y + 1.05)
            for sgn in (-1, 1):
                q = (p[0] + u[0] * sgn * 1.18, p[1] + u[1] * sgn * 1.18)
                obox(deco, "metal_gray", q, nn, u, 0.04, 0.9, y + 0.12, y + 1.05)
            c += 6.4


def roof_gear(deco, rnd, rect, top, floors, detail):
    x0, x1, z0, z1 = rect
    if (x1 - x0) < 8 or (z1 - z0) < 8:
        return

    def spot(margin=2.6):
        return rnd.uniform(x0 + margin, x1 - margin), rnd.uniform(z0 + margin, z1 - margin)
    for _ in range(rnd.randint(1, 4 if detail else 2)):
        cx, cz = spot()
        w, d, h = rnd.uniform(1.2, 2.4), rnd.uniform(0.8, 1.4), rnd.uniform(1.0, 1.9)
        box_flat(deco, "metal_gray", cx - w / 2, cx + w / 2, top, top + h, cz - d / 2, cz + d / 2)
    if rnd.random() < 0.6:
        cx, cz = spot(3.5)
        box_flat(deco, "ledge", cx - 1.6, cx + 1.6, top, top + 2.6, cz - 1.6, cz + 1.6)
    if detail and floors >= 4 and rnd.random() < 0.4:
        cx, cz = spot(3.5)
        for lx, lz in ((-0.9, -0.9), (0.9, -0.9), (-0.9, 0.9), (0.9, 0.9)):
            box_flat(deco, "lamp_metal", cx + lx - 0.06, cx + lx + 0.06, top, top + 1.5, cz + lz - 0.06, cz + lz + 0.06)
        cylinder(deco, "tank", cx, cz, top + 1.5, top + 3.7, 1.35, 8)
    if detail and floors >= 10 and rnd.random() < 0.65:
        cx, cz = spot(3.0)
        cylinder(deco, "lamp_metal", cx, cz, top, top + 11.0, 0.09, 5, cap=False)
        for yy_, ww in ((top + 8.0, 1.6), (top + 9.5, 1.0)):
            box_flat(deco, "lamp_metal", cx - ww, cx + ww, yy_, yy_ + 0.06, cz - 0.03, cz + 0.03)
        box_flat(deco, "tl_red", cx - 0.12, cx + 0.12, top + 11.0, top + 11.25, cz - 0.12, cz + 0.12)


def gable_roof(solid, rect, top, mat_wall, roof_mat="roof_tile", ov=0.45):
    x0, x1, z0, z1 = rect
    along_x = (x1 - x0) >= (z1 - z0)
    w = (z1 - z0) if along_x else (x1 - x0)
    h = 0.3 * w

    def P(u, y, v):
        return (u, y, v) if along_x else (v, y, u)
    ua, ub = (x0, x1) if along_x else (z0, z1)
    va, vb = (z0, z1) if along_x else (x0, x1)
    vm = (va + vb) / 2
    t = 2.4
    for v_edge, sgn in ((va - ov, -1), (vb + ov, 1)):
        pts = [P(ua - ov, top, v_edge), P(ub + ov, top, v_edge), P(ub + ov, top + h, vm), P(ua - ov, top + h, vm)]
        uvs = [((ua - ov) / t, 0), ((ub + ov) / t, 0), ((ub + ov) / t, h / t * 1.2), ((ua - ov) / t, h / t * 1.2)]
        nrm = (0, 0.7, sgn * 0.7) if along_x else (sgn * 0.7, 0.7, 0)
        solid.poly(roof_mat, pts, uvs, nrm)
    for u_edge, sgn in ((ua, -1), (ub, 1)):
        pts = [P(u_edge, top, va), P(u_edge, top, vb), P(u_edge, top + h, vm)]
        nrm = (sgn, 0, 0) if along_x else (0, 0, sgn)
        solid.poly(mat_wall, pts, [(va / 6.4, 0), (vb / 6.4, 0), (vm / 6.4, h / 6.4)], nrm)
    return top + h


def build_building(solid, deco, rnd, rect, floors, style, shop_var, var, detail):
    x0, x1, z0, z1 = rect
    mat_up = f"{style}_{var}"
    mat_shop = ("b_shop2_" if rnd.random() < 0.4 else "b_shop_") + str(shop_var)
    tiers = [((x0, x1, z0, z1), 0, floors)]
    if floors >= 8 and rnd.random() < 0.55:
        base = rnd.randint(3, 5)
        w, d = x1 - x0, z1 - z0
        sh = [round(rnd.uniform(0.0, 0.3) * (w if k < 2 else d) / 1.6) * 1.6 for k in range(4)]
        if w - sh[0] - sh[1] < 9.6:
            sh[0] = sh[1] = 0
        if d - sh[2] - sh[3] < 9.6:
            sh[2] = sh[3] = 0
        tiers = [((x0, x1, z0, z1), 0, base), ((x0 + sh[0], x1 - sh[1], z0 + sh[2], z1 - sh[3]), base, floors)]
    gable = floors <= 3 and len(tiers) == 1 and rnd.random() < 0.4
    brick_like = style in ("b_brick", "b_concrete", "b_stucco")
    for ti, ((rx0, rx1, rz0, rz1), f0, f1) in enumerate(tiers):
        sides = [((rx0, rz0), (rx1, rz0), (0, 0, -1)), ((rx1, rz1), (rx0, rz1), (0, 0, 1)),
                 ((rx0, rz1), (rx0, rz0), (-1, 0, 0)), ((rx1, rz0), (rx1, rz1), (1, 0, 0))]
        for si, (a, b, n) in enumerate(sides):
            uoff = rnd.choice([0.0, 0.5])
            y_start = LY + f0 * FLOOR
            if f0 == 0:
                wall(solid, mat_shop, a, b, y_start, y_start + FLOOR, n, 1 / 6.4, 0.0, 0.5 / FLOOR, uoff)
                if f1 > 1:
                    wall(solid, mat_up, a, b, y_start + FLOOR, LY + f1 * FLOOR, n, 1 / 6.4, 0.5, 0.5 / FLOOR, uoff)
                if detail and rnd.random() < 0.6:
                    awnings(deco, rnd, a, b, n, LY + 2.95)
            else:
                v0 = 0.5 * (f0 % 2)
                wall(solid, mat_up, a, b, y_start, LY + f1 * FLOOR, n, 1 / 6.4, v0, 0.5 / FLOOR, uoff)
            if detail >= 2 and brick_like and 3 <= floors <= 12 and si == 0:
                balconies(deco, rnd, a, b, n, f0, f1)
        top = LY + f1 * FLOOR
        if detail and brick_like:
            for k in range(max(f0, 1), f1):
                ring_boxes(solid, "ledge", rx0, rx1, rz0, rz1, LY + k * FLOOR - 0.12, LY + k * FLOOR + 0.16, 0.14, 0.14)
        if detail:
            for cx_, cz_ in ((rx0, rz0), (rx1, rz0), (rx0, rz1), (rx1, rz1)):
                box_flat(solid, "ledge", cx_ - 0.35, cx_ + 0.35, LY + f0 * FLOOR, top, cz_ - 0.35, cz_ + 0.35)
        last = ti == len(tiers) - 1
        if gable and last:
            gable_roof(solid, (rx0, rx1, rz0, rz1), top, mat_up)
            ring_boxes(solid, "ledge", rx0, rx1, rz0, rz1, top - 0.35, top, 0.3, 0.2)
        else:
            ground_quad(solid, "b_roof", rx0, rz0, rx1, rz1, top, 3.0)
            if detail:
                ring_boxes(solid, "ledge", rx0, rx1, rz0, rz1, top - 0.5, top + 0.1, 0.35, 0.3)
                ring_boxes(solid, "ledge", rx0, rx1, rz0, rz1, top, top + 0.9, 0.25)
            if last:
                roof_gear(deco, rnd, (rx0, rx1, rz0, rz1), top, floors, detail)


# ------------------------------------------------------------------ árvores
def limb(m, mat, p0, p1, r0, r1, sides=6):
    """Cilindro afunilado entre dois pontos 3D."""
    ax = _norm((p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]))
    L = math.dist(p0, p1)
    ref = (0, 1, 0) if abs(ax[1]) < 0.9 else (1, 0, 0)
    t1 = _norm(_cross(ax, ref))
    t2 = _cross(ax, t1)

    def ring(p, r, i):
        a = 2 * math.pi * i / sides
        c, s = math.cos(a), math.sin(a)
        return (p[0] + (t1[0] * c + t2[0] * s) * r, p[1] + (t1[1] * c + t2[1] * s) * r, p[2] + (t1[2] * c + t2[2] * s) * r)
    for i in range(sides):
        am = 2 * math.pi * (i + 0.5) / sides
        n = _norm((t1[0] * math.cos(am) + t2[0] * math.sin(am), t1[1] * math.cos(am) + t2[1] * math.sin(am),
                   t1[2] * math.cos(am) + t2[2] * math.sin(am)))
        uvs = [(i / sides * 2, 0), ((i + 1) / sides * 2, 0), ((i + 1) / sides * 2, L / 2), (i / sides * 2, L / 2)]
        m.poly(mat, [ring(p0, r0, i), ring(p0, r0, i + 1), ring(p1, r1, i + 1), ring(p1, r1, i)], uvs, n)


def leaf_cards(m, rnd, c, radii, count, size_rng, var, tex="leafcard", bias_up=0.15):
    """Cartões de folhas (textura com transparência) espalhados em volta do centro da copa."""
    rx, ry, rz = radii
    for _ in range(count):
        while True:
            p = (rnd.uniform(-1, 1), rnd.uniform(-1, 1), rnd.uniform(-1, 1))
            if p[0] ** 2 + p[1] ** 2 + p[2] ** 2 <= 1.0:
                break
        pos = (c[0] + p[0] * rx, c[1] + p[1] * ry, c[2] + p[2] * rz)
        nv = _norm((rnd.uniform(-1, 1), rnd.uniform(-0.5, 1.0), rnd.uniform(-1, 1)))
        t1 = _norm(_cross(nv, (0, 1, 0))) if abs(nv[1]) < 0.95 else (1, 0, 0)
        t2 = _cross(nv, t1)
        s = rnd.uniform(*size_rng) / 2
        pts = [(pos[0] - t1[0] * s - t2[0] * s, pos[1] - t1[1] * s - t2[1] * s, pos[2] - t1[2] * s - t2[2] * s),
               (pos[0] + t1[0] * s - t2[0] * s, pos[1] + t1[1] * s - t2[1] * s, pos[2] + t1[2] * s - t2[2] * s),
               (pos[0] + t1[0] * s + t2[0] * s, pos[1] + t1[1] * s + t2[1] * s, pos[2] + t1[2] * s + t2[2] * s),
               (pos[0] - t1[0] * s + t2[0] * s, pos[1] - t1[1] * s + t2[1] * s, pos[2] - t1[2] * s + t2[2] * s)]
        out = _norm((p[0], p[1] * 0.8 + bias_up + 0.2, p[2]))  # normal "de esfera": luz suave na copa
        m.poly(f"{tex}_{var}", pts, [(0, 0), (1, 0), (1, 1), (0, 1)], out)


def pine_cone(m, cx, cz, y0, y1, r, sides=8):
    ring = [(cx + r * math.cos(2 * math.pi * i / sides), cz + r * math.sin(2 * math.pi * i / sides)) for i in range(sides)]
    for i in range(sides):
        a, b = ring[i], ring[(i + 1) % sides]
        mx, mz = (a[0] + b[0]) / 2 - cx, (a[1] + b[1]) / 2 - cz
        L = math.hypot(mx, mz) or 1
        m.poly("pine", [(a[0], y0, a[1]), (b[0], y0, b[1]), (cx, y1, cz)],
               [(i / sides * 3, 0), ((i + 1) / sides * 3, 0), ((i + 0.5) / sides * 3, 2)], (mx / L, 0.5, mz / L))


def build_tree(solid, deco, rnd, x, z, kind):
    if kind is True:
        kind = "pine"
    elif kind is False:
        kind = "poplar" if rnd.random() < 0.2 else "oak"
    var = rnd.randint(0, 2)
    if kind == "bush":
        leaf_cards(deco, rnd, (x, LY + 0.5, z), (0.9, 0.5, 0.9), 7, (1.0, 1.5), var)
        return
    if kind == "pine":
        h = 1.8
        limb(solid, "bark", (x, LY, z), (x, LY + h, z), 0.2, 0.12, 6)
        for k in range(4):
            y0 = LY + 1.4 + k * 1.5
            pine_cone(deco, x, z, y0, y0 + 2.6, 2.3 - k * 0.5)
        return
    h = rnd.uniform(2.6, 3.6) if kind == "oak" else rnd.uniform(3.0, 4.2)
    jx, jz = rnd.uniform(-0.2, 0.2), rnd.uniform(-0.2, 0.2)
    top = (x + jx, LY + h, z + jz)
    limb(solid, "bark", (x, LY, z), (x, LY + 0.6, z), 0.38, 0.27, 7)       # base alargada (raízes)
    limb(solid, "bark", (x, LY + 0.6, z), top, 0.27, 0.14, 7)
    if kind == "oak":
        tex = rnd.choice(["leafcard", "leafcard", "leafcard2", "leafcard3"])
        crown = (x + jx, LY + h + 1.4, z + jz)
        radii = (rnd.uniform(2.2, 2.9), rnd.uniform(1.8, 2.3), rnd.uniform(2.2, 2.9))
        for _ in range(rnd.randint(3, 5)):
            a = rnd.uniform(0, 2 * math.pi)
            t = rnd.uniform(0.55, 0.9)
            base = (x + jx * t, LY + h * t, z + jz * t)
            tip = (base[0] + math.cos(a) * rnd.uniform(1.6, 2.4), base[1] + rnd.uniform(1.2, 2.2), base[2] + math.sin(a) * rnd.uniform(1.6, 2.4))
            limb(deco, "bark", base, tip, 0.10, 0.045, 5)
            for _k in range(2):  # galhos secundários
                a2 = a + rnd.uniform(-1.0, 1.0)
                t2 = rnd.uniform(0.5, 0.9)
                b2 = (base[0] + (tip[0] - base[0]) * t2, base[1] + (tip[1] - base[1]) * t2, base[2] + (tip[2] - base[2]) * t2)
                tip2 = (b2[0] + math.cos(a2) * rnd.uniform(0.7, 1.2), b2[1] + rnd.uniform(0.5, 1.2), b2[2] + math.sin(a2) * rnd.uniform(0.7, 1.2))
                limb(deco, "bark", b2, tip2, 0.045, 0.02, 4)
        leaf_cards(deco, rnd, crown, radii, 30, (2.0, 3.2), var, tex)
    else:  # álamo: copa estreita e alta
        crown = (x + jx, LY + h + 2.8, z + jz)
        leaf_cards(deco, rnd, crown, (1.1, 3.4, 1.1), 20, (1.7, 2.5), var, rnd.choice(["leafcard", "leafcard2"]))


# --------------------------------------------------------- mobiliário urbano
def traffic_signal(solid, deco, tx, tz, sx, sz, with_sign=False):
    """Poste com braço sobre a rua e duas cabeças de semáforo (lentes voltadas para quem se aproxima)."""
    cylinder(solid, "lamp_metal", tx, tz, LY, LY + 5.8, 0.09, 8, cap=False)
    ax0, ax1 = sorted((tx, tx + sx * 4.8))
    box_flat(deco, "lamp_metal", ax0, ax1, LY + 5.55, LY + 5.65, tz - 0.05, tz + 0.05)
    for off in (1.3, 4.3):
        hx = tx + sx * off
        box_flat(deco, "tl_body", hx - 0.17, hx + 0.17, LY + 4.55, LY + 5.55, tz - 0.15, tz + 0.15)
        fz0, fz1 = sorted((tz - sz * 0.15, tz - sz * 0.19))
        for k, mname in enumerate(("tl_green", "tl_yellow", "tl_red")):
            y = LY + 4.62 + k * 0.31
            box_flat(deco, mname, hx - 0.09, hx + 0.09, y, y + 0.22, fz0, fz1)
    # botoeira / semáforo de pedestres
    box_flat(deco, "tl_body", tx - 0.12, tx + 0.12, LY + 2.2, LY + 2.8, tz - 0.1, tz + 0.1)
    if with_sign:
        box_flat(deco, "sign_green", tx - 0.55, tx + 0.55, LY + 6.0, LY + 6.25, tz - 0.02, tz + 0.02)
        box_flat(deco, "sign_green", tx - 0.02, tx + 0.02, LY + 6.3, LY + 6.55, tz - 0.55, tz + 0.55)


def bus_stop(solid, deco, x, z, axis):
    """Abrigo de ônibus. axis 'z': comprido ao longo de Z, rua no lado +X. axis 'x': ao longo de X, rua em +Z."""
    def B(m, mat, a0, a1, y0, y1, b0, b1):
        if axis == "z":
            box_flat(m, mat, b0, b1, y0, y1, a0, a1)
        else:
            box_flat(m, mat, a0, a1, y0, y1, b0, b1)
    ca, cb = (z, x) if axis == "z" else (x, z)
    for da in (-1.6, 1.6):
        for db in (-0.55, 0.55):
            B(deco, "metal_gray", ca + da - 0.05, ca + da + 0.05, LY, LY + 2.5, cb + db - 0.05, cb + db + 0.05)
    B(deco, "bus_roof", ca - 1.8, ca + 1.8, LY + 2.5, LY + 2.62, cb - 0.85, cb + 0.85)
    B(deco, "car_glass", ca - 1.6, ca + 1.6, LY + 0.35, LY + 2.4, cb - 0.6, cb - 0.56)
    B(solid, "bench_wood", ca - 1.2, ca + 1.2, LY + 0.42, LY + 0.5, cb - 0.45, cb - 0.05)


# ------------------------------------------------------------------- casas
def window_geo(deco, rnd, p, n, yc, width=1.2, height=1.4, lit_p=0.35, shutters=False):
    """Janela com moldura, peitoril, vidro e travessa. p=(x,z) no centro, n=(nx,nz) normal da parede."""
    u = (-n[1], n[0])
    glass = "house_glass_lit" if rnd.random() < lit_p else "house_glass"
    hw, hh = width / 2, height / 2
    obox(deco, glass, p, u, n, width, 0.03, yc - hh, yc + hh)
    obox(deco, "ledge", p, u, n, width + 0.22, 0.08, yc + hh, yc + hh + 0.1)                  # verga
    obox(deco, "ledge", p, u, n, width + 0.34, 0.14, yc - hh - 0.08, yc - hh)                 # peitoril
    for sgn in (-1, 1):
        q = (p[0] + u[0] * sgn * (hw + 0.05), p[1] + u[1] * sgn * (hw + 0.05))
        obox(deco, "ledge", q, u, n, 0.1, 0.08, yc - hh, yc + hh)
    obox(deco, "ledge", p, u, n, 0.04, 0.06, yc - hh, yc + hh)                                 # travessa central
    if shutters:
        mat = rnd.choice(["shutter_a", "shutter_b"])
        for sgn in (-1, 1):
            q = (p[0] + u[0] * sgn * (hw + 0.4), p[1] + u[1] * sgn * (hw + 0.4))
            obox(deco, mat, q, u, n, 0.5, 0.05, yc - hh, yc + hh)


def build_house(solid, deco, rnd, w, d, floors, wall_mat, roof_var, garage, g_side):
    """Casa no referencial local: origem no centro, frente voltada para -Z, chão em y=LY.
    Retorna (xmin, xmax, zmin, zmax, x_porta, x_garagem) da planta, para calçadas e entradas."""
    h1 = 2.8
    H = h1 * floors
    x0, x1, z0, z1 = -w / 2, w / 2, -d / 2, d / 2
    y0 = LY
    box_flat(solid, "ledge", x0 - 0.08, x1 + 0.08, y0, y0 + 0.45, z0 - 0.08, z1 + 0.08)
    sides = [((x0, z0), (x1, z0), (0, 0, -1)), ((x1, z1), (x0, z1), (0, 0, 1)),
             ((x0, z1), (x0, z0), (-1, 0, 0)), ((x1, z0), (x1, z1), (1, 0, 0))]
    for a, b, n in sides:
        wall(solid, wall_mat, a, b, y0 + 0.45, y0 + H, n, 1 / 2.4, 0.0, 1 / 2.4)
    # friso entre andares e beiral
    if floors > 1:
        ring_boxes(solid, "ledge", x0, x1, z0, z1, y0 + h1 - 0.06, y0 + h1 + 0.08, 0.1, 0.1)
    gable_wall = wall_mat
    ridge = gable_roof(solid, (x0, x1, z0, z1), y0 + H, gable_wall, f"roof_tile_{roof_var}", 0.6)
    ring_boxes(solid, "ledge", x0, x1, z0, z1, y0 + H - 0.22, y0 + H, 0.2, 0.3)     # fascia

    # chaminé
    along_x = w >= d
    cx = rnd.uniform(x0 + 1.5, x1 - 1.5) if along_x else 0.0
    cz = 0.0 if along_x else rnd.uniform(z0 + 1.5, z1 - 1.5)
    box_flat(deco, "chimney", cx - 0.45, cx + 0.45, y0 + H - 0.5, ridge + 0.9, cz - 0.45, cz + 0.45)
    box_flat(deco, "ledge", cx - 0.55, cx + 0.55, ridge + 0.9, ridge + 1.0, cz - 0.55, cz + 0.55)

    # porta, degraus e alpendre
    xd = x0 + w * rnd.choice([0.28, 0.5, 0.72])
    nf = (0, -1)
    uf = (1, 0)
    obox(solid, "door_wood", (xd, z0), uf, nf, 1.0, 0.06, y0 + 0.45, y0 + 2.5)
    obox(deco, "ledge", (xd, z0), uf, nf, 1.3, 0.1, y0 + 2.5, y0 + 2.62)
    for sgn in (-1, 1):
        obox(deco, "ledge", (xd + sgn * 0.6, z0), uf, nf, 0.1, 0.1, y0 + 0.45, y0 + 2.5)
    obox(solid, "ledge", (xd, z0), uf, nf, 2.0, 0.4, y0, y0 + 0.22)
    obox(solid, "ledge", (xd, z0 - 0.4), uf, nf, 2.0, 0.4, y0, y0 + 0.11)
    obox(deco, "ledge", (xd, z0 - 0.0), uf, nf, 2.6, 1.5, y0 + 2.75, y0 + 2.85)      # laje do alpendre
    for sgn in (-1, 1):
        cylinder(solid, "ledge", xd + sgn * 1.15, z0 - 1.35, y0, y0 + 2.75, 0.08, 8, cap=False)
    box_flat(deco, "lamp_head", xd + 0.75, xd + 0.95, y0 + 2.0, y0 + 2.2, z0 - 0.1, z0 - 0.03)

    # garagem
    gx = None
    ext = [x0, x1]
    if garage:
        gw, gd = 3.4, d - 1.5
        gx0, gx1 = (x1, x1 + gw) if g_side > 0 else (x0 - gw, x0)
        gz0, gz1 = z0, z0 + gd
        gh = 2.7
        for a, b, n in [((gx0, gz0), (gx1, gz0), (0, 0, -1)), ((gx1, gz1), (gx0, gz1), (0, 0, 1)),
                        ((gx0, gz1), (gx0, gz0), (-1, 0, 0)), ((gx1, gz0), (gx1, gz1), (1, 0, 0))]:
            wall(solid, wall_mat, a, b, y0 + 0.1, y0 + gh, n, 1 / 2.4, 0.0, 1 / 2.4)
        ground_quad(solid, "b_roof", gx0, gz0, gx1, gz1, y0 + gh, 3.0)
        ring_boxes(solid, "ledge", gx0, gx1, gz0, gz1, y0 + gh, y0 + gh + 0.35, 0.2, 0.1)
        gxc = (gx0 + gx1) / 2
        obox(deco, "garage_door", (gxc, gz0), uf, nf, gw - 0.5, 0.07, y0 + 0.1, y0 + 2.35)
        for k in range(1, 4):
            obox(deco, "tire", (gxc, gz0), uf, nf, gw - 0.5, 0.09, y0 + 0.1 + k * 0.55, y0 + 0.13 + k * 0.55)
        gx = gxc
        ext = [min(x0, gx0), max(x1, gx1)]

    # janelas
    nb = (0, 1)
    for k in range(floors):
        yc = y0 + k * h1 + 1.65
        xs = [x0 + 1.4 + i * 2.7 for i in range(int((w - 2.0) // 2.7) + 1)]
        for x in xs:
            if k == 0 and abs(x - xd) < 1.4:
                continue
            window_geo(deco, rnd, (x, z0), nf, yc, shutters=rnd.random() < 0.35)
        for x in xs:
            window_geo(deco, rnd, (x, z1), nb, yc, lit_p=0.25)
        for z in (-d * 0.2, d * 0.2):
            window_geo(deco, rnd, (x0, z), (-1, 0), yc, lit_p=0.25)
            window_geo(deco, rnd, (x1, z), (1, 0), yc, lit_p=0.25)
    # ar-condicionado e lixeiras na lateral/fundo
    box_flat(deco, "metal_gray", x1 - 1.2, x1 - 0.2, y0, y0 + 0.9, z1, z1 + 0.5)
    for i in range(2):
        cylinder(solid, "bin", x0 + 1.0 + i * 0.7, z1 + 0.5, y0, y0 + 0.9, 0.26, 8)
    return (ext[0], ext[1], z0, z1, xd, gx)
