#!/usr/bin/env python3
"""
gen_condos.py - gera os 3 condomínios fechados (5, 6 e 10 casas) nos quarteirões escolhidos por gen_city.py.

Uso:  python tools/gen_condos.py game/city/city_data.gd game/condos [--no-bake]
Saída: condoN_site_solid/deco.obj (muro, portaria, rua interna, gramado) e uma casa por arquivo
       condoN_houseK_raw.obj (+ condoN_houseK.obj com sombreamento gravado) e condos_data.gd.
Requer: Pillow e numpy (numpy só para gravar o sombreamento das casas).
"""
import json
import math
import os
import random
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_city as gc  # noqa: E402
import city_parts as cp  # noqa: E402

LY = gc.LY
UP = (0, 1, 0)
SETBACK = 5.5
RW = 6.4          # largura da rua interna
SWK = 1.4         # calçada interna


def read_condos(path):
    for ln in open(path):
        if ln.startswith("const CONDOS"):
            return json.loads(ln.split("=", 1)[1])
    raise SystemExit("CONDOS não encontrado em " + path)


def wall_x(m, x0, x1, z, h=2.3, t=0.3):
    """Trecho de muro ao longo de X (z constante) com capa."""
    gc.box_flat(m, "condo_wall", x0, x1, LY, LY + h, z - t / 2, z + t / 2)
    gc.box_flat(m, "ledge", x0 - 0.05, x1 + 0.05, LY + h, LY + h + 0.12, z - t / 2 - 0.08, z + t / 2 + 0.08)


def wall_z(m, z0, z1, x, h=2.3, t=0.3):
    gc.box_flat(m, "condo_wall", x - t / 2, x + t / 2, LY, LY + h, z0, z1)
    gc.box_flat(m, "ledge", x - t / 2 - 0.08, x + t / 2 + 0.08, LY + h, LY + h + 0.12, z0 - 0.05, z1 + 0.05)


def pillars_x(m, x0, x1, z, step=6.0):
    n = max(1, int((x1 - x0) / step))
    for i in range(n + 1):
        x = x0 + (x1 - x0) * i / n
        gc.box_flat(m, "ledge", x - 0.28, x + 0.28, LY, LY + 2.6, z - 0.28, z + 0.28)


def pillars_z(m, z0, z1, x, step=6.0):
    n = max(1, int((z1 - z0) / step))
    for i in range(n + 1):
        z = z0 + (z1 - z0) * i / n
        gc.box_flat(m, "ledge", x - 0.28, x + 0.28, LY, LY + 2.6, z - 0.28, z + 0.28)


def lamp(solid, deco, x, z):
    gc.cylinder(solid, "lamp_metal", x, z, LY, LY + 4.2, 0.06, 6, cap=False)
    gc.box_flat(deco, "lamp_head", x - 0.25, x + 0.25, LY + 4.2, LY + 4.35, z - 0.25, z + 0.25, bottom=True)


def build_site(ci, rect, n, gate_hi, rnd, out):
    bx0, bx1, bz0, bz1 = rect
    xc = (bx0 + bx1) / 2
    sgn = -1 if gate_hi else 1                 # direção do portão para o fundo, ao longo de Z
    gz = bz1 if gate_hi else bz0
    BL = bz1 - bz0
    R = 7.0
    tc = BL - R - 3.5                           # centro da rotatória (distância do portão)

    def zt(t):
        return gz + sgn * t

    solid, deco = gc.Mesh(), gc.Mesh()
    gc.ground_quad(solid, "grass", bx0, bz0, bx1, bz1, LY, 4.0)

    # rua interna, calçadas e rotatória
    zA, zB = sorted((zt(0), zt(tc)))
    gc.ground_quad(solid, "asphalt", xc - RW / 2, zA, xc + RW / 2, zB, LY + 0.015, 2.4)
    gc.ground_quad(solid, "sidewalk", xc - RW / 2 - SWK, zA, xc - RW / 2, zB, LY + 0.04)
    gc.ground_quad(solid, "sidewalk", xc + RW / 2, zA, xc + RW / 2 + SWK, zB, LY + 0.04)
    ring = [(xc + R * math.cos(2 * math.pi * k / 28), zt(tc) + R * math.sin(2 * math.pi * k / 28)) for k in range(28)]
    solid.poly("asphalt", [(x, LY + 0.015, z) for x, z in ring], [(x / 2.4, z / 2.4) for x, z in ring], UP)
    isl = [(xc + 3.0 * math.cos(2 * math.pi * k / 20), zt(tc) + 3.0 * math.sin(2 * math.pi * k / 20)) for k in range(20)]
    solid.poly("grass", [(x, LY + 0.06, z) for x, z in isl], [(x / 4, z / 4) for x, z in isl], UP)
    cp.build_tree(solid, deco, rnd, xc, zt(tc), "oak")

    # muro, portaria e guarita
    ins = 0.5
    wx0, wx1, wz0, wz1 = bx0 + ins, bx1 - ins, bz0 + ins, bz1 - ins
    zg = wz1 if gate_hi else wz0               # muro do lado do portão
    zf = wz0 if gate_hi else wz1               # muro do fundo
    wall_x(solid, wx0, wx1, zf)
    pillars_x(solid, wx0, wx1, zf)
    wall_z(solid, wz0, wz1, wx0)
    wall_z(solid, wz0, wz1, wx1)
    pillars_z(solid, wz0, wz1, wx0)
    pillars_z(solid, wz0, wz1, wx1)
    gate_w = 4.2
    wall_x(solid, wx0, xc - gate_w, zg)
    wall_x(solid, xc + gate_w, wx1, zg)
    pillars_x(solid, wx0, xc - gate_w, zg)
    pillars_x(solid, xc + gate_w, wx1, zg)
    for px in (xc - gate_w, xc + gate_w):
        gc.box_flat(solid, "ledge", px - 0.4, px + 0.4, LY, LY + 3.2, zg - 0.4, zg + 0.4)
        gc.box_flat(deco, "lamp_head", px - 0.25, px + 0.25, LY + 3.2, LY + 3.45, zg - 0.25, zg + 0.25)
    gc.box_flat(deco, "ledge", xc - gate_w, xc + gate_w, LY + 3.0, LY + 3.25, zg - 0.18, zg + 0.18)
    gc.box_flat(deco, "sign_green", xc - 2.2, xc + 2.2, LY + 3.28, LY + 3.9, zg - 0.1, zg + 0.1)
    # guarita ao lado do portão (dentro do condomínio)
    gx, gzc = xc + gate_w + 2.6, zg + sgn * 2.6
    gc.box_flat(solid, "condo_wall", gx - 1.4, gx + 1.4, LY, LY + 2.7, gzc - 1.4, gzc + 1.4)
    gc.box_flat(solid, "ledge", gx - 1.7, gx + 1.7, LY + 2.7, LY + 2.85, gzc - 1.7, gzc + 1.7)
    gc.box_flat(deco, "house_glass_lit", gx - 1.0, gx + 1.0, LY + 1.0, LY + 2.1, gzc - sgn * 1.42, gzc - sgn * 1.4)
    # lâmpadas ao longo da rua
    t = 8.0
    side = 1
    while t < tc - 2:
        lamp(solid, deco, xc + side * (RW / 2 + SWK + 0.3), zt(t))
        side = -side
        t += 12.0

    # casas
    n_left = (n + 1) // 2
    counts = {-1: n_left, 1: n - n_left}
    houses = []
    t_lo, t_hi = 9.0, BL - 5.5
    k = 0
    for s in (-1, 1):
        cnt = counts[s]
        if cnt == 0:
            continue
        pitch = (t_hi - t_lo) / cnt
        for i in range(cnt):
            k += 1
            compact = n >= 8
            w = rnd.uniform(7.4, 8.4) if compact else rnd.uniform(9.5, 12.0)
            d = rnd.uniform(8.0, 9.5) if compact else rnd.uniform(9.5, 11.0)
            floors = (2 if rnd.random() < 0.65 else 1) if compact else rnd.choice([1, 2])
            garage = not compact
            g_side = rnd.choice([-1, 1])
            wall_mat = rnd.choice(["plaster", "siding", "brick"]) + "_" + str(rnd.randint(0, 2))
            roof_var = rnd.randint(0, 2)
            hm = gc.Mesh()
            ext0, ext1, z0, z1, xd, gx = cp.build_house(hm, hm, rnd, w, d, floors, wall_mat, roof_var, garage, g_side)
            house_extras(hm, rnd, ext0, ext1, z0, z1, xd, gx, w, d, (bx1 - bx0) / 2, garage)
            name = f"condo{ci}_house{k}_raw"
            hm.write(out, name)
            t_c = t_lo + (i + 0.5) * pitch
            cx = xc + s * (RW / 2 + SWK + SETBACK + d / 2)
            cz = zt(t_c)
            houses.append([f"condo{ci}_house{k}", round(cx, 2), round(cz, 2), -90 if s < 0 else 90])
    solid.write(out, f"condo{ci}_site_solid")
    deco.write(out, f"condo{ci}_site_deco")
    return houses


def house_extras(m, rnd, ext0, ext1, z0, z1, xd, gx, w, d, half_block, garage):
    """Calçadas, garagem, caixa de correio, cercas, jardim e quintal no referencial local da casa."""
    run = SETBACK + SWK                          # da frente da casa até a calçada interna
    if garage and gx is not None:
        gc.ground_quad(m, "sidewalk", gx - 1.5, z0 - run, gx + 1.5, z0, LY + 0.03)
        if rnd.random() < 0.55:                  # carro na entrada
            cm = rnd.choice(gc.CAR_MATS)
            zc = z0 - 3.4
            gc.box_flat(m, cm, gx - 0.9, gx + 0.9, LY + 0.28, LY + 0.98, zc - 2.2, zc + 2.2)
            gc.box_flat(m, "car_glass", gx - 0.8, gx + 0.8, LY + 0.98, LY + 1.5, zc - 1.0, zc + 1.1)
    gc.ground_quad(m, "sidewalk", xd - 0.6, z0 - run, xd + 0.6, z0 - 0.4, LY + 0.03)
    # caixa de correio
    mx, mz = xd + 1.8, z0 - run + 0.5
    gc.box_flat(m, "lamp_metal", mx - 0.04, mx + 0.04, LY, LY + 1.0, mz - 0.04, mz + 0.04)
    gc.box_flat(m, "tl_body", mx - 0.2, mx + 0.2, LY + 1.0, LY + 1.25, mz - 0.12, mz + 0.12)
    # arbustos na frente
    x = ext0 + 1.2
    while x < ext1 - 1.0:
        near_door = abs(x - xd) < 1.5
        near_drive = gx is not None and abs(x - gx) < 2.3
        if not near_door and not near_drive:
            cp.build_tree(m, m, rnd, x, z0 - 0.9, "bush")
        x += 2.4
    # quintal: cerca nas laterais e no fundo, árvores e, às vezes, piscina
    back = half_block - (SETBACK + RW / 2 + SWK) - d - 0.9
    fx0, fx1 = ext0 - 0.6, ext1 + 0.6
    for fx in (fx0, fx1):
        gc.box_flat(m, "fence_wood", fx - 0.03, fx + 0.03, LY, LY + 1.3, z1, z1 + back)
    gc.box_flat(m, "fence_wood", fx0, fx1, LY, LY + 1.3, z1 + back - 0.03, z1 + back + 0.03)
    for _ in range(rnd.randint(1, 2)):
        cp.build_tree(m, m, rnd, rnd.uniform(fx0 + 2.0, fx1 - 2.0), z1 + rnd.uniform(back * 0.55, back - 2.0),
                      rnd.choice(["oak", "oak", "poplar"]))
    if garage and back > 9 and rnd.random() < 0.4:  # piscina
        px0, px1 = (ext0 + ext1) / 2 - 2.0, (ext0 + ext1) / 2 + 2.0
        pz0, pz1 = z1 + 2.5, z1 + 8.5
        gc.ground_quad(m, "sidewalk", px0 - 1.2, pz0 - 1.2, px1 + 1.2, pz1 + 1.2, LY + 0.04)
        gc.ground_quad(m, "pool_water", px0, pz0, px1, pz1, LY + 0.07)
        cp.ring_boxes(m, "ledge", px0, px1, pz0, pz1, LY + 0.04, LY + 0.16, 0.12, 0.12)


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    city_data, out = sys.argv[1], sys.argv[2]
    bake = "--no-bake" not in sys.argv
    os.makedirs(out, exist_ok=True)
    rnd = random.Random(gc.SEED + 99)
    condos = read_condos(city_data)
    sites, houses = [], []
    for ci, (x0, x1, z0, z1, n, gate_hi) in enumerate(condos, start=1):
        hs = build_site(ci, (x0, x1, z0, z1), n, gate_hi, rnd, out)
        houses += hs
        sites.append([f"condo{ci}_site_solid", f"condo{ci}_site_deco"])
        print(f"condomínio {ci}: {len(hs)} casas")
    # texturas: usa a mesma pasta da cidade
    src_tex = os.path.join(os.path.dirname(city_data), "tex")
    dst_tex = os.path.join(out, "tex")
    if os.path.isdir(dst_tex):
        shutil.rmtree(dst_tex)
    shutil.copytree(src_tex, dst_tex)
    with open(os.path.join(out, "condos_data.gd"), "w") as f:
        f.write("extends RefCounted\n# Gerado por tools/gen_condos.py - não edite.\n")
        f.write("const SITES = " + json.dumps(sites) + "\n")
        f.write("const HOUSES = " + json.dumps(houses) + "\n")
    if bake:
        for name, *_ in houses:
            raw = os.path.join(out, name + "_raw.obj")
            baked = os.path.join(out, name + ".obj")
            subprocess.run([sys.executable, os.path.join(HERE, "bake_ao.py"), raw, baked, "1.4", "0.25"],
                           check=True, stdout=subprocess.DEVNULL)
        print("sombreamento gravado em", len(houses), "casas")


if __name__ == "__main__":
    main()
