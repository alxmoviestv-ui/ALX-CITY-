#!/usr/bin/env python3
"""
bake_city.py - grava iluminação (oclusão ambiental + exposição ao céu) nos pedaços sólidos da cidade.

Uso:  python tools/bake_city.py game/city [raio_m=220] [centro_x centro_z]
Saída: city_solid_A_B_lit.obj ao lado de cada city_solid_A_B.obj dentro do raio (o original continua
       servindo de colisão). A cor de vértice vale para qualquer hora do dia (não depende da posição do sol).
Requer: numpy.
"""
import glob
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bake_ao as ba  # noqa: E402

VOX = 1.0
MAX_GIANT = 400.0


# ------------------------------------------------------------------ leitura
def read_chunk(path):
    V, VT, VN, groups, cur = [], [], [], [], None
    for ln in open(path):
        if ln.startswith("v "):
            p = ln.split()
            V.append((float(p[1]), float(p[2]), float(p[3])))
        elif ln.startswith("vt "):
            p = ln.split()
            VT.append((float(p[1]), float(p[2])))
        elif ln.startswith("vn "):
            p = ln.split()
            VN.append((float(p[1]), float(p[2]), float(p[3])))
        elif ln.startswith("usemtl"):
            cur = (ln.split()[1], [])
            groups.append(cur)
        elif ln.startswith("f "):
            cur[1].append([tuple(int(x) - 1 if x else 0 for x in t.split("/")) for t in ln.split()[1:]])
    return np.array(V, np.float64), np.array(VT, np.float64), np.array(VN, np.float64), groups


def read_positions(path):
    V, F = [], []
    for ln in open(path):
        if ln.startswith("v "):
            p = ln.split()
            V.append((float(p[1]), float(p[2]), float(p[3])))
        elif ln.startswith("f "):
            idx = [int(t.split("/")[0]) - 1 for t in ln.split()[1:]]
            for k in range(1, len(idx) - 1):
                F.append((idx[0], idx[k], idx[k + 1]))
    return np.array(V, np.float64).reshape(-1, 3), np.array(F, np.int64).reshape(-1, 3)


# --------------------------------------------------------------- voxelização
def voxelize(occ, lo, shape, V, F):
    T = V[F]                                  # (n, 3, 3)
    e = np.maximum.reduce([np.linalg.norm(T[:, 1] - T[:, 0], axis=1),
                           np.linalg.norm(T[:, 2] - T[:, 1], axis=1),
                           np.linalg.norm(T[:, 0] - T[:, 2], axis=1)])
    small = e < 0.6
    ok = e < MAX_GIANT

    def mark(pts):
        ix = np.floor((pts - lo) / VOX).astype(int)
        good = (ix >= 0).all(1) & (ix < shape).all(1)
        ix = ix[good]
        occ[ix[:, 0], ix[:, 1], ix[:, 2]] = 1

    S = T[small & ok]
    if len(S):
        mark(S.mean(1))
        mark(S[:, 0])
        mark(S[:, 1])
        mark(S[:, 2])
    cache = {}
    for t, em in zip(T[~small & ok], e[~small & ok]):
        n = max(1, int(em / 0.4)) + 1
        if n not in cache:
            i, j = np.meshgrid(np.arange(n + 1), np.arange(n + 1))
            m = (i + j) <= n
            cache[n] = (i[m] / n, j[m] / n)
        u, v = cache[n]
        mark(t[0] + np.outer(u, t[1] - t[0]) + np.outer(v, t[2] - t[0]))


# ------------------------------------------------------------- subdivisão
def split_aniso(tri, flat, out):
    """Divide pela aresta mais "longa em relação ao limite": chão e telhado 4 m, paredes 8 m (horizontal) e 10 m (vertical)."""
    stack = [tri]
    while stack:
        t = stack.pop()
        (p0, u0, n0), (p1, u1, n1), (p2, u2, n2) = t
        best, bk = 0.0, -1
        for k, (a, b) in enumerate(((p0, p1), (p1, p2), (p2, p0))):
            d = b - a
            L = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
            lim = 4.0 if flat else (10.0 if abs(d[1]) > 0.5 * L else 8.0)
            r = L / lim
            if r > best:
                best, bk = r, k
        if best <= 1.0 or bk < 0:
            out.append(t)
            continue
        if bk == 0:
            pm, um = (p0 + p1) / 2, (u0 + u1) / 2
            stack += [((p0, u0, n0), (pm, um, n0), (p2, u2, n0)), ((pm, um, n0), (p1, u1, n0), (p2, u2, n0))]
        elif bk == 1:
            pm, um = (p1 + p2) / 2, (u1 + u2) / 2
            stack += [((p0, u0, n0), (p1, u1, n0), (pm, um, n0)), ((p0, u0, n0), (pm, um, n0), (p2, u2, n0))]
        else:
            pm, um = (p2 + p0) / 2, (u2 + u0) / 2
            stack += [((p0, u0, n0), (p1, u1, n0), (pm, um, n0)), ((pm, um, n0), (p1, u1, n0), (p2, u2, n0))]


# ------------------------------------------------------------ iluminação
def light(occ, lo, shape, P, N):
    ref = np.where(np.abs(N[:, 1:2]) < 0.9, np.array([[0.0, 1.0, 0.0]]), np.array([[1.0, 0.0, 0.0]]))
    T = np.cross(N, ref)
    T /= np.linalg.norm(T, axis=1, keepdims=True)
    B = np.cross(N, T)
    start = P + N * 1.2
    # oclusão ambiental curta
    blocked = np.zeros(len(P))
    dirs = ba.hemisphere_dirs(12)
    for dx, dy, dz in dirs:
        d = T * dx + B * dy + N * dz
        hit = np.zeros(len(P), bool)
        for s in (0.6, 1.6, 2.8, 4.0):
            hit |= ba.lookup(occ, lo, shape, start + d * s)
        blocked += hit
    ao = 1.0 - 0.7 * (blocked / len(dirs))
    # exposição ao céu (raios para cima, até 70 m)
    n_up = 12
    openv = np.zeros(len(P))
    golden = math.pi * (3 - math.sqrt(5))
    for i in range(n_up):
        dz = 0.42 + 0.58 * math.sqrt((i + 0.5) / n_up)
        r = math.sqrt(max(0.0, 1 - dz * dz))
        a = golden * i
        d = np.array([r * math.cos(a), dz, r * math.sin(a)])
        hit = np.zeros(len(P), bool)
        for s in np.arange(1.0, 70.0, 1.0):
            hit |= ba.lookup(occ, lo, shape, start + d * s)
        openv += ~hit
    sky = np.clip(openv / n_up / 0.85, 0.0, 1.0)
    raw = np.clip(ao * (0.40 + 0.60 * sky ** 0.8), 0.25, 1.0)
    return 0.45 + 0.55 * raw          # contraste suave: a luz do sol continua fazendo o trabalho principal


def bake_chunk(path, occ, lo, shape, out_path):
    V, VT, VN, groups = read_chunk(path)
    tris, mats, counts = [], [], []
    for mat, faces in groups:
        n0 = len(tris)
        for f in faces:
            for k in range(1, len(f) - 1):
                corner = [f[0], f[k], f[k + 1]]
                t = []
                for vi, ti, ni in corner:
                    t.append((V[vi], VT[ti] if len(VT) else np.zeros(2), VN[ni] if len(VN) else np.array([0.0, 1.0, 0.0])))
                p0, p1, p2 = t[0][0], t[1][0], t[2][0]
                em = max(np.linalg.norm(p1 - p0), np.linalg.norm(p2 - p1), np.linalg.norm(p0 - p2))
                if em > MAX_GIANT:
                    tris.append((tuple(t), True))        # gigante (terreno de fundo): sem subdividir
                    continue
                area = 0.5 * np.linalg.norm(np.cross(p1 - p0, p2 - p0))
                if area / max(em, 1e-6) < 0.8:               # tira fina (praça preenchida): sem subdividir
                    tris.append(((( p0, t[0][1], t[0][2]), (p1, t[1][1], t[0][2]), (p2, t[2][1], t[0][2])), False))
                    continue
                flat = abs(float(t[0][2][1])) > 0.7
                tt = ((p0, t[0][1], t[0][2]), (p1, t[1][1], t[0][2]), (p2, t[2][1], t[0][2]))
                out = []
                split_aniso(tt, flat, out)
                for o in out:
                    tris.append((o, False))
        mats.append(mat)
        counts.append(len(tris) - n0)
    P = np.array([v[0] for tr, _ in tris for v in tr])
    UV = np.array([v[1] for tr, _ in tris for v in tr])
    NN = np.array([tr[0][2] for tr, _ in tris for _v in range(3)])
    giant = np.repeat(np.array([g for _, g in tris]), 3)
    shade = np.ones(len(P))
    idx = np.where(~giant)[0]
    if len(idx):
        shade[idx] = light(occ, lo, shape, P[idx], NN[idx])
    vkey, vlines, vtlines, vidx = {}, [], [], np.zeros(len(P), np.int64)
    for i in range(len(P)):
        p, u, c = P[i], UV[i], shade[i]
        key = (int(round(p[0] * 100)), int(round(p[1] * 100)), int(round(p[2] * 100)), int(round(c * 100)),
               int(round(u[0] * 1000)), int(round(u[1] * 1000)))
        j = vkey.get(key)
        if j is None:
            j = len(vlines)
            vkey[key] = j
            cc = key[3] / 100.0
            vlines.append("v %.2f %.2f %.2f %.2f %.2f %.2f\n" % (key[0] / 100.0, key[1] / 100.0, key[2] / 100.0, cc, cc, cc))
            vtlines.append("vt %.3f %.3f\n" % (key[4] / 1000.0, key[5] / 1000.0))
        vidx[i] = j
    nkey, nlines, nidx = {}, [], np.zeros(len(tris), np.int64)
    for k in range(len(tris)):
        n = NN[k * 3]
        key = (int(round(n[0] * 100)), int(round(n[1] * 100)), int(round(n[2] * 100)))
        j = nkey.get(key)
        if j is None:
            j = len(nlines)
            nkey[key] = j
            nlines.append("vn %.2f %.2f %.2f\n" % (key[0] / 100.0, key[1] / 100.0, key[2] / 100.0))
        nidx[k] = j
    with open(out_path, "w") as f:
        base = os.path.basename(path)[:-4]
        f.write(f"mtllib {base}.mtl\n")
        f.writelines(vlines)
        f.writelines(vtlines)
        f.writelines(nlines)
        tri_i = 0
        for mat, cnt in zip(mats, counts):
            f.write(f"o {mat}\nusemtl {mat}\n")
            for _ in range(cnt):
                a, b, c = vidx[tri_i * 3] + 1, vidx[tri_i * 3 + 1] + 1, vidx[tri_i * 3 + 2] + 1
                nn = nidx[tri_i] + 1
                f.write(f"f {a}/{a}/{nn} {b}/{b}/{nn} {c}/{c}/{nn}\n")
                tri_i += 1
    return len(tris), float(shade.mean())


def chunk_dist(path, mx, mz):
    """Distância do centro (mx, mz) até a caixa do pedaço (ignora os terrenos gigantes)."""
    V, _ = read_positions(path)
    m = (np.abs(V[:, 0]) < 2000) & (np.abs(V[:, 2]) < 2000)
    V = V[m] if m.any() else V
    dx = max(V[:, 0].min() - mx, 0.0, mx - V[:, 0].max())
    dz = max(V[:, 2].min() - mz, 0.0, mz - V[:, 2].max())
    return math.hypot(dx, dz)


def main():
    folder = sys.argv[1]
    R = float(sys.argv[2]) if len(sys.argv) > 2 else 220.0
    mx, mz = (float(sys.argv[3]), float(sys.argv[4])) if len(sys.argv) > 4 else (-17.05, 19.0)
    ba.VOX = VOX
    solids = sorted(glob.glob(os.path.join(folder, "city_solid_*[0-9].obj")))
    decos = sorted(glob.glob(os.path.join(folder, "city_deco_*[0-9].obj")))
    near_solid, occluders = [], []
    for p in solids + decos:
        d = chunk_dist(p, mx, mz)
        if d < R + 140:
            occluders.append(p)
        if p in solids and d < R:
            near_solid.append(p)
    print("pedaços para gravar:", len(near_solid), " oclusores:", len(occluders))

    pad = R + 160
    lo = np.array([mx - pad, -8.0, mz - pad])
    hi = np.array([mx + pad, 95.0, mz + pad])
    shape = np.ceil((hi - lo) / VOX).astype(int)
    occ = np.zeros(shape, np.uint8)
    for p in occluders:
        V, F = read_positions(p)
        if len(F):
            voxelize(occ, lo, shape, V, F)
    print("voxels ocupados:", int(occ.sum()))

    tot_t = 0
    for p in near_solid:
        out_path = p[:-4] + "_lit.obj"
        n, mean = bake_chunk(p, occ, lo, shape, out_path)
        tot_t += n
        print("ok %s  tris=%d  sombra média=%.2f" % (os.path.basename(out_path), n, mean))
    print("total de triângulos gravados:", tot_t)


if __name__ == "__main__":
    main()
