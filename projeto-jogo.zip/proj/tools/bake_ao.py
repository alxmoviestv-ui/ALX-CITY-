#!/usr/bin/env python3
"""
bake_ao.py - grava sombreamento nos vértices do OBJ do mapa (cor de vértice).

  ao  = oclusão ambiental curta (cantos e frestas ficam mais escuros)
  sky = exposição ao céu (interiores e áreas cobertas ficam mais escuros)

Uso:  python tools/bake_ao.py game/map/rp_downtown_vv1.obj game/map/rp_downtown_vv1_shaded.obj [aresta_max_m]
Requer: numpy. Gera um OBJ subdividido com cor de vértice (o original continua servindo de colisão).
"""
import math
import sys

import numpy as np

VOX = 0.5


def read_obj(path):
    lines = open(path).read().split("\n")
    V, polys = [], []
    for ln in lines:
        if ln.startswith("v "):
            p = ln.split()
            V.append((float(p[1]), float(p[2]), float(p[3])))
        elif ln.startswith("f "):
            polys.append([int(t.split("/")[0]) - 1 for t in ln.split()[1:]])
    return lines, np.array(V, np.float64), polys


def vertex_normals(V, polys):
    N = np.zeros_like(V)
    for idx in polys:
        a, b, c = V[idx[0]], V[idx[1]], V[idx[2]]
        n = np.cross(b - a, c - a)
        L = np.linalg.norm(n)
        if L > 1e-9:
            n = n / L
        else:
            n = np.array([0.0, 1.0, 0.0])
        for i in idx:
            N[i] = n
    return N


def voxelize(V, polys, origin, shape):
    occ = np.zeros(shape, np.uint8)
    cache = {}
    for idx in polys:
        for k in range(1, len(idx) - 1):
            a, b, c = V[idx[0]], V[idx[k]], V[idx[k + 1]]
            e = max(np.linalg.norm(b - a), np.linalg.norm(c - b), np.linalg.norm(a - c))
            n = max(1, int(e / 0.3)) + 1
            if n not in cache:
                i, j = np.meshgrid(np.arange(n + 1), np.arange(n + 1))
                m = (i + j) <= n
                cache[n] = (i[m] / n, j[m] / n)
            u, v = cache[n]
            pts = a + np.outer(u, b - a) + np.outer(v, c - a)
            ix = np.floor((pts - origin) / VOX).astype(int)
            ok = (ix >= 0).all(1) & (ix < shape).all(1)
            ix = ix[ok]
            occ[ix[:, 0], ix[:, 1], ix[:, 2]] = 1
    return occ


def lookup(occ, origin, shape, pts):
    ix = np.floor((pts - origin) / VOX).astype(int)
    inside = (ix >= 0).all(1) & (ix < shape).all(1)
    out = np.zeros(len(pts), bool)
    ii = ix[inside]
    out[inside] = occ[ii[:, 0], ii[:, 1], ii[:, 2]] > 0
    return out


def hemisphere_dirs(n, cos_weighted=True):
    d = []
    golden = math.pi * (3 - math.sqrt(5))
    for i in range(n):
        z = math.sqrt((i + 0.5) / n) if cos_weighted else (i + 0.5) / n
        r = math.sqrt(max(0.0, 1 - z * z))
        a = golden * i
        d.append((r * math.cos(a), r * math.sin(a), z))
    return d


def parse_groups(path):
    """Lê o OBJ: posições, uvs e grupos [(material, [faces])] com faces = [(vi, ti), ...]."""
    V, VT, groups, cur = [], [], [], None
    for ln in open(path).read().split("\n"):
        if ln.startswith("v "):
            p = ln.split()
            V.append((float(p[1]), float(p[2]), float(p[3])))
        elif ln.startswith("vt "):
            p = ln.split()
            VT.append((float(p[1]), float(p[2])))
        elif ln.startswith("usemtl"):
            cur = (ln.split()[1], [])
            groups.append(cur)
        elif ln.startswith("f "):
            face = []
            for t in ln.split()[1:]:
                q = t.split("/")
                face.append((int(q[0]) - 1, int(q[1]) - 1 if len(q) > 1 and q[1] else 0))
            cur[1].append(face)
    return np.array(V, np.float64), np.array(VT, np.float64), groups


def split_tri(tri, max_edge, out):
    """Divide o triângulo pela aresta mais longa até todas ficarem <= max_edge."""
    stack = [tri]
    while stack:
        (p0, u0), (p1, u1), (p2, u2) = stack.pop()
        e = (np.linalg.norm(p1 - p0), np.linalg.norm(p2 - p1), np.linalg.norm(p0 - p2))
        m = max(e)
        if m <= max_edge:
            out.append(((p0, u0), (p1, u1), (p2, u2)))
            continue
        k = e.index(m)
        if k == 0:
            pm, um = (p0 + p1) / 2, (u0 + u1) / 2
            stack += [((p0, u0), (pm, um), (p2, u2)), ((pm, um), (p1, u1), (p2, u2))]
        elif k == 1:
            pm, um = (p1 + p2) / 2, (u1 + u2) / 2
            stack += [((p0, u0), (p1, u1), (pm, um)), ((p0, u0), (pm, um), (p2, u2))]
        else:
            pm, um = (p2 + p0) / 2, (u2 + u0) / 2
            stack += [((p0, u0), (p1, u1), (pm, um)), ((pm, um), (p1, u1), (p2, u2))]


def main():
    path = sys.argv[1]
    out_path = sys.argv[2]
    max_edge = float(sys.argv[3]) if len(sys.argv) > 3 else 2.0
    global VOX
    if len(sys.argv) > 4:
        VOX = float(sys.argv[4])
    V0, VT0, groups = parse_groups(path)

    # grade de voxels com a geometria original
    lo = V0.min(0) - 2.0
    hi = V0.max(0) + 2.0
    shape = np.ceil((hi - lo) / VOX).astype(int)
    orig_polys = [[vi for vi, _ in face] for _, faces in groups for face in faces]
    occ = voxelize(V0, orig_polys, lo, shape)
    print("grade:", tuple(shape), "voxels ocupados:", int(occ.sum()))

    # subdivide e junta os vértices por material
    P, UV, mats, counts = [], [], [], []
    for mat, faces in groups:
        n_before = len(P)
        for face in faces:
            for k in range(1, len(face) - 1):
                tri = []
                for vi, ti in (face[0], face[k], face[k + 1]):
                    tri.append((V0[vi], VT0[ti] if len(VT0) else np.zeros(2)))
                out = []
                split_tri(tuple(tri), max_edge, out)
                for t in out:
                    for p, u in t:
                        P.append(p)
                        UV.append(u)
        mats.append(mat)
        counts.append(len(P) - n_before)
    P = np.array(P)
    UV = np.array(UV)
    print("vértices depois de subdividir:", len(P), " triângulos:", len(P) // 3)

    # normais por triângulo
    tri = P.reshape(-1, 3, 3)
    Nt = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    L = np.linalg.norm(Nt, axis=1, keepdims=True)
    Nt = np.where(L > 1e-9, Nt / np.maximum(L, 1e-9), np.array([[0.0, 1.0, 0.0]]))
    N = np.repeat(Nt, 3, axis=0)

    ref = np.where(np.abs(N[:, 1:2]) < 0.9, np.array([[0.0, 1.0, 0.0]]), np.array([[1.0, 0.0, 0.0]]))
    T = np.cross(N, ref)
    T /= np.linalg.norm(T, axis=1, keepdims=True)
    B = np.cross(N, T)

    # --- oclusão ambiental curta
    dirs = hemisphere_dirs(16)
    steps = [0.7, 1.1, 1.5, 1.9, 2.4, 3.0]
    blocked = np.zeros(len(P))
    for dx, dy, dz in dirs:
        d = T * dx + B * dy + N * dz
        hit = np.zeros(len(P), bool)
        for s in steps:
            hit |= lookup(occ, lo, shape, P + d * s)
        blocked += hit
    ao = 1.0 - 0.75 * (blocked / len(dirs))
    print("ao feito")

    # --- exposição ao céu (raios para cima, até 35 m, sem raios muito rasos)
    n_up = 12
    openv = np.zeros(len(P))
    start = P + N * 0.7
    golden = math.pi * (3 - math.sqrt(5))
    for i in range(n_up):
        dz = 0.42 + 0.58 * math.sqrt((i + 0.5) / n_up)
        r = math.sqrt(max(0.0, 1 - dz * dz))
        a = golden * i
        d = np.array([r * math.cos(a), dz, r * math.sin(a)])
        hit = np.zeros(len(P), bool)
        for s in np.arange(0.4, 35.0, 1.0):
            hit |= lookup(occ, lo, shape, start + d * s)
        openv += ~hit
    sky = openv / n_up
    sky_n = np.clip(sky / 0.7, 0.0, 1.0)

    shade = np.clip(ao * (0.22 + 0.78 * sky_n ** 0.9), 0.15, 1.0)
    print("sombreamento: min %.2f  médio %.2f  max %.2f" % (shade.min(), shade.mean(), shade.max()))
    print("vértices bem expostos ao céu: %.0f%%" % (100.0 * (sky_n > 0.8).mean()))

    with open(out_path, "w") as f:
        base = path.rsplit(".", 1)[0].split("/")[-1]
        f.write(f"mtllib {base}.mtl\n")
        for p, c in zip(P, shade):
            f.write("v %.2f %.2f %.2f %.2f %.2f %.2f\n" % (p[0], p[1], p[2], c, c, c))
        for u in UV:
            f.write("vt %.3f %.3f\n" % (u[0], u[1]))
        i = 0
        for mat, cnt in zip(mats, counts):
            f.write(f"o {mat}\nusemtl {mat}\n")
            for k in range(cnt // 3):
                a, b, c = i + 1, i + 2, i + 3
                f.write(f"f {a}/{a} {b}/{b} {c}/{c}\n")
                i += 3
    print("ok:", out_path)


if __name__ == "__main__":
    main()
