#!/usr/bin/env python3
"""export_lights.py - extrai as luzes do mapa (light / light_spot) para game/map_lights.gd.
Uso: python tools/export_lights.py mapa.bsp game/map_lights.gd"""
import re
import struct
import sys

S = 0.01905


def main():
    data = open(sys.argv[1], "rb").read()
    off, length, _v, _c = struct.unpack_from("<iiii", data, 8)
    ent = data[off:off + length].decode("latin1")
    lights = []
    for block in re.findall(r"\{([^}]*)\}", ent):
        d = dict(re.findall(r'"([^"]+)" "([^"]*)"', block))
        if d.get("classname") not in ("light", "light_spot"):
            continue
        x, y, z = map(float, d["origin"].split())
        v = d.get("_light", "255 255 255 200").split()
        r, g, b = (int(v[0]) / 255.0, int(v[1]) / 255.0, int(v[2]) / 255.0)
        bright = float(v[3]) if len(v) > 3 else 200.0
        energy = max(0.35, min(2.4, bright / 230.0))
        down = 0.15 if d["classname"] == "light_spot" else 0.0
        lights.append([round(x * S, 2), round(z * S - down, 2), round(-y * S, 2),
                       round(r, 2), round(g, 2), round(b, 2), round(energy, 2)])
    with open(sys.argv[2], "w") as f:
        f.write("extends RefCounted\n# Gerado por tools/export_lights.py - nao edite.\n")
        f.write("const LIGHTS = " + str(lights).replace(" ", "") + "\n")
    print("luzes exportadas:", len(lights))


if __name__ == "__main__":
    main()
