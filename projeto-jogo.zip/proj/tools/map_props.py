#!/usr/bin/env python3
"""
map_props.py - recria os objetos (props) do mapa original que não vieram na conversão:
portas, luminárias de teto, postes, bancos, lixeiras, fogões, mesas, arquivos, caixas de força e corrimãos.

Uso:  python tools/map_props.py mapa.bsp game/map/rp_downtown_vv1.obj game/map
Saída: map_props_solid.obj (com colisão) e map_props_deco.obj (sem colisão)
Requer: Pillow e numpy.
"""
import math
import os
import re
import struct
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_city as gc  # noqa: E402
import city_parts as cp  # noqa: E402
import bake_ao as ba  # noqa: E402

S = 0.01905
gc.FLAT.update({
    "fixture_light": (1.0, 0.97, 0.85), "fixture_metal": (0.55, 0.56, 0.6), "stove": (0.82, 0.82, 0.84),
    "desk_wood": (0.40, 0.28, 0.18), "cabinet": (0.45, 0.48, 0.52), "door_knob": (0.72, 0.62, 0.22),
    "handrail": (0.25, 0.25, 0.28), "door_paint": (0.62, 0.45, 0.28),
})


def parse_bsp(path):
    f = open(path, "rb").read()
    off, ln, _v, _c = struct.unpack_from("<iiii", f, 8)
    ents = []
    for b in re.findall(r"\{([^}]*)\}", f[off:off + ln].decode("latin1")):
        ents.append(dict(re.findall(r'"([^"]+)" "([^"]*)"', b)))
    props = []
    base, = struct.unpack_from("<i", f, 8 + 35 * 16)
    n, = struct.unpack_from("<i", f, base)
    for i in range(n):
        gid, fl, ver, ofs, size = struct.unpack_from("<iHHii", f, base + 4 + i * 16)
        if struct.pack("<i", gid)[::-1] != b"sprp":
            continue
        p = ofs
        nd, = struct.unpack_from("<i", f, p)
        p += 4
        names = [f[p + k * 128:p + (k + 1) * 128].split(b"\0")[0].decode() for k in range(nd)]
        p += nd * 128
        nl, = struct.unpack_from("<i", f, p)
        p += 4 + nl * 2
        npr, = struct.unpack_from("<i", f, p)
        p += 4
        sz = (ofs + size - p) // npr
        for k in range(npr):
            x, y, z, ax, ay, az, pt = struct.unpack_from("<6fH", f, p + k * sz)
            props.append((names[pt].lower().split("/")[-1], (x, y, z), (ax, ay, az)))
    return ents, props


def g(origin):
    """Source (x, y, z) -> Godot (x, y, z) em metros."""
    return origin[0] * S, origin[2] * S, -origin[1] * S


def heading(yaw_deg):
    t = math.radians(yaw_deg)
    return (math.cos(t), -math.sin(t))


def disc(m, mat, cx, y, cz, r, up, n=10):
    pts = [(cx + r * math.cos(2 * math.pi * i / n), y, cz + r * math.sin(2 * math.pi * i / n)) for i in range(n)]
    m.poly(mat, pts, [(0, 0)] * n, (0, 1 if up else -1, 0))


def oriented(m, mat, cx, cz, hd, along, across, y0, y1, bottom=False):
    """Caixa centrada em (cx, cz) com comprimento 'along' na direção hd e largura 'across'."""
    u = hd
    nrm = (-hd[1], hd[0])
    p = (cx - nrm[0] * across / 2, cz - nrm[1] * across / 2)
    cp.obox(m, mat, p, u, nrm, along, across, y0, y1, bottom)


# --------------------------------------------------------------------- portas
class Doors:
    def __init__(self, obj_path):
        V, _vt, groups = ba.parse_groups(obj_path)
        polys = [[vi for vi, _ in face] for _, faces in groups for face in faces]
        ba.VOX = 0.25
        self.lo = V.min(0) - 1.0
        hi = V.max(0) + 1.0
        self.shape = np.ceil((hi - self.lo) / 0.25).astype(int)
        self.occ = ba.voxelize(V, polys, self.lo, self.shape)

    def blocked(self, pts):
        return ba.lookup(self.occ, self.lo, self.shape, np.array(pts, np.float64))

    def span_free(self, c, ax, t0, t1, y):
        ts = np.linspace(t0, t1, 7)
        pts = [(c[0] + ax[0] * t, yy, c[1] + ax[1] * t) for t in ts for yy in (y + 0.5, y + 1.0, y + 1.7)]
        return not self.blocked(pts).any()

    def end_hits(self, c, ax, y, sgn):
        pts = [(c[0] + ax[0] * sgn * u, yy, c[1] + ax[1] * sgn * u) for u in (0.42, 0.5, 0.58, 0.66, 0.75, 0.85)
               for yy in (y + 0.5, y + 1.0, y + 1.7)]
        return self.blocked(pts).any()

    def find(self, org, hd):
        """Procura, ao redor da origem, o vão de porta: livre no meio e com paredes nas duas pontas.
        Retorna (centro, eixo, y do chão) ou None."""
        perp = (-hd[1], hd[0])
        offs = sorted(((dx, dz) for dx in np.arange(-0.7, 0.71, 0.1) for dz in np.arange(-0.7, 0.71, 0.1)),
                      key=lambda t: t[0] ** 2 + t[1] ** 2)
        for dy in (-1.05, -1.0, -1.1, 0.0, -0.5):   # a origem da porta fica no meio da altura (chão = y - 1,05)
            for dx, dz in offs:
                c = (org[0] + dx, org[1] + dz)
                for ax in (hd, perp):
                    y = org_y[0] + dy
                    if self.span_free(c, ax, -0.30, 0.30, y) and self.end_hits(c, ax, y, -1) and self.end_hits(c, ax, y, 1):
                        return c, ax, y
        return None


org_y = [0.0]


def build(bsp, obj, out):
    ents, sprops = parse_bsp(bsp)
    solid, deco = gc.Mesh(), gc.Mesh()
    counts = {}

    def cnt(k):
        counts[k] = counts.get(k, 0) + 1

    # ------------------------------------------------------------ props estáticos
    for name, origin, ang in sprops:
        x, y, z = g(origin)
        hd = heading(ang[1])
        perp = (-hd[1], hd[0])
        if "domelight" in name:
            disc(deco, "fixture_light", x, y - 0.12, z, 0.21, False)
            gc.cylinder(deco, "fixture_metal", x, z, y - 0.12, y, 0.23, 10, cap=False)
            cnt("domelight")
        elif "florescent" in name or "flourescent" in name:
            oriented(deco, "fixture_light", x, z, hd, 1.2, 0.3, y - 0.08, y, bottom=True)
            cnt("fluorescente")
        elif "lamppost" in name:
            gc.cylinder(solid, "lamp_metal", x, z, y, y + 4.6, 0.07, 8, cap=False)
            gc.box_flat(deco, "lamp_head", x - 0.3, x + 0.3, y + 4.55, y + 4.7, z - 0.2, z + 0.2, bottom=True)
            cnt("poste")
        elif "bench" in name:
            oriented(solid, "bench_wood", x, z, hd, 1.6, 0.45, y + 0.4, y + 0.48)
            oriented(deco, "bench_wood", x - perp[0] * 0.2, z - perp[1] * 0.2, hd, 1.6, 0.06, y + 0.48, y + 0.95)
            for sgn in (-1, 1):
                gc.box_flat(solid, "fixture_metal", x + hd[0] * 0.7 * sgn - 0.03, x + hd[0] * 0.7 * sgn + 0.03, y, y + 0.4,
                            z + hd[1] * 0.7 * sgn - 0.03, z + hd[1] * 0.7 * sgn + 0.03)
            cnt("banco")
        elif "trashcan" in name:
            gc.cylinder(solid, "bin", x, z, y, y + 0.7, 0.26, 8)
            cnt("lixeira")
        elif "powerbox" in name:
            oriented(deco, "metal_gray", x + hd[0] * 0.1, z + hd[1] * 0.1, perp, 0.5, 0.22, y + 0.2, y + 0.9)
            cnt("caixa de força")
        elif "stove" in name:
            oriented(solid, "stove", x, z, hd, 0.8, 0.7, y, y + 0.9)
            cnt("fogão")
        elif "handrail" in name:
            oriented(deco, "handrail", x, z, hd, 2.4, 0.05, y + 0.92, y + 0.98)
            for sgn in (-1, 0, 1):
                gc.box_flat(deco, "handrail", x + hd[0] * 1.1 * sgn - 0.025, x + hd[0] * 1.1 * sgn + 0.025, y,
                            y + 0.95, z + hd[1] * 1.1 * sgn - 0.025, z + hd[1] * 1.1 * sgn + 0.025)
            cnt("corrimão")

    # ------------------------------------------------------- entidades de mobília
    for e in ents:
        c = e.get("classname", "")
        model = e.get("model", "").lower().split("/")[-1]
        if not (c.startswith("prop_physics") or c.startswith("prop_dynamic")) or "origin" not in e:
            continue
        o = tuple(map(float, e["origin"].split()))
        ang = tuple(map(float, e.get("angles", "0 0 0").split()))
        x, y, z = g(o)
        hd = heading(ang[1])
        if "desk" in model:
            oriented(solid, "desk_wood", x, z, hd, 1.8, 0.8, y + 0.7, y + 0.78)
            oriented(solid, "desk_wood", x, z, hd, 1.7, 0.7, y, y + 0.7)
            cnt("mesa")
        elif "filecabinet" in model:
            oriented(solid, "cabinet", x, z, hd, 0.5, 0.6, y, y + 1.3)
            cnt("arquivo")
        elif "fridge" in model:
            oriented(solid, "stove", x, z, hd, 0.75, 0.75, y, y + 1.75)
            cnt("geladeira")

    # --------------------------------------------------------------------- portas
    doors = Doors(obj)
    placed = skipped = 0
    for e in ents:
        if e.get("classname") != "prop_door_rotating" or "origin" not in e:
            continue
        o = tuple(map(float, e["origin"].split()))
        ang = tuple(map(float, e.get("angles", "0 0 0").split()))
        x, y, z = g(o)
        org_y[0] = y
        found = doors.find((x, z), heading(ang[1]))
        if not found:
            skipped += 1
            continue
        c, ax, yy = found
        # porta aberta (90 graus) ou entreaberta (70, 50, 30) para o lado livre; a dobradiça pode estar em qualquer ponta
        ends = [(c[0] - ax[0] * 0.46, c[1] - ax[1] * 0.46), (c[0] + ax[0] * 0.46, c[1] + ax[1] * 0.46)]
        done = False
        for hp, other in ((ends[0], ends[1]), (ends[1], ends[0])):
            closed = ((other[0] - hp[0]) / 0.92, (other[1] - hp[1]) / 0.92)
            for theta in (90, 70, 50, 30):
                th = math.radians(theta)
                for sw in ((-ax[1], ax[0]), (ax[1], -ax[0])):
                    d = (closed[0] * math.cos(th) + sw[0] * math.sin(th), closed[1] * math.cos(th) + sw[1] * math.sin(th))
                    pts = [(hp[0] + d[0] * t, yy + h, hp[1] + d[1] * t) for t in np.linspace(0.12, 0.9, 6) for h in (0.5, 1.0, 1.7)]
                    if not done and not doors.blocked(pts).any():
                        mid = (hp[0] + d[0] * 0.46, hp[1] + d[1] * 0.46)
                        oriented(deco, "door_paint", mid[0], mid[1], d, 0.92, 0.045, yy + 0.02, yy + 2.1)
                        kx, kz = hp[0] + d[0] * 0.8, hp[1] + d[1] * 0.8
                        gc.box_flat(deco, "door_knob", kx - 0.04, kx + 0.04, yy + 0.95, yy + 1.05, kz - 0.04, kz + 0.04)
                        done = True
        if done:
            placed += 1
        else:
            skipped += 1
    counts["portas abertas"] = placed
    counts["portas sem lugar (ignoradas)"] = skipped
    os.makedirs(out, exist_ok=True)
    solid.write(out, "map_props_solid")
    deco.write(out, "map_props_deco")
    for k, v in counts.items():
        print(f"  {k}: {v}")
    print("sólido: %d triângulos; deco: %d triângulos" % (solid.tris(), deco.tris()))


if __name__ == "__main__":
    if len(sys.argv) < 4:
        raise SystemExit(__doc__)
    build(sys.argv[1], sys.argv[2], sys.argv[3])
