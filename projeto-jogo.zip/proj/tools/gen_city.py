#!/usr/bin/env python3
"""
gen_city.py - gera a cidade ao redor do mapa convertido (OBJ).

Uso:  python tools/gen_city.py game/map/rp_downtown_vv1.obj game/city
Saída: city_solid.obj/.mtl (com colisão), city_deco.obj/.mtl (sem colisão),
       city_graph.json (nós/arestas das ruas, para o tráfego), tex/*.png
Requer: Python 3.8+ e Pillow.
"""
import json
import math
import os
import random
import shutil
import sys

from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))

GY = -3.658          # nível do chão do mapa (metros)
CURB = 0.06  # baixo o bastante para a cápsula do jogador subir
LY = GY + CURB       # nível das calçadas e lotes
SW, RW = 4.0, 14.0   # calçada e rua
COR = 2 * SW + RW    # corredor total = 22 m
FLOOR = 3.2
WB = 68.0            # largura dos quarteirões externos
K = 8                # camadas de quarteirões em volta do mapa
AVENUE_EVERY = 4     # a cada 4ª rua (contando a partir do mapa) é uma avenida
AVENUE_COR = 32.0    # corredor da avenida: calçada 4 + pista 24 + calçada 4
PROP_R = 520.0       # árvores, postes, carros etc. só até esta distância do mapa
SEED = 20261112

SHADES = [(0.80, 0.80, 0.80), (0.90, 0.90, 0.90), (1.0, 1.0, 1.0)]
TINTS = {
    "plaster": [(1.0, 0.97, 0.88), (0.96, 0.86, 0.78), (0.86, 0.91, 0.96)],
    "siding": [(1.0, 1.0, 1.0), (0.8, 0.88, 0.95), (0.95, 0.88, 0.7)],
    "brick": [(1.0, 1.0, 1.0), (0.9, 0.85, 0.8), (1.1, 0.95, 0.9)],
    "roof_tile": [(1.0, 1.0, 1.0), (0.7, 0.72, 0.8), (0.55, 0.5, 0.48)],
    "leafcard2": [(0.95, 1.0, 0.9), (1.2, 1.05, 0.7), (0.85, 1.0, 0.85)],
    "leafcard3": [(0.95, 1.0, 0.9), (1.15, 1.0, 0.7), (0.8, 0.95, 0.8)],
    "b_stucco": [(1.0, 0.97, 0.86), (1.0, 0.83, 0.77), (0.86, 0.97, 0.9)],
    "b_shop2": [(1.0, 1.0, 1.0), (1.0, 0.9, 0.85), (0.9, 0.95, 1.0)],
    "leafcard": [(0.92, 1.0, 0.88), (1.2, 1.05, 0.72), (0.78, 0.95, 0.8)],
    "b_glass": [(0.75, 0.9, 1.0), (0.85, 1.0, 0.95), (1.0, 1.0, 1.0)],
    "b_brick": [(1.0, 1.0, 1.0), (1.0, 0.9, 0.8), (0.85, 0.85, 0.95)],
    "b_concrete": [(1.0, 1.0, 1.0), (0.9, 0.95, 1.0), (1.0, 0.95, 0.85)],
    "b_office": [(1.0, 1.0, 1.0), (0.9, 0.95, 1.0), (1.0, 0.92, 0.85)],
    "b_shop": [(1.0, 1.0, 1.0), (1.0, 0.85, 0.8), (0.85, 0.95, 1.0)],
}
TEXTURED = {  # material base -> arquivo em tex/
    "road": "road", "avenue": "avenue", "crosswalk": "crosswalk", "asphalt": "asphalt",
    "sidewalk": "sidewalk", "grass": "grass", "b_roof": "b_roof",
    "leaves": "leaves", "bark": "bark", "concrete": "concrete",
    "plaster": "plaster", "brick": "brick", "siding": "siding",
    "leafcard": "leafcard", "leafcard2": "leafcard2", "leafcard3": "leafcard3", "b_stucco": "b_stucco", "b_shop2": "b_shop2", "pine": "pine", "roof_tile": "roof_tile",
    "b_glass": "b_glass", "b_brick": "b_brick", "b_concrete": "b_concrete",
    "b_office": "b_office", "b_shop": "b_shop",
}
FLAT = {
    "ledge": (0.72, 0.71, 0.68), "metal_gray": (0.46, 0.48, 0.52), "tank": (0.36, 0.27, 0.2),
    "awning_red": (0.72, 0.12, 0.1), "awning_blue": (0.12, 0.25, 0.55), "awning_green": (0.12, 0.42, 0.22),
    "awning_yellow": (0.85, 0.65, 0.12),
    "chimney": (0.5, 0.22, 0.16), "garage_door": (0.84, 0.84, 0.8), "door_wood": (0.33, 0.19, 0.1),
    "house_glass": (0.13, 0.2, 0.27), "house_glass_lit": (1.0, 0.82, 0.5),
    "shutter_a": (0.15, 0.3, 0.22), "shutter_b": (0.2, 0.22, 0.34), "fence_wood": (0.6, 0.5, 0.38),
    "pool_water": (0.15, 0.55, 0.75), "condo_wall": (0.8, 0.76, 0.68), "gate_bar": (0.1, 0.1, 0.12),
    "sign_green": (0.05, 0.35, 0.2), "bus_roof": (0.2, 0.25, 0.3), "tree_pit": (0.16, 0.11, 0.08),
    "stopline": (0.88, 0.88, 0.85), "hill": (0.27, 0.38, 0.24), "hill_dark": (0.19, 0.29, 0.20),
    "lamp_metal": (0.18, 0.19, 0.21), "lamp_head": (1.0, 0.92, 0.6),
    "tl_red": (0.9, 0.1, 0.1), "tl_yellow": (0.95, 0.8, 0.1), "tl_green": (0.1, 0.8, 0.25),
    "tl_body": (0.08, 0.08, 0.08), "hydrant": (0.75, 0.1, 0.08),
    "bench_wood": (0.45, 0.28, 0.14), "bin": (0.2, 0.3, 0.25),
    "car_glass": (0.12, 0.17, 0.22), "tire": (0.05, 0.05, 0.05),
    "car_red": (0.7, 0.1, 0.1), "car_blue": (0.1, 0.25, 0.6), "car_white": (0.88, 0.88, 0.9),
    "car_black": (0.07, 0.07, 0.08), "car_silver": (0.6, 0.62, 0.65), "car_yellow": (0.85, 0.7, 0.1),
    "car_green": (0.1, 0.4, 0.2),
}
CAR_MATS = ["car_red", "car_blue", "car_white", "car_black", "car_silver", "car_yellow", "car_green"]


# ------------------------------------------------------------------ malha
class Mesh:
    def __init__(self):
        self.v, self.vt, self.vn = [], [], []
        self.faces = {}  # material -> lista de triângulos [(v,vt,vn)*3]

    def poly(self, mat, pts, uvs, n):
        # orienta anti-horário em relação à normal n
        nx = ny = nz = 0.0
        for i in range(len(pts)):
            p, q = pts[i], pts[(i + 1) % len(pts)]
            nx += (p[1] - q[1]) * (p[2] + q[2])
            ny += (p[2] - q[2]) * (p[0] + q[0])
            nz += (p[0] - q[0]) * (p[1] + q[1])
        if nx * n[0] + ny * n[1] + nz * n[2] < 0:
            pts, uvs = pts[::-1], uvs[::-1]
        base = len(self.v)
        ni = len(self.vn) + 1
        self.vn.append(n)
        idx = []
        for k, p in enumerate(pts):
            self.v.append(p)
            self.vt.append(uvs[k])
            idx.append((base + k + 1, base + k + 1, ni))
        lst = self.faces.setdefault(mat, [])
        for i in range(1, len(idx) - 1):
            lst.append((idx[0], idx[i], idx[i + 1]))

    def tris(self):
        return sum(len(f) for f in self.faces.values())

    def write(self, folder, name):
        base = os.path.join(folder, name)
        with open(base + ".obj", "w") as f:
            f.write(f"mtllib {name}.mtl\n")
            for p in self.v:
                f.write(f"v {p[0]:.2f} {p[1]:.2f} {p[2]:.2f}\n")
            for t in self.vt:
                f.write(f"vt {t[0]:.3f} {t[1]:.3f}\n")
            for n in self.vn:
                f.write(f"vn {n[0]:.2f} {n[1]:.2f} {n[2]:.2f}\n")
            for mat in sorted(self.faces):
                f.write(f"o {mat}\nusemtl {mat}\n")
                for a, b, c in self.faces[mat]:
                    f.write("f %d/%d/%d %d/%d/%d %d/%d/%d\n" % (*a, *b, *c))
        with open(base + ".mtl", "w") as f:
            for mat in sorted(self.faces):
                f.write(material_text(mat))
        return base


class Chunked:
    """Divide a geometria em pedaços (para o celular desenhar só o que está à vista)."""

    def __init__(self, size=160.0):
        self.size = size
        self.meshes = {}

    def poly(self, mat, pts, uvs, n):
        cx = sum(p[0] for p in pts) / len(pts)
        cz = sum(p[2] for p in pts) / len(pts)
        key = (int(math.floor(cx / self.size)) + 40, int(math.floor(cz / self.size)) + 40)
        self.meshes.setdefault(key, Mesh()).poly(mat, pts, uvs, n)

    def tris(self):
        return sum(m.tris() for m in self.meshes.values())

    def mat_count(self):
        return len({k for m in self.meshes.values() for k in m.faces})

    def write(self, folder, prefix):
        names = []
        for (ix, iz), m in sorted(self.meshes.items()):
            name = f"{prefix}_{ix}_{iz}"
            m.write(folder, name)
            names.append(name)
        return names


def split_variant(mat):
    """b_brick_2 -> ('b_brick', 2)"""
    parts = mat.rsplit("_", 1)
    if len(parts) == 2 and parts[1].isdigit() and parts[0] in TEXTURED:
        return parts[0], int(parts[1])
    return mat, None


def material_text(mat):
    base, var = split_variant(mat)
    s = f"newmtl {mat}\nKa 1 1 1\n"
    if base in TEXTURED:
        kd = (1.0, 1.0, 1.0)
        if var is not None:
            sh = SHADES[var]
            tn = TINTS.get(base, [(1, 1, 1)] * 3)[var]
            kd = (sh[0] * tn[0], sh[1] * tn[1], sh[2] * tn[2])
        s += f"Kd {kd[0]:.3f} {kd[1]:.3f} {kd[2]:.3f}\nmap_Kd tex/{TEXTURED[base]}.png\n"
    else:
        c = FLAT.get(mat, (0.6, 0.6, 0.6))
        s += f"Kd {c[0]:.3f} {c[1]:.3f} {c[2]:.3f}\n"
    return s + "\n"


UP = (0, 1, 0)


def ground_quad(m, mat, x0, z0, x1, z1, y, tile=2.4):
    pts = [(x0, y, z0), (x1, y, z0), (x1, y, z1), (x0, y, z1)]
    uvs = [(x0 / tile, z0 / tile), (x1 / tile, z0 / tile), (x1 / tile, z1 / tile), (x0 / tile, z1 / tile)]
    m.poly(mat, pts, uvs, UP)


def wall(m, mat, a, b, y0, y1, n, u_per_m, v0, v_per_m, u0=0.0):
    """Parede entre os pontos a=(x,z) e b=(x,z)."""
    L = math.hypot(b[0] - a[0], b[1] - a[1])
    pts = [(a[0], y0, a[1]), (b[0], y0, b[1]), (b[0], y1, b[1]), (a[0], y1, a[1])]
    uvs = [(u0, v0), (u0 + L * u_per_m, v0), (u0 + L * u_per_m, v0 + (y1 - y0) * v_per_m),
           (u0, v0 + (y1 - y0) * v_per_m)]
    m.poly(mat, pts, uvs, n)


def box_flat(m, mat, x0, x1, y0, y1, z0, z1, bottom=False):
    z = (0, 0)
    faces = [
        ([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], (0, 0, -1)),
        ([(x1, y0, z1), (x0, y0, z1), (x0, y1, z1), (x1, y1, z1)], (0, 0, 1)),
        ([(x0, y0, z1), (x0, y0, z0), (x0, y1, z0), (x0, y1, z1)], (-1, 0, 0)),
        ([(x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)], (1, 0, 0)),
        ([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)], (0, 1, 0)),
    ]
    if bottom:
        faces.append(([(x0, y0, z1), (x1, y0, z1), (x1, y0, z0), (x0, y0, z0)], (0, -1, 0)))
    for pts, n in faces:
        m.poly(mat, pts, [z] * 4, n)


def cylinder(m, mat, cx, cz, y0, y1, r, sides=6, cap=True):
    ring = [(cx + r * math.cos(2 * math.pi * i / sides), cz + r * math.sin(2 * math.pi * i / sides))
            for i in range(sides)]
    for i in range(sides):
        a, b = ring[i], ring[(i + 1) % sides]
        mid = (a[0] + b[0]) / 2 - cx, (a[1] + b[1]) / 2 - cz
        L = math.hypot(*mid) or 1
        n = (mid[0] / L, 0, mid[1] / L)
        m.poly(mat, [(a[0], y0, a[1]), (b[0], y0, b[1]), (b[0], y1, b[1]), (a[0], y1, a[1])], [(0, 0)] * 4, n)
    if cap:
        m.poly(mat, [(p[0], y1, p[1]) for p in ring], [(0, 0)] * sides, UP)


def cone(m, mat, cx, cz, y0, y1, r, sides=7):
    ring = [(cx + r * math.cos(2 * math.pi * i / sides), cz + r * math.sin(2 * math.pi * i / sides))
            for i in range(sides)]
    for i in range(sides):
        a, b = ring[i], ring[(i + 1) % sides]
        mx, mz = (a[0] + b[0]) / 2 - cx, (a[1] + b[1]) / 2 - cz
        L = math.hypot(mx, mz) or 1
        n = (mx / L, 0.5, mz / L)
        m.poly(mat, [(a[0], y0, a[1]), (b[0], y0, b[1]), (cx, y1, cz)], [(0, 0)] * 3, n)


_PHI = (1 + 5 ** 0.5) / 2
_IV = [(-1, _PHI, 0), (1, _PHI, 0), (-1, -_PHI, 0), (1, -_PHI, 0), (0, -1, _PHI), (0, 1, _PHI),
       (0, -1, -_PHI), (0, 1, -_PHI), (_PHI, 0, -1), (_PHI, 0, 1), (-_PHI, 0, -1), (-_PHI, 0, 1)]
_IF = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2),
       (10, 7, 6), (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5),
       (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]


def blob(m, mat, cx, cy, cz, rx, ry, rz, rnd):
    jit = [(1 + rnd.uniform(-0.15, 0.15)) for _ in _IV]
    pts = []
    for (x, y, z), j in zip(_IV, jit):
        L = math.sqrt(x * x + y * y + z * z)
        pts.append((cx + x / L * rx * j, cy + y / L * ry * j, cz + z / L * rz * j))
    for a, b, c in _IF:
        p = [pts[a], pts[b], pts[c]]
        mx = sum(q[0] for q in p) / 3 - cx
        my = sum(q[1] for q in p) / 3 - cy
        mz = sum(q[2] for q in p) / 3 - cz
        L = math.sqrt(mx * mx + my * my + mz * mz) or 1
        m.poly(mat, p, [(0, 0), (1, 0), (0.5, 1)], (mx / L, my / L, mz / L))


# ---------------------------------------------------------------- mapa base
def read_map(obj_path):
    verts, tris = [], []
    for line in open(obj_path):
        if line.startswith("v "):
            _, x, y, z = line.split()
            verts.append((float(x), float(y), float(z)))
        elif line.startswith("f "):
            idx = [int(t.split("/")[0]) - 1 for t in line.split()[1:]]
            for i in range(1, len(idx) - 1):
                tris.append((idx[0], idx[i], idx[i + 1]))
    return verts, tris


def occupancy(verts, tris, bbox, res=0.5, grow=0.0):
    x0, x1, z0, z1 = bbox
    W, H = int((x1 - x0) / res) + 2, int((z1 - z0) / res) + 2
    img = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(img)
    for a, b, c in tris:
        pts = [((verts[i][0] - x0) / res, (verts[i][2] - z0) / res) for i in (a, b, c)]
        d.polygon(pts, fill=255, outline=255)
    if grow > 0:
        k = int(grow / res) * 2 + 1
        img = img.filter(ImageFilter.MaxFilter(k))
    return img, res


def fill_voids(m, img, res, bbox, cell=0.5):
    """Preenche com piso de praça as células vazias dentro da caixa do mapa."""
    x0, x1, z0, z1 = bbox
    px = img.load()
    W, H = img.size
    step = int(cell / res)
    nx, nz = int((x1 - x0) / cell) + 1, int((z1 - z0) / cell) + 1
    empty = [[True] * nx for _ in range(nz)]
    for j in range(nz):
        for i in range(nx):
            for yy in range(j * step, min((j + 1) * step, H)):
                if not empty[j][i]:
                    break
                for xx in range(i * step, min((i + 1) * step, W)):
                    if px[xx, yy]:
                        empty[j][i] = False
                        break
    count = 0
    for j in range(nz):  # mescla células em faixas horizontais
        i = 0
        while i < nx:
            if empty[j][i]:
                s = i
                while i < nx and empty[j][i]:
                    i += 1
                ground_quad(m, "sidewalk", x0 + s * cell, z0 + j * cell, x0 + i * cell, z0 + (j + 1) * cell, GY - 0.005)
                count += i - s
            else:
                i += 1
    return count


# ----------------------------------------------------------------- layout
def cor_w(dist):
    """Largura do corredor a 'dist' ruas de distância do mapa (0 = rua de contorno)."""
    return AVENUE_COR if (dist + 1) % AVENUE_EVERY == 0 else COR


def axis_layout(lo, hi):
    """Sequência de ('B', a, b, tipo) e ('C', a, b) ao longo de um eixo."""
    span = hi - lo
    wm = (span - COR) / 2.0
    seq = []
    cur = lo - sum(WB + cor_w(d) for d in range(K))
    for idx in range(K):
        w = cor_w(K - 1 - idx)
        seq.append(("B", cur, cur + WB, "ext")); cur += WB
        seq.append(("C", cur, cur + w)); cur += w
    seq.append(("B", cur, cur + wm, "mid")); cur += wm
    seq.append(("C", cur, cur + COR)); cur += COR
    seq.append(("B", cur, cur + wm, "mid")); cur += wm
    for d in range(K):
        w = cor_w(d)
        seq.append(("C", cur, cur + w)); cur += w
        seq.append(("B", cur, cur + WB, "ext")); cur += WB
    return seq


def inside(bbox, xa, xb, za, zb, eps=0.5):
    return xa >= bbox[0] - eps and xb <= bbox[1] + eps and za >= bbox[2] - eps and zb <= bbox[3] + eps


def texture_ok(name):
    return os.path.isfile(os.path.join(HERE, "textures", name + ".png"))


# ------------------------------------------------------------- construção
import city_parts  # noqa: E402

city_parts.bind(globals())
build_building = city_parts.build_building
build_tree = city_parts.build_tree


def build_lots(solid, deco, rnd, rect, floors_range, styles_w, park, props, detail=0):
    bx0, bx1, bz0, bz1 = rect
    ground_quad(solid, "grass" if park else "sidewalk", bx0, bz0, bx1, bz1, LY)
    if park:
        w, d = bx1 - bx0, bz1 - bz0
        for _ in range(int(w * d / 90)):
            tx, tz = rnd.uniform(bx0 + 3, bx1 - 3), rnd.uniform(bz0 + 3, bz1 - 3)
            props["trees"].append((tx, tz, rnd.random() < 0.3))
        for _ in range(int(w * d / 220)):
            props["trees"].append((rnd.uniform(bx0 + 2, bx1 - 2), rnd.uniform(bz0 + 2, bz1 - 2), "bush"))
        for _ in range(4):
            props["benches"].append((rnd.uniform(bx0 + 6, bx1 - 6), rnd.uniform(bz0 + 6, bz1 - 6), rnd.choice([0, 1])))
        props["lamps_free"].append(((bx0 + bx1) / 2, (bz0 + bz1) / 2))
        return
    nx = rnd.choice([2, 3, 3]) if (bx1 - bx0) > 55 else rnd.choice([1, 2])
    nz = rnd.choice([2, 2, 3]) if (bz1 - bz0) > 45 else rnd.choice([1, 2])
    xs = [bx0] + [bx0 + (bx1 - bx0) * (i + rnd.uniform(-0.12, 0.12)) / nx for i in range(1, nx)] + [bx1]
    zs = [bz0] + [bz0 + (bz1 - bz0) * (j + rnd.uniform(-0.12, 0.12)) / nz for j in range(1, nz)] + [bz1]
    for i in range(nx):
        for j in range(nz):
            lx0, lx1 = xs[i] + 1.5, xs[i + 1] - 1.5
            lz0, lz1 = zs[j] + 1.5, zs[j + 1] - 1.5
            w = math.floor((lx1 - lx0) / 3.2) * 3.2
            d = math.floor((lz1 - lz0) / 3.2) * 3.2
            if w < 9.6 or d < 9.6:
                continue
            cx, cz = (lx0 + lx1) / 2, (lz0 + lz1) / 2
            f = rnd.randint(*floors_range)
            style = rnd.choices(["b_glass", "b_brick", "b_concrete", "b_office", "b_stucco"],
                                list(styles_w) + [3 if floors_range[1] <= 9 else 1])[0]
            build_building(solid, deco, rnd, (cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2), f, style,
                           rnd.randint(0, 2), rnd.randint(0, 2), detail)


def corner_props(props, x, z, sx, sz):
    props["tlights"].append((x, z, sx, sz))


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    obj_path, out = sys.argv[1], sys.argv[2]
    rnd = random.Random(SEED)
    os.makedirs(os.path.join(out, "tex"), exist_ok=True)

    verts, tris = read_map(obj_path)
    xs = [v[0] for v in verts]
    zs = [v[2] for v in verts]
    bbox = (min(xs) - 1.0, max(xs) + 1.0, min(zs) - 1.0, max(zs) + 1.0)
    x0, x1, z0, z1 = bbox
    mx, mz = (x0 + x1) / 2, (z0 + z1) / 2
    print("mapa: X %.1f..%.1f  Z %.1f..%.1f" % (x0, x1, z0, z1))

    solid, deco = Chunked(), Chunked()
    props = {"trees": [], "benches": [], "lamps_free": [], "lamps": [], "hydrants": [], "bins": [],
             "cars": [], "tlights": [], "buses": []}

    # --- vazios da praça
    img, res = occupancy(verts, tris, bbox)
    n = fill_voids(solid, img, res, bbox)
    print("células de praça preenchidas:", n)

    X = axis_layout(x0, x1)
    Z = axis_layout(z0, z1)
    nodes, node_idx, edges = [], {}, []

    def node(i, j):
        if (i, j) not in node_idx:
            xa, xb = X[i][1], X[i][2]
            za, zb = Z[j][1], Z[j][2]
            node_idx[(i, j)] = len(nodes)
            nodes.append([round((xa + xb) / 2, 2), round((za + zb) / 2, 2)])
        return node_idx[(i, j)]

    # --- condomínios: 3 quarteirões escolhidos em faixas de distância e direções diferentes
    crnd = random.Random(SEED + 7)
    cands = []
    for i, bx in enumerate(X):
        for j, bz in enumerate(Z):
            if bx[0] == "B" and bz[0] == "B" and bx[3] == "ext" and bz[3] == "ext":
                cx, cz = (bx[1] + bx[2]) / 2, (bz[1] + bz[2]) / 2
                cands.append((i, j, math.hypot(cx - mx, cz - mz), math.atan2(cz - mz, cx - mx)))
    condos, condo_set = [], set()
    for (rlo, rhi), nh in (((130, 230), 5), ((240, 340), 6), ((350, 470), 10)):
        pool = [c for c in cands if rlo <= c[2] <= rhi and all(
            abs(math.atan2(math.sin(c[3] - o[3]), math.cos(c[3] - o[3]))) > 1.5 for o in condos)]
        if not pool:
            pool = [c for c in cands if rlo <= c[2] <= rhi]
        c = crnd.choice(pool)
        condos.append(c)
        condo_set.add((c[0], c[1]))
    condo_info = []
    for (ci, cj, _r, _a), nh in zip(condos, (5, 6, 10)):
        bx, bz = X[ci], Z[cj]
        gate_hi = 1 if ((bz[1] + bz[2]) / 2) < mz else 0   # portão virado para o lado do mapa
        condo_info.append([round(bx[1], 2), round(bx[2], 2), round(bz[1], 2), round(bz[2], 2), nh, gate_hi])
    print("condomínios:", condo_info)

    # --- quarteirões
    for i, bx in enumerate(X):
        if bx[0] != "B":
            continue
        for j, bz in enumerate(Z):
            if bz[0] != "B":
                continue
            if bx[3] == "mid" and bz[3] == "mid":
                continue
            if (i, j) in condo_set:
                continue
            rect = (bx[1], bx[2], bz[1], bz[2])
            cx, cz = (rect[0] + rect[1]) / 2, (rect[2] + rect[3]) / 2
            r = math.hypot(cx - mx, cz - mz)
            if r < 150:
                fr, w = (3, 8), [1, 4, 3, 2]
            elif r < 300:
                fr, w = (6, 16), [4, 2, 2, 4]
            elif r < 450:
                fr, w = (3, 9), [2, 3, 3, 3]
            else:
                fr, w = (2, 5), [0, 5, 5, 1]
            park = r > 100 and rnd.random() < 0.13
            detail = 2 if r < 260 else (1 if r < 480 else 0)
            build_lots(solid, deco, rnd, rect, fr, w, park, props, detail)

    # --- ruas
    def road_tex_quad(xa, xb, za, zb, vertical):
        # asfalto com faixas; u atravessa a rua, v corre ao longo (a textura é quadrada e cobre a largura)
        rw = (xb - xa) if vertical else (zb - za)
        mat = "avenue" if rw > 20 else "road"
        pts = [(xa, GY, za), (xb, GY, za), (xb, GY, zb), (xa, GY, zb)]
        if vertical:
            uvs = [(0, za / rw), (1, za / rw), (1, zb / rw), (0, zb / rw)]
        else:
            uvs = [(xa / rw, 0), (xb / rw, 0), (xb / rw, 1), (xa / rw, 1)]
        solid.poly(mat, pts, uvs, UP)

    def curb_face(a, b, n):
        wall(solid, "sidewalk", a, b, GY, LY, n, 1 / 2.4, 0.0, 1 / 2.4)

    for i, cx_ in enumerate(X):
        for j, cz_ in enumerate(Z):
            tx, tz = cx_[0], cz_[0]
            # segmento vertical: corredor em X, bloco em Z
            if tx == "C" and tz == "B":
                xa, xb, za, zb = cx_[1], cx_[2], cz_[1], cz_[2]
                if inside(bbox, xa, xb, za, zb):
                    continue
                road_tex_quad(xa + SW, xb - SW, za, zb, True)
                ground_quad(solid, "sidewalk", xa, za, xa + SW, zb, LY)
                ground_quad(solid, "sidewalk", xb - SW, za, xb, zb, LY)
                curb_face((xa + SW, za), (xa + SW, zb), (1, 0, 0))
                curb_face((xb - SW, za), (xb - SW, zb), (-1, 0, 0))
                L = zb - za
                if xb - xa > 30:  # avenida: canteiro central arborizado
                    xc = (xa + xb) / 2
                    ground_quad(solid, "grass", xc - 1.0, za, xc + 1.0, zb, LY, 4.0)
                    curb_face((xc - 1.0, za), (xc - 1.0, zb), (-1, 0, 0))
                    curb_face((xc + 1.0, za), (xc + 1.0, zb), (1, 0, 0))
                    for s_ in range(6, int(L) - 4, 12):
                        props["trees"].append((xc, za + s_, False))
                    props["buses"].append((xa + SW - 1.4, za + L * 0.5, "z"))
                for s in range(6, int(L) - 4, 13):
                    for side, px in ((0, xa + 1.2), (1, xb - 1.2)):
                        if rnd.random() < 0.75:
                            props["trees"].append((px, za + s + (7 if side else 0), False))
                for k, s in enumerate(range(10, int(L) - 6, 28)):
                    props["lamps"].append((xa + 0.7, za + s, 1))
                    props["lamps"].append((xb - 0.7, za + s + 14, -1))
                if rnd.random() < 0.5:
                    for s in (L * 0.25, L * 0.7):
                        props["hydrants"].append((xa + 0.9, za + s))
                for s in range(20, int(L) - 10, 40):
                    props["bins"].append((xa + 1.0, za + s))
                    props["bins"].append((xb - 1.0, za + s + 20))
                for s in range(10, int(L) - 8, 6):
                    if rnd.random() < 0.28:
                        props["cars"].append((xa + SW + 1.25, za + s, "z", rnd.choice(CAR_MATS)))
                    if rnd.random() < 0.28:
                        props["cars"].append((xb - SW - 1.25, za + s, "z", rnd.choice(CAR_MATS)))
            # segmento horizontal: corredor em Z, bloco em X
            elif tx == "B" and tz == "C":
                xa, xb, za, zb = cx_[1], cx_[2], cz_[1], cz_[2]
                if inside(bbox, xa, xb, za, zb):
                    continue
                road_tex_quad(xa, xb, za + SW, zb - SW, False)
                ground_quad(solid, "sidewalk", xa, za, xb, za + SW, LY)
                ground_quad(solid, "sidewalk", xa, zb - SW, xb, zb, LY)
                curb_face((xa, za + SW), (xb, za + SW), (0, 0, 1))
                curb_face((xa, zb - SW), (xb, zb - SW), (0, 0, -1))
                L = xb - xa
                if zb - za > 30:  # avenida: canteiro central arborizado
                    zc = (za + zb) / 2
                    ground_quad(solid, "grass", xa, zc - 1.0, xb, zc + 1.0, LY, 4.0)
                    curb_face((xa, zc - 1.0), (xb, zc - 1.0), (0, 0, -1))
                    curb_face((xa, zc + 1.0), (xb, zc + 1.0), (0, 0, 1))
                    for s_ in range(6, int(L) - 4, 12):
                        props["trees"].append((xa + s_, zc, False))
                    props["buses"].append((xa + L * 0.5, za + SW - 1.4, "x"))
                for s in range(6, int(L) - 4, 13):
                    for side, pz in ((0, za + 1.2), (1, zb - 1.2)):
                        if rnd.random() < 0.75:
                            props["trees"].append((xa + s + (7 if side else 0), pz, False))
                for s in range(10, int(L) - 6, 28):
                    props["lamps"].append((xa + s, za + 0.7, 2))
                    props["lamps"].append((xa + s + 14, zb - 0.7, -2))
                for s in range(10, int(L) - 8, 6):
                    if rnd.random() < 0.28:
                        props["cars"].append((xa + s, za + SW + 1.25, "x", rnd.choice(CAR_MATS)))
                    if rnd.random() < 0.28:
                        props["cars"].append((xa + s, zb - SW - 1.25, "x", rnd.choice(CAR_MATS)))
            # cruzamento
            elif tx == "C" and tz == "C":
                xa, xb, za, zb = cx_[1], cx_[2], cz_[1], cz_[2]
                if inside(bbox, xa, xb, za, zb):
                    continue
                solid.poly("asphalt", [(xa + SW, GY, za + SW), (xb - SW, GY, za + SW), (xb - SW, GY, zb - SW),
                                       (xa + SW, GY, zb - SW)],
                           [((xa + SW) / 2.4, (za + SW) / 2.4), ((xb - SW) / 2.4, (za + SW) / 2.4),
                            ((xb - SW) / 2.4, (zb - SW) / 2.4), ((xa + SW) / 2.4, (zb - SW) / 2.4)], UP)
                # quatro "braços" de 4 m
                arms = [
                    ((xa + SW, xb - SW, za, za + SW), "z", -1),
                    ((xa + SW, xb - SW, zb - SW, zb), "z", 1),
                    ((xa, xa + SW, za + SW, zb - SW), "x", -1),
                    ((xb - SW, xb, za + SW, zb - SW), "x", 1),
                ]
                xc, zc = (xa + xb) / 2, (za + zb) / 2

                def seg_exists(di, dj):
                    ii, jj = i + di, j + dj
                    if not (0 <= ii < len(X) and 0 <= jj < len(Z)):
                        return False
                    return not inside(bbox, X[ii][1], X[ii][2], Z[jj][1], Z[jj][2])

                for (ax0, ax1, az0, az1), axis, sgn in arms:
                    solid.poly("asphalt", [(ax0, GY, az0), (ax1, GY, az0), (ax1, GY, az1), (ax0, GY, az1)],
                               [(ax0 / 2.4, az0 / 2.4), (ax1 / 2.4, az0 / 2.4), (ax1 / 2.4, az1 / 2.4), (ax0 / 2.4, az1 / 2.4)], UP)
                    # faixa de pedestres (sobre o braço)
                    cy = GY + 0.03
                    if axis == "z":
                        z_a, z_b = (az0 + 0.4, az1 - 0.4)
                        pts = [(ax0, cy, z_a), (ax1, cy, z_a), (ax1, cy, z_b), (ax0, cy, z_b)]
                        kk = (ax1 - ax0) / 14.0
                        uvs = [(0, 0), (kk, 0), (kk, 1), (0, 1)]
                    else:
                        x_a, x_b = (ax0 + 0.4, ax1 - 0.4)
                        pts = [(x_a, cy, az0), (x_b, cy, az0), (x_b, cy, az1), (x_a, cy, az1)]
                        kk = (az1 - az0) / 14.0
                        uvs = [(0, 0), (0, 1), (kk, 1), (kk, 0)]
                    solid.poly("crosswalk", pts, uvs, UP)
                    # linha de parada na faixa de quem se aproxima (mão direita), se houver rua adiante
                    if axis == "z" and seg_exists(0, sgn):
                        gap = 1.2 if (xb - xa) > 30 else 0.3
                        if sgn < 0:
                            lx0, lx1, lz0, lz1 = xa + SW + 2.5, xc - gap, za - 0.9, za - 0.4
                        else:
                            lx0, lx1, lz0, lz1 = xc + gap, xb - SW - 2.5, zb + 0.4, zb + 0.9
                        solid.poly("stopline", [(lx0, cy, lz0), (lx1, cy, lz0), (lx1, cy, lz1), (lx0, cy, lz1)], [(0, 0)] * 4, UP)
                    elif axis == "x" and seg_exists(sgn, 0):
                        gap = 1.2 if (zb - za) > 30 else 0.3
                        if sgn < 0:
                            lx0, lx1, lz0, lz1 = xa - 0.9, xa - 0.4, zc + gap, zb - SW - 2.5
                        else:
                            lx0, lx1, lz0, lz1 = xb + 0.4, xb + 0.9, za + SW + 2.5, zc - gap
                        solid.poly("stopline", [(lx0, cy, lz0), (lx1, cy, lz0), (lx1, cy, lz1), (lx0, cy, lz1)], [(0, 0)] * 4, UP)
                # cantos elevados
                corners = [(xa, za, 1, 1), (xb - SW, za, -1, 1), (xa, zb - SW, 1, -1), (xb - SW, zb - SW, -1, -1)]
                for cx0, cz0, sx, sz in corners:
                    ground_quad(solid, "sidewalk", cx0, cz0, cx0 + SW, cz0 + SW, LY)
                    ix = cx0 + SW if sx > 0 else cx0
                    iz = cz0 + SW if sz > 0 else cz0
                    curb_face((ix, cz0), (ix, cz0 + SW), (sx, 0, 0))
                    curb_face((cx0, iz), (cx0 + SW, iz), (0, 0, sz))
                    props["tlights"].append((ix - sx * 0.6, iz - sz * 0.6, sx, sz))
                node(i, j)

    # arestas do grafo de ruas
    for (i, j), a in node_idx.items():
        for di, dj in ((2, 0), (0, 2)):
            nb = (i + di, j + dj)
            if nb not in node_idx:
                continue
            mi, mj = i + di // 2, j + dj // 2
            xa, xb = (X[mi][1], X[mi][2]) if di else (X[i][1], X[i][2])
            za, zb = (Z[mj][1], Z[mj][2]) if dj else (Z[j][1], Z[j][2])
            if inside(bbox, xa, xb, za, zb):
                continue
            width = (Z[j][2] - Z[j][1]) if di else (X[i][2] - X[i][1])
            lane = 3.1 if width > 30 else 2.25
            side = (width - 2 * SW) / 2.0 + 2.0
            edges.append([a, node_idx[nb], lane, side])

    # --- props (só perto do mapa, para não pesar no celular)
    for key in props:
        props[key] = [p for p in props[key] if math.hypot(p[0] - mx, p[1] - mz) < PROP_R]

    t_count = 0
    for tx, tz, kind in props["trees"]:
        if kind is False:
            ground_quad(solid, "tree_pit", tx - 0.7, tz - 0.7, tx + 0.7, tz + 0.7, LY + 0.012, 4.0)
        build_tree(solid, deco, rnd, tx, tz, kind)
        t_count += 1

    for lx, lz, kind in props["lamps"]:
        cylinder(solid, "lamp_metal", lx, lz, LY, LY + 7.0, 0.08, 6, cap=False)
        # braço apontando para a rua
        dx, dz = {1: (1, 0), -1: (-1, 0), 2: (0, 1), -2: (0, -1)}[kind]
        ex, ez = lx + dx * 1.6, lz + dz * 1.6
        box_flat(deco, "lamp_metal", min(lx, ex) - 0.05, max(lx, ex) + 0.05, LY + 6.95, LY + 7.05, min(lz, ez) - 0.05, max(lz, ez) + 0.05)
        box_flat(deco, "lamp_head", ex - 0.3, ex + 0.3, LY + 6.8, LY + 6.95, ez - 0.2, ez + 0.2, bottom=True)
    for lx, lz in props["lamps_free"]:
        cylinder(solid, "lamp_metal", lx, lz, LY, LY + 5.0, 0.07, 6, cap=False)
        box_flat(deco, "lamp_head", lx - 0.35, lx + 0.35, LY + 5.0, LY + 5.15, lz - 0.35, lz + 0.35, bottom=True)
    for hx, hz in props["hydrants"]:
        cylinder(solid, "hydrant", hx, hz, LY, LY + 0.75, 0.17, 6)
    for bx, bz, ori in props["benches"]:
        if ori:
            box_flat(solid, "bench_wood", bx - 0.9, bx + 0.9, LY + 0.4, LY + 0.5, bz - 0.25, bz + 0.25)
            box_flat(deco, "bench_wood", bx - 0.9, bx + 0.9, LY + 0.5, LY + 0.95, bz + 0.2, bz + 0.27)
        else:
            box_flat(solid, "bench_wood", bx - 0.25, bx + 0.25, LY + 0.4, LY + 0.5, bz - 0.9, bz + 0.9)
            box_flat(deco, "bench_wood", bx + 0.2, bx + 0.27, LY + 0.5, LY + 0.95, bz - 0.9, bz + 0.9)
    for tx, tz, sx, sz in props["tlights"]:
        city_parts.traffic_signal(solid, deco, tx, tz, sx, sz, with_sign=(sx > 0 and sz > 0))
    for bx, bz, ax in props["buses"]:
        city_parts.bus_stop(solid, deco, bx, bz, ax)
    for bx, bz in props["bins"]:
        cylinder(solid, "bin", bx, bz, LY, LY + 0.9, 0.26, 8)
    for cx_, cz_, axis, cm in props["cars"]:
        if axis == "z":
            bx0, bx1, bz0, bz1 = cx_ - 0.9, cx_ + 0.9, cz_ - 2.2, cz_ + 2.2
            cb = (cx_ - 0.8, cx_ + 0.8, cz_ - 1.0, cz_ + 1.1)
        else:
            bx0, bx1, bz0, bz1 = cx_ - 2.2, cx_ + 2.2, cz_ - 0.9, cz_ + 0.9
            cb = (cx_ - 1.0, cx_ + 1.1, cz_ - 0.8, cz_ + 0.8)
        box_flat(solid, cm, bx0, bx1, GY + 0.25, GY + 0.95, bz0, bz1)
        box_flat(solid, "car_glass", cb[0], cb[1], GY + 0.95, GY + 1.5, cb[2], cb[3])

    # --- terreno de fundo (grama), enorme
    R = 2600
    ground_quad(solid, "grass", mx - R, mz - R, mx + R, mz + R, GY - 0.08, 4.0)

    scen = Mesh()
    for k in range(48):
        ang = 2 * math.pi * k / 48 + rnd.uniform(-0.05, 0.05)
        rad = rnd.uniform(1350, 1550)
        hx, hz = mx + rad * math.cos(ang), mz + rad * math.sin(ang)
        mat = "hill" if rnd.random() < 0.6 else "hill_dark"
        blob(scen, mat, hx, GY - 25, hz, rnd.uniform(220, 380), rnd.uniform(90, 170), rnd.uniform(220, 380), rnd)
        blob(scen, mat, hx + rnd.uniform(-150, 150), GY - 40, hz + rnd.uniform(-150, 150),
             rnd.uniform(160, 260), rnd.uniform(60, 120), rnd.uniform(160, 260), rnd)

    folder = out
    scen.write(folder, "city_scenery")
    solid_names = solid.write(folder, "city_solid")
    deco_names = deco.write(folder, "city_deco")
    with open(os.path.join(folder, "city_data.gd"), "w") as f:
        f.write("extends RefCounted\n# Gerado por tools/gen_city.py - não edite.\n")
        f.write(f"const ROAD_Y = {GY}\n")
        f.write("const SOLID = " + json.dumps(solid_names) + "\n")
        f.write("const DECO = " + json.dumps(deco_names) + "\n")
        f.write('const SCENERY = "city_scenery"\n')
        f.write("const CONDOS = " + json.dumps(condo_info) + "\n")
        f.write("const NODES = " + json.dumps(nodes) + "\n")
        f.write("const EDGES = " + json.dumps(edges) + "\n")

    # texturas usadas
    for name in set(TEXTURED.values()):
        for src_dir in (os.path.join(HERE, "textures"), os.path.join(HERE, "textures_city")):
            src = os.path.join(src_dir, name + ".png")
            if os.path.isfile(src):
                shutil.copy(src, os.path.join(out, "tex", name + ".png"))
                for suffix in ("_n", "_e"):  # relevo e luzes das janelas, se existirem
                    for sd in ("textures_city", "textures"):
                        extra = os.path.join(HERE, sd, name + suffix + ".png")
                        if os.path.isfile(extra):
                            shutil.copy(extra, os.path.join(out, "tex", name + suffix + ".png"))
                            break
                break
        else:
            print("AVISO: textura ausente:", name)

    print("sólido: %d triângulos, %d pedaços" % (solid.tris(), len(solid_names)))
    print("deco:   %d triângulos, %d pedaços" % (deco.tris(), len(deco_names)))
    print("árvores %d, postes %d, carros %d, semáforos %d, nós %d, arestas %d" % (
        t_count, len(props["lamps"]), len(props["cars"]), len(props["tlights"]), len(nodes), len(edges)))
    print("tamanho total ≈ %.0f m × %.0f m" % (X[-1][2] - X[0][1], Z[-1][2] - Z[0][1]))
    return props, X, Z, bbox


if __name__ == "__main__":
    main()
