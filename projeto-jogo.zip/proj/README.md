# Mundo aberto de teste (Godot + mapa BSP convertido)

## Estrutura
- `game/`   projeto Godot 4.3 (mapa já convertido em `game/map/`)
- `tools/bsp2obj.py`   conversor BSP -> OBJ (usado só se quiser reconverter)
- `.github/workflows/build-apk.yml`   gera o APK
- `.github/workflows/converter-mapa.yml`   só converte o mapa (opcional, com recorte)

## Gerar o APK (pelo Termux)
1. `git init`, `git add .`, `git commit -m "jogo"`, crie o repositório no GitHub e `git push`.
2. GitHub > Actions > "Gerar APK (Godot)" > Run workflow.
3. Quando terminar, baixe o artifact `jogo-apk`, extraia e instale `jogo.apk`.

(O `.bsp` é opcional: se colocar em `maps/rp_downtown_vv1.bsp`, o workflow reconverte.)

## Controles
- Esquerda da tela: analógico (andar / acelerar e virar no carro)
- Direita da tela: arrastar para girar a câmera
- Botões: Pular, Entrar/Sair (perto do carro), Resetar carro
- No PC: WASD e arrastar com o mouse

## Ajustes rápidos
- Carro andando de ré ou direção invertida: `DRIVE_SIGN` / `STEER_SIGN` em `game/car.gd`
- Ponto de início: `SPAWN` em `game/main.gd`

## Texturas
O conversor usa texturas procedurais de `tools/textures/` (tijolo, pedra, concreto, madeira,
metal, vidro, fachadas, vitrines...) escolhidas pelo nome do material. Para regerá-las:
`pip install numpy pillow && python tools/make_textures.py`.
Se você tiver as texturas reais do jogo, coloque numa pasta `content/` (com `materials/`) e use `--content`.

## Desempenho
Se ficar pesado no celular, em `game/main.gd` troque `SHADOWS` para `false`.

## Cidade ao redor do mapa
`tools/gen_city.py` gera uma cidade de ~1 km x 1 km em volta do mapa: ruas com faixas, calçadas,
faixas de pedestres, quarteirões com prédios de vários estilos, parques, árvores, postes,
semáforos, hidrantes, bancos e carros estacionados. O resultado fica em `game/city/`
(pedaços `city_solid_*` com colisão e `city_deco_*` sem colisão) e `game/traffic.gd` coloca
carros e pedestres andando pelas ruas.

Para regerar (opcional): `pip install numpy pillow`,
`python tools/make_textures.py && python tools/make_city_textures.py`,
`python tools/gen_city.py game/map/rp_downtown_vv1.obj game/city`.

Ajustes: `K` (camadas de quarteirões, deixa a cidade maior ou menor), `SEED` (muda a cidade)
e as faixas de andares por região, no começo e no meio de `tools/gen_city.py`.

## Extras do jogo (cada um é um script opcional em `game/`)
- `hud.gd`: mini-mapa no canto superior esquerdo, relógio, dinheiro, missão e velocidade
- `daynight.gd`: ciclo de dia e noite (8 min reais; mude `DAY_SECONDS`), postes acendem e o carro liga os faróis
- `missions.gd`: entregas, vá até o marcador amarelo e ganhe $100
- `traffic.gd`: carros e pedestres andando pelas ruas

## Cidade grande e estradas (versão 2)
- A cidade tem ~1,6 km x 1,6 km (`K = 8` em `tools/gen_city.py`), com colinas ao fundo.
- A cada 4ª rua há uma avenida de 32 m, com 4 faixas, canteiro central arborizado e estacionamento nas laterais.
- Cruzamentos com faixa de pedestres e linha de parada; asfalto com remendos, rachaduras e bueiros.
- Árvores, postes, carros e semáforos só existem até `PROP_R` (520 m) do mapa, para não pesar no celular.

## Realismo (versão 3)
- Prédios: relevo nas fachadas (normal maps), janelas que acendem à noite, frisos por andar, cornijas,
  platibandas, pilastras, toldos nas lojas, sacadas, casas de telhado de duas águas, torres escalonadas
  e telhados com caixa d'água, ar-condicionado e antenas.
- Árvores: tronco afunilado com galhos e copas feitas de cartões de folhas com transparência
  (carvalho, álamo, pinheiro e arbustos, em tons de verde diferentes).
- Os detalhes dos prédios só existem perto do mapa (`detail` em `tools/gen_city.py`), para não pesar longe.
- Para regerar as texturas: `python tools/make_city_textures.py`; depois `python tools/gen_city.py game/map/rp_downtown_vv1.obj game/city`.

## Gráficos do mapa original (versão 4)
- `tools/bake_ao.py`: subdivide as faces e grava sombreamento nos vértices do mapa (oclusão ambiental +
  exposição ao céu): cantos e interiores ficam mais escuros, telhados e praças mais claros.
  Gera `game/map/rp_downtown_vv1_shaded.obj` (para desenhar); o OBJ simples continua servindo de colisão.
  Uso: `pip install numpy && python tools/bake_ao.py game/map/rp_downtown_vv1.obj game/map/rp_downtown_vv1_shaded.obj 2.0`
- Texturas do mapa agora têm mapas de relevo (`*_n.png`); metal, vidro, madeira e azulejo têm brilho próprio.
- `tools/export_lights.py` + `game/interior_lights.gd`: as 537 luzes originais do mapa viram luzes reais
  perto do jogador (`POOL` = quantas ao mesmo tempo; se pesar, diminua).

## Cidade mais realista (versão 5)
- Prédios: novo estilo de reboco pintado com venezianas (cores variadas), lojas com porta central e vitrines,
  mais variedade de cores e telhados.
- Ruas: semáforos com braço sobre a pista e lentes voltadas para quem chega, placas de rua, pontos de ônibus
  nas avenidas, lixeiras, hidrantes e covas escuras ao redor das árvores.
- Árvores: base alargada, galhos primários e secundários, copas mais cheias e três tipos de folha.

## Condomínios fechados (versão 6)
- `tools/gen_city.py` escolhe 3 quarteirões (distâncias e direções diferentes) e os deixa livres;
  `tools/gen_condos.py game/city/city_data.gd game/condos` gera os condomínios: 5, 6 e 10 casas.
- Cada condomínio tem muro com pilares, portaria com guarita e placa, rua interna sem saída com rotatória,
  postes, gramado e uma casa por arquivo (`condoN_houseK_raw.obj` = colisão; `condoN_houseK.obj` = com sombreamento).
- Casas: fundação, paredes de reboco, madeira ou tijolo, telhado de duas águas com beiral e chaminé, porta com
  degraus e alpendre, janelas com moldura, peitoril, venezianas e vidro (algumas acendem à noite), garagem,
  entrada de carros, calçada, caixa de correio, arbustos, quintal com cerca e árvores, e às vezes piscina.
- `tools/blender/enhance_houses.py`: etapa opcional do GitHub Actions (Blender sem interface) que arredonda
  as quinas das casas. Se falhar, o jogo usa as casas que já vêm no zip.

## Iluminação gravada da cidade (versão 7)
- `tools/bake_city.py game/city 220`: grava nos pedaços sólidos da cidade (raio de 220 m em volta do mapa) a
  exposição ao céu e a oclusão (ruas entre prédios altos, cantos e vãos ficam mais escuros; telhados e praças, claros).
  Gera `city_solid_A_B_lit.obj` ao lado de cada pedaço; o jogo desenha o `_lit` e usa o original na colisão.
  Vale para qualquer hora do dia (não depende da posição do sol, que continua em tempo real com sombras).
- `tools/blender/bake_city_gi.py`: etapa opcional do GitHub Actions. O Blender (Cycles) refaz essa gravação com
  luz do céu que quica nas paredes (iluminação global) e reescreve as cores dos mesmos `_lit.obj`.
  No Actions, desmarque "usar_blender" ao rodar manualmente para um build mais rápido.

## Mapa original (versão 8)
- Materiais mais precisos: 51 em vez de 35, com texturas novas para piso e parede de concreto (com juntas e furos de
  fôrma), forro de gesso, papel de parede, terra, telha metálica, piso de tijolo e metal escuro (Combine), todas com relevo.
- `tools/map_props.py mapa.bsp game/map/rp_downtown_vv1.obj game/map`: recria objetos que não vieram na conversão:
  108 portas (abertas ou entreabertas, achadas pelos vãos), 214 luminárias de domo e 158 fluorescentes (acesas),
  10 postes, 9 bancos, 7 lixeiras, 5 fogões, mesas, arquivos, geladeiras, caixas de força e corrimãos.
- As portas são só decoração (sem colisão); móveis, bancos, postes e fogões têm colisão.

## Versão 9: personagem, carro, câmera e paredes com espessura
- Blender e Godot são obrigatórios no build (`build-apk.yml`): o Blender cria o personagem com esqueleto e
  animações (`tools/blender/make_character.py`: idle, walk, run), o carro e a roda (`make_car.py`), arredonda
  as casas (`enhance_houses.py`) e calcula a iluminação da cidade (`bake_city_gi.py`). Se uma etapa falhar, o
  build para e mostra o erro no log. Os arquivos gerados vão para `game/assets/` (`character.glb`, `car_body.glb`, `car_wheel.glb`).
- `game/player.gd` usa o personagem e as animações (cápsula laranja só se o arquivo não existir).
- `game/car.gd`: modelo do Blender, suspensão, tração traseira, direção que endurece em velocidade, freio, freio de
  mão (botão na tela) e ré. Se andar de ré ao acelerar: `DRIVE_SIGN = -1.0`; direção invertida: `STEER_SIGN = -1.0`.
- Câmera com colisão (`game/main.gd`): para nas paredes e no chão; não mostra mais o interior dos prédios nem a
  parte de baixo da cidade. As malhas de colisão também valem pelas costas das faces.
- Trânsito e pedestres desligados por enquanto (`CAR_COUNT` e `PED_COUNT` em `game/traffic.gd`).
- Prédios de tijolo, concreto e reboco até 180 m do mapa: térreo + 3 andares com janelas abertas de verdade
  (parede com espessura, vão, peitoril e vidro recuado), friso por andar, pilastras, cornija e platibanda.
