extends Node3D
# Monta o mundo inteiro por código: mapa, luz, jogador, carro, câmera e controles.

const MAP_PATH := "res://map/rp_downtown_vv1.obj"
const MAP_SHADED_PATH := "res://map/rp_downtown_vv1_shaded.obj"
const SPAWN := Vector3(-50.12, -2.4, 34.11)  # info_player_start do mapa, já em metros

var player: CharacterBody3D
var car: VehicleBody3D
var cam: Camera3D
var controls: CanvasLayer
var in_car := false
var yaw := 0.0
var pitch := -0.25
var sky_mat: ProceduralSkyMaterial
var env: Environment
var sun: DirectionalLight3D
var game_hour := 10.0
var lamp_mats: Array = []
var window_mats: Array = []
var _tex_cache: Dictionary = {}


func _ready() -> void:
	_build_environment()
	_build_map()
	_build_city()

	player = preload("res://player.gd").new()
	add_child(player)
	player.global_position = SPAWN

	car = preload("res://car.gd").new()
	add_child(car)
	car.global_position = SPAWN + Vector3(5, 0.5, 0)

	cam = Camera3D.new()
	cam.far = 2200.0
	cam.near = 0.2
	add_child(cam)
	cam.current = true
	cam.global_position = SPAWN + Vector3(0, 3, 5)

	controls = preload("res://touch_controls.gd").new()
	add_child(controls)
	controls.look.connect(_on_look)
	controls.jump_pressed.connect(_on_jump)
	controls.action_pressed.connect(_toggle_car)
	controls.reset_pressed.connect(_reset_car)

	# Recursos extras: cada um é opcional (se algum script falhar, o resto continua).
	for path in ["res://traffic.gd", "res://hud.gd", "res://daynight.gd", "res://missions.gd", "res://interior_lights.gd"]:
		var sc = load(path)
		if sc != null:
			var node = sc.new()
			node.main = self
			if path == "res://hud.gd":
				node.name = "Hud"
			add_child(node)


# Mude para false se o jogo ficar pesado no seu celular.
const SHADOWS := true


func _build_environment() -> void:
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.22, 0.42, 0.74)
	sky_mat.sky_horizon_color = Color(0.68, 0.78, 0.88)
	sky_mat.ground_horizon_color = Color(0.68, 0.74, 0.80)
	sky_mat.ground_bottom_color = Color(0.30, 0.32, 0.35)
	sky_mat.sun_angle_max = 25.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.8
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.fog_enabled = true
	env.fog_light_color = Color(0.70, 0.78, 0.88)
	env.fog_density = 0.0018
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_color = Color(1.0, 0.94, 0.82)
	sun.light_energy = 1.25
	sun.shadow_enabled = SHADOWS
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 70.0
	sun.shadow_bias = 0.08
	sun.shadow_normal_bias = 1.5
	add_child(sun)


func _build_map() -> void:
	var col_mesh = load(MAP_PATH)  # malha simples, usada na colisão
	if col_mesh == null or not (col_mesh is Mesh):
		push_error("Mapa não encontrado em " + MAP_PATH)
		return
	# malha subdividida com sombreamento gravado nos vértices (se existir)
	var vis_mesh = null
	if ResourceLoader.exists(MAP_SHADED_PATH):
		vis_mesh = load(MAP_SHADED_PATH)
	var shaded: bool = vis_mesh != null and vis_mesh is Mesh
	if not shaded:
		vis_mesh = col_mesh
	for i in range(vis_mesh.get_surface_count()):
		var mat = vis_mesh.surface_get_material(i)
		if mat is BaseMaterial3D:
			_setup_map_material(mat, shaded)
	var mi := MeshInstance3D.new()
	mi.mesh = vis_mesh
	add_child(mi)

	var body := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	shape.shape = col_mesh.create_trimesh_shape()
	shape.shape.backface_collision = true
	body.add_child(shape)
	add_child(body)

	# portas, luminárias, postes, bancos, mesas etc. recriados a partir do mapa original
	_add_chunk("res://map/map_props_solid.obj", true, 0.0)
	_add_chunk("res://map/map_props_deco.obj", false, 260.0)


func _setup_map_material(m: BaseMaterial3D, shaded: bool) -> void:
	m.cull_mode = BaseMaterial3D.CULL_DISABLED  # se alguma face ficou ao contrário, ainda aparece
	m.roughness = 0.85
	m.metallic = 0.0
	m.metallic_specular = 0.15
	if shaded:
		m.vertex_color_use_as_albedo = true
	var n := String(m.resource_name)
	var base := n
	if n.length() > 2 and n[n.length() - 2] == "_" and n[n.length() - 1].is_valid_int():
		base = n.substr(0, n.length() - 2)
	var nt = _tex("res://map/tex/%s_n.png" % base)
	if nt != null:
		m.normal_enabled = true
		m.normal_texture = nt
		m.normal_scale = 1.0
	match base:
		"p_metal":
			m.metallic = 0.55
			m.roughness = 0.4
		"p_glass":
			m.roughness = 0.12
			m.metallic_specular = 0.7
		"p_wood":
			m.roughness = 0.65
		"p_tile":
			m.roughness = 0.25
		"p_facade", "p_storefront":
			m.roughness = 0.35
		"p_combine":
			m.metallic = 0.5
			m.roughness = 0.45
		"p_corrugated":
			m.metallic = 0.5
			m.roughness = 0.5
		"p_concrete_floor":
			m.roughness = 0.6
		"p_dirt":
			m.roughness = 1.0
		"p_ceiling", "p_wallpaper":
			m.roughness = 0.95


func _build_city() -> void:
	var cd = load("res://city/city_data.gd")
	if cd == null:
		push_warning("Cidade não encontrada em res://city/")
		return
	for base in cd.SOLID:
		_add_chunk("res://city/%s.obj" % base, true, 1100.0, "res://city/%s_lit.obj" % base)
	for base in cd.DECO:
		_add_chunk("res://city/%s.obj" % base, false, 380.0)
	_add_chunk("res://city/%s.obj" % cd.SCENERY, false, 0.0)  # colinas ao fundo, sempre visíveis
	_build_condos()


func _add_chunk(path: String, collide: bool, vis_end: float, lit_path: String = "") -> void:
	var mesh = load(path)  # malha simples: colisão (e desenho, se não houver versão com sombreamento)
	if mesh == null or not (mesh is Mesh):
		return
	var vis = mesh
	var shaded := false
	if lit_path != "" and ResourceLoader.exists(lit_path):
		var lm = load(lit_path)
		if lm != null and lm is Mesh:
			vis = lm
			shaded = true
	for i in range(vis.get_surface_count()):
		var m = vis.surface_get_material(i)
		if m is BaseMaterial3D:
			_setup_material(m)
			if shaded:
				m.vertex_color_use_as_albedo = true
	var mi := MeshInstance3D.new()
	mi.mesh = vis
	mi.visibility_range_end = vis_end
	add_child(mi)
	if collide:
		var body := StaticBody3D.new()
		var shape := CollisionShape3D.new()
		shape.shape = mesh.create_trimesh_shape()
		shape.shape.backface_collision = true
		body.add_child(shape)
		add_child(body)


func _build_condos() -> void:
	var cdd = load("res://condos/condos_data.gd")
	if cdd == null:
		return
	for s in cdd.SITES:
		_add_chunk("res://condos/%s.obj" % s[0], true, 900.0)
		_add_chunk("res://condos/%s.obj" % s[1], false, 420.0)
	for h in cdd.HOUSES:
		_add_house(h)


func _add_house(h) -> void:
	# h = [nome, x, z, rotação em graus]; a casa tem malha simples (colisão) e malha com sombreamento
	var xf := Transform3D(Basis(Vector3.UP, deg_to_rad(float(h[3]))), Vector3(float(h[1]), 0.0, float(h[2])))
	var base := "res://condos/%s" % str(h[0])
	var col_mesh = load(base + "_raw.obj")
	if col_mesh == null or not (col_mesh is Mesh):
		return
	var vis_mesh = null
	if ResourceLoader.exists(base + ".obj"):
		vis_mesh = load(base + ".obj")
	var baked: bool = vis_mesh != null and vis_mesh is Mesh
	if not baked:
		vis_mesh = col_mesh
	for i in range(vis_mesh.get_surface_count()):
		var mat = vis_mesh.surface_get_material(i)
		if mat is BaseMaterial3D:
			_setup_material(mat)
			if baked:
				mat.vertex_color_use_as_albedo = true
	var mi := MeshInstance3D.new()
	mi.mesh = vis_mesh
	mi.transform = xf
	mi.visibility_range_end = 450.0
	add_child(mi)
	var body := StaticBody3D.new()
	body.transform = xf
	var shape := CollisionShape3D.new()
	shape.shape = col_mesh.create_trimesh_shape()
	shape.shape.backface_collision = true
	body.add_child(shape)
	add_child(body)


func _tex(path: String):
	if _tex_cache.has(path):
		return _tex_cache[path]
	var t = null
	if ResourceLoader.exists(path):
		t = load(path)
	_tex_cache[path] = t
	return t


func _setup_material(m: BaseMaterial3D) -> void:
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.roughness = 0.9
	m.metallic = 0.0
	m.metallic_specular = 0.15
	var n := String(m.resource_name)
	if n.begins_with("lamp_head"):
		m.emission_enabled = true
		m.emission = Color(1.0, 0.9, 0.6)
		m.emission_energy_multiplier = 0.5
		lamp_mats.append(m)
		return
	if n.begins_with("fixture_light"):
		m.emission_enabled = true
		m.emission = Color(1.0, 0.95, 0.8)
		m.emission_energy_multiplier = 2.2
		return
	if n.begins_with("house_glass_lit"):
		m.emission_enabled = true
		m.emission = Color(1.0, 0.82, 0.5)
		m.emission_energy_multiplier = 0.0
		m.roughness = 0.1
		window_mats.append(m)
		return
	if n.begins_with("house_glass"):
		m.roughness = 0.08
		m.metallic_specular = 0.8
		return
	if n.begins_with("leafcard"):
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		m.alpha_scissor_threshold = 0.45
		m.roughness = 1.0
		m.metallic_specular = 0.05
		return
	var base := n
	if n.length() > 2 and n[n.length() - 2] == "_" and n[n.length() - 1].is_valid_int():
		base = n.substr(0, n.length() - 2)
	var nt = _tex("res://city/tex/%s_n.png" % base)
	if nt != null:
		m.normal_enabled = true
		m.normal_texture = nt
		m.normal_scale = 1.0
	if base == "siding" or base == "plaster" or base == "brick":
		m.roughness = 0.85
	if base.begins_with("b_") or base == "roof_tile":
		var et = _tex("res://city/tex/%s_e.png" % base)
		if et != null:
			m.emission_enabled = true
			m.emission_texture = et
			m.emission_energy_multiplier = 0.0
			window_mats.append(m)
		if base == "b_glass":
			m.roughness = 0.2
			m.metallic_specular = 0.7
		elif base != "b_roof":
			m.roughness = 0.7


func focus_pos() -> Vector3:
	return car.global_position if in_car else player.global_position


func _on_jump() -> void:
	if not in_car:
		player.jump()


func _on_look(delta: Vector2) -> void:
	yaw -= delta.x * 0.005
	pitch = clamp(pitch - delta.y * 0.004, -1.2, 0.5)


func _toggle_car() -> void:
	if in_car:
		in_car = false
		var side := car.global_transform.basis.x * 2.5
		player.global_position = car.global_position + side + Vector3(0, 1.0, 0)
		player.set_active(true)
		car.throttle = 0.0
		car.steer = 0.0
	elif player.global_position.distance_to(car.global_position) < 5.0:
		in_car = true
		player.set_active(false)


func _reset_car() -> void:
	var p := player.global_position if not in_car else car.global_position
	car.linear_velocity = Vector3.ZERO
	car.angular_velocity = Vector3.ZERO
	car.global_transform = Transform3D(Basis(Vector3.UP, yaw), p + Vector3(0, 2.0, 0))


func _physics_process(delta: float) -> void:
	var mv: Vector2 = controls.move_vec
	if in_car:
		car.throttle = -mv.y
		car.steer = -mv.x
		car.handbrake = controls.handbrake
	else:
		player.move_input = mv
		player.run = mv.length() > 0.92
		player.cam_yaw = yaw
		if player.global_position.y < -60.0:
			player.global_position = SPAWN
			player.velocity = Vector3.ZERO

	var target: Vector3 = (car.global_position if in_car else player.global_position) + Vector3(0, 1.6, 0)
	var dist := 8.0 if in_car else 4.5
	var cam_basis := Basis.from_euler(Vector3(pitch, yaw, 0))
	var want := target + cam_basis * Vector3(0, 0, dist)
	var space := get_world_3d().direct_space_state
	var excl: Array[RID] = [player.get_rid(), car.get_rid()]
	# a câmera não atravessa paredes nem o chão: encosta no primeiro obstáculo entre o personagem e ela
	var q := PhysicsRayQueryParameters3D.create(target, want)
	q.exclude = excl
	var hit := space.intersect_ray(q)
	if hit:
		want = hit.position + (target - want).normalized() * 0.35
	var cam_pos := cam.global_position.lerp(want, clamp(12.0 * delta, 0.0, 1.0))
	var q2 := PhysicsRayQueryParameters3D.create(target, cam_pos)
	q2.exclude = excl
	var hit2 := space.intersect_ray(q2)
	if hit2:
		cam_pos = hit2.position + (target - cam_pos).normalized() * 0.35
	cam.global_position = cam_pos
	cam.look_at(target, Vector3.UP)
