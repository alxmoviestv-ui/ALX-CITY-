extends Node3D
# Luzes dos interiores: as luzes originais do mapa (537) viram luzes reais perto do jogador.
# POOL = quantas luzes ficam acesas ao mesmo tempo (aumente se o celular aguentar).

const POOL := 4
const RADIUS := 28.0

var main: Node3D
var lights_data: Array = []
var pool: Array = []
var _acc := 0.0


func _ready() -> void:
	var d = load("res://map_lights.gd")
	if d == null:
		set_process(false)
		return
	lights_data = d.LIGHTS
	for i in range(POOL):
		var l := OmniLight3D.new()
		l.omni_range = 11.0
		l.omni_attenuation = 1.3
		l.shadow_enabled = false
		l.visible = false
		add_child(l)
		pool.append(l)


func _process(delta: float) -> void:
	if main == null:
		return
	_acc += delta
	if _acc < 0.3:
		return
	_acc = 0.0
	var f: Vector3 = main.focus_pos() + Vector3(0, 1.0, 0)
	var cand: Array = []
	for L in lights_data:
		var dx: float = L[0] - f.x
		var dy: float = L[1] - f.y
		var dz: float = L[2] - f.z
		var d2: float = dx * dx + dy * dy + dz * dz
		if d2 < RADIUS * RADIUS:
			cand.append([d2, L])
	cand.sort_custom(func(a, b): return a[0] < b[0])
	for i in range(POOL):
		var l: OmniLight3D = pool[i]
		if i < cand.size():
			var L = cand[i][1]
			l.global_position = Vector3(L[0], L[1], L[2])
			l.light_color = Color(L[3], L[4], L[5])
			l.light_energy = float(L[6]) * 1.4
			l.visible = true
		else:
			l.visible = false
