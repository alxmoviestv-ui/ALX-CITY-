extends CharacterBody3D
# Jogador em terceira pessoa. Usa o personagem criado no Blender (res://assets/character.glb) com as
# animações idle, walk e run. Se o arquivo não existir (teste fora do build), usa uma cápsula.

const SPEED := 4.6
const RUN_SPEED := 8.0
const JUMP := 6.5
const GRAVITY := 22.0

var move_input := Vector2.ZERO
var cam_yaw := 0.0
var run := false
var _col: CollisionShape3D
var _visual: Node3D
var _anim: AnimationPlayer
var _current := ""


func _init() -> void:
	_col = CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.78
	_col.shape = cap
	_col.position.y = 0.89
	add_child(_col)

	var scene = null
	if ResourceLoader.exists("res://assets/character.glb"):
		scene = load("res://assets/character.glb")
	if scene is PackedScene:
		_visual = scene.instantiate()
		add_child(_visual)
		var players := _visual.find_children("*", "AnimationPlayer", true, false)
		if players.size() > 0:
			_anim = players[0]
			for n in ["idle", "walk", "run"]:
				if _anim.has_animation(n):
					_anim.get_animation(n).loop_mode = Animation.LOOP_LINEAR
		_play("idle")
	else:
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.35
		cm.height = 1.78
		mi.mesh = cm
		mi.position.y = 0.89
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.9, 0.4, 0.1)
		mi.material_override = mat
		add_child(mi)
		_visual = mi


func _play(n: String, speed: float = 1.0) -> void:
	if _anim == null or not _anim.has_animation(n):
		return
	if _current != n:
		_anim.play(n, 0.2)
		_current = n
	_anim.speed_scale = speed


func set_active(on: bool) -> void:
	visible = on
	set_physics_process(on)
	_col.set_deferred("disabled", not on)
	if not on:
		velocity = Vector3.ZERO


func jump() -> void:
	if is_on_floor():
		velocity.y = JUMP


func _physics_process(delta: float) -> void:
	var dir := Basis(Vector3.UP, cam_yaw) * Vector3(move_input.x, 0, move_input.y)
	var target_speed := RUN_SPEED if run else SPEED
	if dir.length() > 0.05:
		velocity.x = dir.x * target_speed
		velocity.z = dir.z * target_speed
		var target_yaw := atan2(-dir.x, -dir.z)
		rotation.y = lerp_angle(rotation.y, target_yaw, clamp(12.0 * delta, 0.0, 1.0))
	else:
		velocity.x = move_toward(velocity.x, 0, target_speed * 5 * delta)
		velocity.z = move_toward(velocity.z, 0, target_speed * 5 * delta)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	elif velocity.y < 0:
		velocity.y = 0
	floor_snap_length = 0.35
	move_and_slide()

	var hv := Vector2(velocity.x, velocity.z).length()
	if not is_on_floor() and hv > 0.5:
		_play("walk", 1.0)
	elif hv > SPEED + 1.5:
		_play("run", clamp(hv / RUN_SPEED, 0.7, 1.4))
	elif hv > 0.4:
		_play("walk", clamp(hv / SPEED, 0.6, 1.3))
	else:
		_play("idle", 1.0)
