extends VehicleBody3D
# Carro com física de veículo. Modelo do Blender: res://assets/car_body.glb e car_wheel.glb
# (se não existirem, usa caixas). throttle e steer vão de -1 a 1.

# Se o carro andar de ré ao acelerar, troque DRIVE_SIGN para -1.0. Se a direção estiver invertida, STEER_SIGN.
const DRIVE_SIGN := 1.0
const STEER_SIGN := 1.0
const MAX_SPEED := 42.0        # m/s (~150 km/h)
const ENGINE := 6500.0
const REVERSE_MAX := 10.0

var throttle := 0.0
var steer := 0.0
var handbrake := false
var lights: Array = []
var paint := Color(0.72, 0.08, 0.08)


func _init() -> void:
	mass = 1300.0
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0, 0.42, 0)
	linear_damp = 0.04
	angular_damp = 1.3

	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.8, 0.75, 4.2)
	col.shape = box
	col.position.y = 0.78
	add_child(col)

	_add_body_model()

	for x in [-0.6, 0.6]:
		var l := SpotLight3D.new()
		l.position = Vector3(x, 0.72, -2.2)
		l.spot_range = 45.0
		l.spot_angle = 30.0
		l.light_energy = 4.0
		l.visible = false
		add_child(l)
		lights.append(l)

	for sx in [-1.0, 1.0]:
		for sz in [-1.38, 1.38]:
			_add_wheel(Vector3(0.9 * sx, 0.42, sz), sz < 0)


func _add_body_model() -> void:
	var scene = null
	if ResourceLoader.exists("res://assets/car_body.glb"):
		scene = load("res://assets/car_body.glb")
	if scene is PackedScene:
		var model: Node3D = scene.instantiate()
		add_child(model)
		for mi in model.find_children("*", "MeshInstance3D", true, false):
			var mesh: Mesh = mi.mesh
			for i in range(mesh.get_surface_count()):
				var m = mesh.surface_get_material(i)
				if m is StandardMaterial3D and String(m.resource_name) == "paint":
					var d: StandardMaterial3D = m.duplicate()
					d.albedo_color = paint
					d.metallic = 0.55
					d.roughness = 0.25
					mi.set_surface_override_material(i, d)
	else:
		var body := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(1.8, 0.7, 4.2)
		body.mesh = bm
		body.position.y = 0.7
		var mat := StandardMaterial3D.new()
		mat.albedo_color = paint
		body.material_override = mat
		add_child(body)


func _add_wheel(pos: Vector3, front: bool) -> void:
	var w := VehicleWheel3D.new()
	w.position = pos
	w.wheel_radius = 0.35
	w.wheel_rest_length = 0.1
	w.suspension_travel = 0.25
	w.suspension_stiffness = 52.0
	w.suspension_max_force = 9000.0
	w.damping_compression = 2.2
	w.damping_relaxation = 2.8
	w.wheel_friction_slip = 2.6 if front else 3.0
	w.wheel_roll_influence = 0.25
	w.use_as_steering = front
	w.use_as_traction = not front
	var scene = null
	if ResourceLoader.exists("res://assets/car_wheel.glb"):
		scene = load("res://assets/car_wheel.glb")
	if scene is PackedScene:
		w.add_child(scene.instantiate())
	else:
		var m := MeshInstance3D.new()
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.35
		cyl.bottom_radius = 0.35
		cyl.height = 0.24
		m.mesh = cyl
		m.rotation_degrees = Vector3(0, 0, 90)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.06, 0.06, 0.06)
		m.material_override = mat
		w.add_child(m)
	add_child(w)


func set_lights(on: bool) -> void:
	for l in lights:
		l.visible = on


func _physics_process(delta: float) -> void:
	var fwd := -global_transform.basis.z
	var fwd_speed := linear_velocity.dot(fwd)
	var speed := linear_velocity.length()

	var force := 0.0
	var brk := 0.0
	if throttle > 0.05:
		if fwd_speed < -1.0:
			brk = 40.0                                      # freia antes de inverter
		else:
			force = throttle * ENGINE * (1.0 - clampf(fwd_speed / MAX_SPEED, 0.0, 1.0))
	elif throttle < -0.05:
		if fwd_speed > 1.0:
			brk = 40.0
		else:
			force = throttle * ENGINE * 0.7 * (1.0 - clampf(-fwd_speed / REVERSE_MAX, 0.0, 1.0))
	else:
		brk = 5.0                                           # freio-motor
	if handbrake:
		brk = 70.0
		force = 0.0
	engine_force = force * DRIVE_SIGN
	brake = brk

	var max_steer := lerpf(0.62, 0.18, clampf(speed / 28.0, 0.0, 1.0))
	steering = move_toward(steering, steer * STEER_SIGN * max_steer, 3.2 * delta)

	apply_central_force(Vector3.DOWN * speed * speed * 0.3)  # aderência em velocidade
